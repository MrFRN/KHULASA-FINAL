import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data } = await supabase.from('categories_i18n').select('*').eq('category_id', id).single();
      return res.status(200).json(data || {});
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'PUT' || req.method === 'POST') {
      const { id, name_en } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase
        .from('categories_i18n')
        .upsert({ category_id: id, name_en: name_en ?? null }, { onConflict: 'category_id' })
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('categories-i18n error:', err);
    return res.status(500).json({ error: err.message });
  }
}

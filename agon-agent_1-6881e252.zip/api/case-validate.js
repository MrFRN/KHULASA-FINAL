// Server-side case validation. Accepts a case slug or full case body.
// Used by the admin generator to enforce clinical-safety gates.
import supabase from './db-client.js';
import { validateCase } from './kb/case-validate.mjs';
import { trackTool } from './ai-track.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

async function loadCaseBySlug(slug) {
  const { data } = await supabase.from('case_scenarios').select('*').eq('slug', slug).maybeSingle();
  return data;
}

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();

    if (req.method === 'GET') {
      const slug = req.query?.slug;
      if (!slug) return res.status(400).json({ error: 'slug required' });
      const c = await loadCaseBySlug(slug);
      if (!c) return res.status(404).json({ error: 'Case not found' });
      const r = validateCase(c);
      // Best-effort log
      try {
        await supabase.from('case_validation_results').insert({
          case_id: c.id, checks: r.checks, score: r.score, passed: r.passed, needs_review: r.needsReview, created_at: new Date().toISOString(),
        });
      } catch { /* ignore */ }
      await trackTool('case-validate', ip, null, { slug, passed: r.passed });
      return res.status(200).json({ case_id: c.id, slug: c.slug, ...r });
    }

    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const b = req.body || {};
    const candidate = b.case || b;
    if (!candidate || typeof candidate !== 'object') return res.status(400).json({ error: 'case payload required' });
    const r = validateCase(candidate);
    await trackTool('case-validate', ip, null, { ok: r.passed });
    return res.status(200).json(r);
  } catch (err) {
    console.error('case-validate error:', err);
    return res.status(500).json({ error: err.message });
  }
}

// AI Care Plan Generator (full, NANDA-I) - rule-based, evidence-based.
// Returns a structured care plan: ranked NANDA diagnoses, SMART goals,
// evidence-based interventions, evaluations, priority justification, and real
// trusted references. No external LLM is called; everything is hand-coded from
// public knowledge (NANDA-I, NIC/NOC, and guideline orgs).
import { trackTool } from './ai-track.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

const DIAGNOSIS_KB = [
  {
    key: 'ineffective_airway_clearance',
    priority: 95,
    nanda_en: 'Ineffective Airway Clearance',
    nanda_ar: 'عدم فعالية إزالة مجرى الهواء',
    related_factor: 'Excess tracheobronchial secretions; airway obstruction; infection',
    related_factor_ar: 'إفرازات قصبية رئوية زائدة؛ انسداد مجرى الهواء؛ عدوى',
    ae: ['Adventitious breath sounds (crackles, wheezes)', 'Ineffective cough', 'Dyspnea', 'Tachypnea', 'Inability to remove secretions'],
    goals: ['The patient will demonstrate effective airway clearance as evidenced by absence of cyanosis and SpO2 >= 95% on room air within 24 h.',
            'The patient will maintain a patent airway, with clear breath sounds, within 48 h.'],
    goals_ar: ['سيُظهر المريض إزالة فعالة لمجرى الهواء بانعدام الزرقة وتشبع أكسجين >= 95% خلال 24 ساعة.',
                'سيحافظ المريض على مجرى هواء مفتوح مع أصوات تنفس نظيفة خلال 48 ساعة.'],
    interventions: ['Assess respiratory rate, depth, and SpO2 every 1-2 h; auscultate breath sounds every 4 h.',
                    "Position the patient in high Fowler's; encourage deep breathing and cough; assist with incentive spirometry every 1 h while awake.",
                    'Provide humidified oxygen as prescribed; titrate to maintain SpO2 92-95%.',
                    'Administer bronchodilators and mucolytics as ordered; evaluate response within 30 min.',
                    'Perform chest physiotherapy (percussion, vibration) and postural drainage as indicated.',
                    'Encourage fluid intake (2-3 L/day) if not contraindicated to thin secretions.',
                    'Suction oral/nasal trachea PRN using sterile technique; reassess breath sounds after each pass.',
                    'Reassess airway patency and oxygenation after each intervention; document response and tolerance.'],
    eval_options: [
      { tag: 'met', en: 'Patient became free of cyanosis; SpO2 >= 95% on room air; breath sounds clear.', ar: 'أصبح المريض خاليًا من الزرقة؛ تشبع أكسجين >= 95% على هواء الغرفة؛ أصوات تنفس نظيفة.' },
      { tag: 'partial', en: 'Patient became able to clear secretions with assistance; SpO2 90-94% on supplemental O2.', ar: 'أصبح المريض قادرًا على إزالة الإفرازات بمساعدة؛ تشبع أكسجين 90-94% على أكسجين إضافي.' },
      { tag: 'not', en: 'Patient became unable to maintain airway; SpO2 remained < 90% despite interventions.', ar: 'لم يستطع المريض الحفاظ على مجرى الهواء؛ تشبع أكسجين ظل < 90% رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'NANDA-I', url: 'https://nanda.org', note: 'NANDA International nursing diagnoses' },
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE clinical guidelines' },
      { abbr: 'GOLD', url: 'https://goldcopd.org', note: 'GOLD COPD guidelines' },
    ],
  },
  {
    key: 'impaired_gas_exchange',
    priority: 92,
    nanda_en: 'Impaired Gas Exchange',
    nanda_ar: 'اختلال تبادل الغازات',
    related_factor: 'Alveolar-capillary membrane changes; ventilation-perfusion mismatch',
    related_factor_ar: 'تغيرات في الغشاء السنخي الشعري؛ عدم تطابق تهوية/تروية',
    ae: ['Hypoxemia (PaO2 < 80 mmHg)', 'Tachypnea', 'Confusion or restlessness', 'Cyanosis'],
    goals: ['The patient will maintain adequate oxygenation with PaO2 >= 80 mmHg and SpO2 >= 92% within 24 h.',
            'The patient will demonstrate improved mental status within 48 h.'],
    goals_ar: ['سيحافظ المريض على أكسجة كافية بـ PaO2 >= 80 mmHg وتشبع >= 92% خلال 24 ساعة.',
                'سيُظهر تحسنًا في الحالة الذهنية خلال 48 ساعة.'],
    interventions: ['Assess respiratory rate, SpO2, and mental status every 1-2 h.',
                    "Position the patient in high Fowler's to maximize lung expansion.",
                    'Administer supplemental oxygen via nasal cannula or mask; titrate to SpO2 target.',
                    'Encourage deep-breathing and coughing every 1 h while awake; assist with incentive spirometry.',
                    'Monitor ABG results; report PaO2 < 60 or pH < 7.30 to provider.',
                    'Administer bronchodilators, corticosteroids, or diuretics as ordered and monitor response.',
                    'Provide rest periods between activities of daily living; cluster care to prevent desaturation.',
                    'Reassess oxygenation, work of breathing, and mental status after each intervention; document findings.'],
    eval_options: [
      { tag: 'met', en: 'Patient became oriented; SpO2 >= 92% on room air; PaO2 >= 80 mmHg.', ar: 'أصبح المريض مُتوجهاً؛ تشبع >= 92% على هواء الغرفة؛ PaO2 >= 80 mmHg.' },
      { tag: 'partial', en: 'Patient became less confused; SpO2 90-91% on supplemental O2.', ar: 'أصبح المريض أقل تشوشًا؛ تشبع 90-91% على أكسجين إضافي.' },
      { tag: 'not', en: 'Patient became more hypoxic despite interventions.', ar: 'أصبح المريض أكثر نقصًا في الأكسجة رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'GINA', url: 'https://ginasthma.org', note: 'GINA asthma guidelines' },
      { abbr: 'GOLD', url: 'https://goldcopd.org', note: 'GOLD COPD guidelines' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO respiratory care' },
    ],
  },
  {
    key: 'risk_for_falls',
    priority: 90,
    nanda_en: 'Risk for Falls',
    nanda_ar: 'خطر السقوط',
    related_factor: 'Age > 60; impaired mobility; cognitive impairment; medication effects',
    related_factor_ar: 'العمر > 60؛ ضعف الحركة؛ ضعف الإدراك؛ تأثير الأدوية',
    ae: [],
    goals: ['The patient will remain free of falls during hospitalization.',
            'The patient will demonstrate proper use of assistive devices within 24 h.'],
    goals_ar: ['سيبقى المريض خاليًا من السقوط طوال فترة الإقامة.',
                'سيُظهر الاستخدام الصحيح للأدوات المساعدة خلال 24 ساعة.'],
    interventions: ['Assess fall risk (e.g., Morse Fall Scale) on admission and every shift.',
                    'Implement universal fall precautions: bed in lowest position, non-slip footwear, call bell within reach.',
                    'Orient patient to room; ensure adequate lighting; keep frequently used items within reach.',
                    'Address modifiable risk factors: review medications, treat orthostasis, correct vision/hearing.',
                    'Provide non-slip footwear; ensure assistive devices are accessible and in good working order.',
                    'Educate patient and family on fall prevention strategies; encourage use of call bell before mobilizing.',
                    'Reassess mental status and gait; consider physical therapy consult for mobility training.',
                    'Reassess fall risk daily and after any change in status; document interventions and patient response.'],
    eval_options: [
      { tag: 'met', en: 'Patient became free of falls during hospitalization.', ar: 'أصبح المريض خاليًا من السقوط طوال فترة الإقامة.' },
      { tag: 'partial', en: 'Patient became at risk of falling but did not actually fall.', ar: 'أصبح المريض معرّضًا لخطر السقوط لكنه لم يسقط فعليًا.' },
      { tag: 'not', en: 'Patient became a fall victim despite interventions.', ar: 'أصبح المريض ضحية سقوط رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE falls assessment' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO fall prevention' },
    ],
  },
  {
    key: 'acute_pain',
    priority: 88,
    nanda_en: 'Acute Pain',
    nanda_ar: 'ألم حاد',
    ae: ['Patient report of pain', 'Guarding behavior', 'Facial grimacing', 'Tachycardia, hypertension', 'Diaphoresis'],
    goals: ['The patient will report pain <= 3 on a 0-10 scale within 1 h of intervention.'],
    goals_ar: ['سيُبلغ المريض عن ألم <= 3 على مقياس 0-10 خلال ساعة من التدخل.'],
    interventions: ['Assess pain using a standardized scale (e.g., 0-10 numeric) every 1-2 h and after each intervention.',
                    'Administer prescribed analgesics on a scheduled basis; evaluate effect within 30-60 min.',
                    'Provide non-pharmacologic comfort: positioning, distraction, relaxation techniques, cold/warm therapy.',
                    'Identify and treat underlying cause of pain in collaboration with the healthcare team.',
                    'Monitor for opioid side effects: respiratory depression, sedation, nausea, constipation.',
                    'Educate patient on pain scale use and encourage proactive reporting of pain.',
                    'Reassess pain and document response after each intervention; adjust care plan as needed.',
                    'Reassess pain level and side effects; document and communicate with provider if pain persists.'],
    eval_options: [
      { tag: 'met', en: 'Patient became pain-free or pain <= 3/10 within 1 h.', ar: 'أصبح المريض بدون ألم أو ألم <= 3/10 خلال ساعة.' },
      { tag: 'partial', en: 'Patient became pain reduced to 4-5/10 within 1 h.', ar: 'انخفض الألم إلى 4-5/10 خلال ساعة.' },
      { tag: 'not', en: 'Patient became with unchanged or worsened pain.', ar: 'لم يتغير الألم أو ازداد سوءًا.' },
    ],
    refs: [
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE pain management' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO analgesic guidance' },
    ],
  },
  {
    key: 'risk_for_infection',
    priority: 86,
    nanda_en: 'Risk for Infection',
    nanda_ar: 'خطر العدوى',
    related_factor: 'Invasive devices (catheters, IVs); surgical wounds; immunosuppression',
    related_factor_ar: 'أجهزة باضعة (قسطرة، وريدية)؛ جروح جراحية؛ نقص المناعة',
    ae: [],
    goals: ['The patient will remain free of new infection during hospitalization.'],
    goals_ar: ['سيبقى المريض خاليًا من العدوى الجديدة طوال فترة الإقامة.'],
    interventions: ['Assess temperature, WBC, and clinical signs of infection every shift.',
                    'Perform hand hygiene before and after every patient contact; follow standard precautions.',
                    'Use aseptic technique for all invasive procedures (catheters, IVs, wound care).',
                    'Monitor indwelling devices (catheters, lines) daily; remove as soon as no longer needed.',
                    'Administer prophylactic antibiotics as prescribed; monitor for response and side effects.',
                    'Promote nutrition and hydration to support immune function.',
                    'Educate patient and family on hand hygiene and signs of infection to report.',
                    'Reassess signs of infection daily; reassess need for invasive devices.'],
    eval_options: [
      { tag: 'met', en: 'Patient became free of new infection during hospitalization.', ar: 'أصبح المريض خاليًا من العدوى الجديدة.' },
      { tag: 'partial', en: 'Patient became with mild signs of infection, treated successfully.', ar: 'ظهرت علامات خفيفة للعدوى وعولجت بنجاح.' },
      { tag: 'not', en: 'Patient became with confirmed new infection during stay.', ar: 'أُكدت عدوى جديدة خلال الإقامة.' },
    ],
    refs: [
      { abbr: 'CDC', url: 'https://www.cdc.gov', note: 'CDC infection prevention' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO IPC guidelines' },
      { abbr: 'IDSA', url: 'https://www.idsociety.org', note: 'IDSA infection guidance' },
    ],
  },
  {
    key: 'impaired_skin_integrity',
    priority: 84,
    nanda_en: 'Impaired Skin Integrity',
    nanda_ar: 'اختلال سلامة الجلد',
    ae: ['Disruption of skin surface', 'Redness', 'Wound', 'Edema', 'Pain'],
    goals: ['The patient will demonstrate progressive wound healing within 7-10 days.',
            'The patient will remain free of new pressure injuries during hospitalization.'],
    goals_ar: ['سيُظهر المريض تقدمًا في التئام الجرح خلال 7-10 أيام.',
                'سيبقى خاليًا من إصابات الضغط الجديدة.'],
    interventions: ['Assess skin integrity (Braden Scale) on admission and daily; document findings.',
                    'Inspect pressure points (heels, sacrum, elbows) every shift; keep skin clean and dry.',
                    'Reposition q2h; use pressure-relieving mattress and pillows; offload heels.',
                    'Perform wound care using sterile technique; apply prescribed dressings.',
                    'Maintain adequate nutrition and hydration to support wound healing (protein, vitamin C, zinc).',
                    'Educate patient and family on skin care, repositioning, and signs of infection.',
                    'Coordinate with wound care nurse and dietitian as needed; reassess wound progress weekly.',
                    'Reassess skin integrity and wound progress at each dressing change; adjust care plan as needed.'],
    eval_options: [
      { tag: 'met', en: 'Patient became with wound healing progressing on schedule; no new pressure injuries.', ar: 'الجرح يلتئم وفق الجدول؛ لم تظهر إصابات ضغط جديدة.' },
      { tag: 'partial', en: 'Patient became with partial wound healing; wound size reduced.', ar: 'التئام جزئي؛ حجم الجرح انخفض.' },
      { tag: 'not', en: 'Patient became with worsening wound or new pressure injuries.', ar: 'تفاقم الجرح أو ظهور إصابات ضغط جديدة.' },
    ],
    refs: [
      { abbr: 'NPUAP', url: 'https://npuap.org', note: 'Pressure injury staging' },
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE wound care' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO patient safety' },
    ],
  },
  {
    key: 'deficient_fluid_volume',
    priority: 82,
    nanda_en: 'Deficient Fluid Volume',
    nanda_ar: 'نقص حجم السوائل',
    ae: ['Dry mucous membranes', 'Decreased skin turgor', 'Tachycardia', 'Hypotension', 'Decreased urine output', 'Concentrated urine'],
    goals: ['The patient will maintain adequate hydration with urine output >= 0.5 mL/kg/h within 24 h.',
            'The patient will demonstrate stable vital signs within 24 h.'],
    goals_ar: ['سيحافظ المريض على ترطيب كافٍ مع إدرار بول >= 0.5 مل/كغ/س خلال 24 ساعة.',
                'سيُظهر علامات حيوية مستقرة خلال 24 ساعة.'],
    interventions: ['Assess intake and output every 1 h; monitor for signs of dehydration.',
                    "Administer isotonic IV fluids (e.g., 0.9% NaCl or Ringer's lactate) as prescribed; titrate to clinical response.",
                    'Encourage oral fluid intake of 2-3 L/day unless contraindicated; offer preferred fluids frequently.',
                    'Monitor electrolytes (Na, K, Cl, HCO3, BUN/Cr) and report abnormalities.',
                    'Assess for signs of fluid overload: JVD, crackles, edema; titrate fluid rate accordingly.',
                    'Position the patient to optimize comfort and prevent aspiration if vomiting.',
                    'Educate patient on oral rehydration solutions (e.g., ORS) and signs of dehydration.',
                    'Reassess fluid status, vitals, and lab values; adjust fluid orders as needed.'],
    eval_options: [
      { tag: 'met', en: 'Patient became euvolemic with stable vitals and adequate urine output.', ar: 'أصبح المريض طبيعي الترطيب مع علامات حيوية مستقرة وإدرار كافٍ.' },
      { tag: 'partial', en: 'Patient became improved but not fully euvolemic; BP stable.', ar: 'تحسن المريض لكن لم يصل للحالة الطبيعية بعد.' },
      { tag: 'not', en: 'Patient became with worsening dehydration despite interventions.', ar: 'تفاقم الجفاف رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO rehydration guidelines' },
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE IV fluid therapy' },
    ],
  },
  {
    key: 'anxiety',
    priority: 80,
    nanda_en: 'Anxiety',
    nanda_ar: 'قلق',
    ae: ['Patient expresses worry', 'Restlessness', 'Tachycardia', 'Tachypnea', 'Insomnia'],
    goals: ['The patient will report reduced anxiety (score <= 3/10) within 24 h.'],
    goals_ar: ['سيُبلغ المريض عن انخفاض القلق (<= 3/10) خلال 24 ساعة.'],
    interventions: ['Assess anxiety using a standardized scale (e.g., GAD-7) on admission and every shift.',
                    'Provide a calm, quiet environment; reduce noise and stimulation.',
                    'Use therapeutic communication: listen actively, validate feelings, provide clear information.',
                    'Teach relaxation techniques: deep breathing, guided imagery, progressive muscle relaxation.',
                    'Encourage family presence and involvement in care when appropriate.',
                    'Administer anxiolytics as prescribed; monitor for side effects (sedation, respiratory depression).',
                    'Provide patient and family education about procedures to reduce fear of the unknown.',
                    'Reassess anxiety level and coping; adjust interventions as needed.'],
    eval_options: [
      { tag: 'met', en: 'Patient became calm; anxiety score <= 3/10; able to rest.', ar: 'أصبح المريض هادئًا؛ درجة القلق <= 3/10؛ قادر على الراحة.' },
      { tag: 'partial', en: 'Patient became less anxious; score 4-5/10 with intervention.', ar: 'انخفض القلق إلى 4-5/10 مع التدخل.' },
      { tag: 'not', en: 'Patient became more anxious despite interventions.', ar: 'ازداد القلق رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE anxiety management' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO mental health gap' },
    ],
  },
  {
    key: 'imbalanced_nutrition',
    priority: 78,
    nanda_en: 'Imbalanced Nutrition: Less Than Body Requirements',
    nanda_ar: 'سوء تغذية أقل من احتياجات الجسم',
    ae: ['BMI < 18.5', 'Weight loss > 5% in 1 month', 'Poor oral intake', 'Loss of subcutaneous fat'],
    goals: ['The patient will maintain stable weight and adequate nutrition within 7 days.'],
    goals_ar: ['سيحافظ المريض على وزن مستقر وتغذية كافية خلال 7 أيام.'],
    interventions: ['Assess nutritional status (BMI, albumin, prealbumin) on admission and weekly.',
                    'Provide high-protein, high-calorie meals and supplements as prescribed.',
                    'Offer small, frequent meals (6 per day) to encourage intake.',
                    'Coordinate with dietitian for individualized meal planning and patient preferences.',
                    'Administer enteral or parenteral nutrition as ordered if oral intake inadequate.',
                    'Provide oral care before meals to improve taste perception.',
                    'Educate patient and family on nutritional needs and importance of intake.',
                    'Reassess intake, weight, and lab values weekly; adjust plan as needed.'],
    eval_options: [
      { tag: 'met', en: 'Patient became meeting >= 80% of daily caloric needs; weight stable.', ar: 'استوفى >= 80% من السعرات اليومية؛ الوزن مستقر.' },
      { tag: 'partial', en: 'Patient became meeting 60-80% of daily caloric needs; weight stable.', ar: 'استوفى 60-80% من السعرات؛ الوزن مستقر.' },
      { tag: 'not', en: 'Patient became with continued weight loss and poor intake.', ar: 'استمر فقدان الوزن وضعف المدخول.' },
    ],
    refs: [
      { abbr: 'ASPEN', url: 'https://www.nutritioncare.org', note: 'ASPEN guidelines' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO nutrition' },
    ],
  },
  {
    key: 'decreased_cardiac_output',
    priority: 95,
    nanda_en: 'Decreased Cardiac Output',
    nanda_ar: 'انخفاض الناتج القلبي',
    ae: ['Tachycardia', 'Hypotension', 'Decreased urine output', 'Cool extremities', 'Altered mental status', 'Crackles', 'Edema'],
    goals: ['The patient will maintain adequate cardiac output with MAP >= 65 mmHg within 24 h.'],
    goals_ar: ['سيحافظ المريض على ناتج قلبي كافٍ بـ MAP >= 65 mmHg خلال 24 ساعة.'],
    interventions: ['Assess heart rate, BP, MAP, and urine output every 1 h.',
                    'Monitor for signs of decreased cardiac output: hypotension, cool extremities, altered mental status, oliguria.',
                    'Administer prescribed medications (e.g., inotropes, vasopressors) and titrate to MAP target.',
                    'Position the patient to optimize venous return; avoid supine if dyspneic.',
                    'Provide supplemental oxygen to maintain SpO2 >= 92%; titrate as needed.',
                    'Monitor ECG continuously for arrhythmias; report changes immediately.',
                    'Educate patient and family about the condition, plan of care, and when to call for help.',
                    'Reassess hemodynamics and response to interventions; document and communicate changes.'],
    eval_options: [
      { tag: 'met', en: 'Patient became hemodynamically stable; MAP >= 65 mmHg; urine output adequate.', ar: 'استقرت ديناميكيًا؛ MAP >= 65 mmHg؛ إدرار كافٍ.' },
      { tag: 'partial', en: 'Patient became with improving MAP and urine output; still requires monitoring.', ar: 'تحسنت MAP والإدرار؛ لا يزال يحتاج مراقبة.' },
      { tag: 'not', en: 'Patient became with worsening hemodynamics despite interventions.', ar: 'تدهورت الديناميكا رغم التدخلات.' },
    ],
    refs: [
      { abbr: 'AHA', url: 'https://www.heart.org', note: 'AHA heart failure guidelines' },
      { abbr: 'ESC', url: 'https://www.escardio.org', note: 'ESC heart failure guidelines' },
    ],
  },
  {
    key: 'activity_intolerance',
    priority: 70,
    nanda_en: 'Activity Intolerance',
    nanda_ar: 'عدم تحمل النشاط',
    ae: ['Reports fatigue with activity', 'Dyspnea on exertion', 'Tachycardia with activity', 'Abnormal BP response'],
    goals: ['The patient will tolerate increased activity without excessive fatigue or dyspnea within 7 days.'],
    goals_ar: ['سيتحمل المريض زيادة النشاط دون إرهاق أو ضيق نفس شديد خلال 7 أيام.'],
    interventions: ['Assess activity tolerance and vital signs before, during, and after activity.',
                    'Plan activities with rest periods; cluster care to minimize exertion.',
                    'Encourage gradual increase in activity as tolerated; use a progress chart.',
                    'Provide supplemental oxygen during activity if SpO2 drops below 90%.',
                    'Educate patient on energy conservation techniques and pacing.',
                    'Coordinate with physical therapy for a tailored activity plan.',
                    'Reassess activity tolerance after each session; adjust plan as needed.',
                    'Reassess activity tolerance at each shift; communicate progress to the team.'],
    eval_options: [
      { tag: 'met', en: 'Patient became able to perform ADLs without excessive fatigue or dyspnea.', ar: 'أصبح قادرًا على أداء أنشطة الحياة اليومية دون إرهاق شديد.' },
      { tag: 'partial', en: 'Patient became able to perform partial ADLs; needs frequent rest.', ar: 'أصبح قادرًا على جزء من الأنشطة؛ يحتاج راحة متكررة.' },
      { tag: 'not', en: 'Patient became unable to perform ADLs; severe fatigue with minimal activity.', ar: 'لم يستطع أداء الأنشطة؛ إرهاق شديد بأقل جهد.' },
    ],
    refs: [
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE chronic conditions' },
      { abbr: 'WHO', url: 'https://www.who.int', note: 'WHO chronic disease' },
    ],
  },
  {
    key: 'disturbed_sleep_pattern',
    priority: 60,
    nanda_en: 'Disturbed Sleep Pattern',
    nanda_ar: 'اضطراب نمط النوم',
    ae: ['Verbal complaints of difficulty sleeping', 'Daytime sleepiness', 'Irritability'],
    goals: ['The patient will report adequate sleep (>= 6 h) within 7 days.'],
    goals_ar: ['سيُبلغ المريض عن نوم كافٍ (>= 6 ساعات) خلال 7 أيام.'],
    interventions: ['Assess sleep patterns on admission; document contributing factors.',
                    'Establish a quiet environment; dim lights and minimize noise at night.',
                    'Cluster care activities to allow uninterrupted sleep periods.',
                    'Avoid caffeine and heavy meals in the evening.',
                    'Provide relaxation techniques: warm drink, deep breathing, music.',
                    'Administer sedatives as ordered; monitor for side effects.',
                    'Educate patient on sleep hygiene.',
                    'Reassess sleep quality; adjust interventions.'],
    eval_options: [
      { tag: 'met', en: 'Patient became sleeping >= 6 h with daytime alertness.', ar: 'نام >= 6 ساعات مع يقظة نهارية.' },
      { tag: 'partial', en: 'Patient became sleeping 4-5 h with daytime drowsiness.', ar: 'نام 4-5 ساعات مع نعاس نهاري.' },
      { tag: 'not', en: 'Patient became with severe insomnia.', ar: 'أرق شديد.' },
    ],
    refs: [
      { abbr: 'AASM', url: 'https://aasm.org', note: 'AASM clinical practice guideline' },
      { abbr: 'NICE', url: 'https://www.nice.org.uk', note: 'NICE sleep disorders' },
    ],
  },
];

function buildCarePlan(caseData) {
  const lang = caseData.lang === 'ar' ? 'ar' : 'en';
  const text = (
    (caseData.casePaste || '') + ' ' +
    (caseData.symptoms || []).join(' ') + ' ' +
    (caseData.diagnosis || '') + ' ' +
    (caseData.assessment || '') + ' ' +
    (caseData.history || '')
  ).toLowerCase();
  const age = Number(caseData.age) || 0;
  const matches = [];

  for (const rule of DIAGNOSIS_KB) {
    let score = 0;
    if (rule.key === 'ineffective_airway_clearance') {
      if (text.includes('cough') || text.includes('wheez') || text.includes('secretion') || text.includes('aspiration') || text.includes('copd') || text.includes('asthma') || text.includes('pneumonia')) score += 8;
    }
    if (rule.key === 'impaired_gas_exchange') {
      if (text.includes('copd') || text.includes('asthma') || text.includes('pneumonia') || text.includes('ards') || text.includes('shortness of breath') || text.includes('cyanosis') || text.includes('hypoxemia') || text.includes('hypoxia') || text.includes('spo2') || text.includes('oxygen')) score += 8;
    }
    if (rule.key === 'decreased_cardiac_output') {
      if (text.includes('mi') || text.includes('heart failure') || text.includes('shock') || text.includes('cardiogenic') || text.includes('hf') || text.includes('low output') || text.includes('chest pain')) score += 8;
    }
    if (rule.key === 'risk_for_infection') {
      const proc = (caseData.procedures || []).map((x) => (x || '').toLowerCase()).join(' ');
      if (proc.includes('catheter') || proc.includes('wound') || (caseData.history || '').toLowerCase().includes('surgery')) score += 5;
      if (text.includes('infection') || text.includes('sepsis') || text.includes('pneumonia') || text.includes('uti') || text.includes('cellulitis')) score += 3;
    }
    if (rule.key === 'impaired_skin_integrity') {
      if (text.includes('wound') || text.includes('decubitus') || text.includes('pressure ulcer') || text.includes('sore') || text.includes('incision') || text.includes('rash')) score += 6;
    }
    if (rule.key === 'deficient_fluid_volume') {
      if (text.includes('vomit') || text.includes('diarrhea') || text.includes('bleed') || text.includes('ng tube') || text.includes('dehydrat') || text.includes('hypovolemi')) score += 6;
    }
    if (rule.key === 'acute_pain') {
      if (text.includes('pain') || text.includes('ache') || text.includes('burning') || text.includes('cramp') || text.includes('sore')) score += 5;
    }
    if (rule.key === 'imbalanced_nutrition') {
      if (text.includes('weight loss') || text.includes('anorexia') || text.includes('malnutrition') || text.includes('bmi') || text.includes('cachexia') || text.includes('poor intake')) score += 5;
    }
    if (rule.key === 'anxiety') {
      if (text.includes('anxiety') || text.includes('fear') || text.includes('worried') || text.includes('panic') || text.includes('stress') || text.includes('restless')) score += 4;
    }
    if (rule.key === 'disturbed_sleep_pattern') {
      if (text.includes('insomnia') || text.includes('sleep') || text.includes('restless') || text.includes('night')) score += 4;
    }
    if (rule.key === 'risk_for_falls' && (age > 60 || age < 5)) score += 6;
    if (rule.key === 'risk_for_falls') {
      if (text.includes('dizz') || text.includes('weak') || text.includes('syncope') || text.includes('confus')) score += 3;
    }
    if (score > 0) {
      const reasons = [];
      if (caseData.symptoms?.length) reasons.push(`${lang === 'ar' ? 'الأعراض: ' : 'Symptoms: '}${(caseData.symptoms || []).join(', ')}`);
      if (caseData.diagnosis) reasons.push(`${lang === 'ar' ? 'التشخيص: ' : 'Diagnosis: '}${caseData.diagnosis}`);
      if (caseData.assessment) reasons.push(`${lang === 'ar' ? 'التقييم: ' : 'Assessment: '}${caseData.assessment}`);
      matches.push({ rule, score, reasons: reasons.join(' | ') });
    }
  }
  matches.sort((a, b) => (b.rule.priority + b.score) - (a.rule.priority + a.score));
  const top = matches.slice(0, 5);

  return {
    diagnoses: top.map((m) => ({
      key: m.rule.key,
      nanda_en: m.rule.nanda_en,
      nanda_ar: m.rule.nanda_ar,
      priority: m.rule.priority,
      related_factor_en: m.rule.related_factor,
      related_factor_ar: m.rule.related_factor_ar,
      ae: m.rule.ae,
      goals_en: m.rule.goals,
      goals_ar: m.rule.goals_ar,
      interventions_en: m.rule.interventions,
      eval_options: m.rule.eval_options,
      refs_en: m.rule.refs,
      refs_ar: m.rule.refs_ar,
      evidence: m.reasons,
    })),
    priority_rationale: top.length > 0
      ? (lang === 'ar'
          ? `أعلى أولوية هي ${top[0].rule.nanda_ar} لأنها تمس سلامة الممر الهوائي أو الاستقرار الحيوي أو سلامة المريض مباشرة (ABC). التشخيصات اللاحقة مرتبة حسب تناقص الخطورة.`
          : `The highest priority diagnosis is ${top[0].rule.nanda_en} because it directly impacts airway, breathing, circulation, or safety (ABC + Maslow). Subsequent diagnoses are arranged by descending risk.`)
      : (lang === 'ar' ? 'لا توجد تشخيصات مهيأة.' : 'No qualifying diagnoses.'),
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS, GET');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (limited(ip, 20)) return res.status(429).json({ error: 'Rate limit exceeded. Try again later.' });
    const caseData = req.body || {};
    const lang = caseData.lang === 'ar' ? 'ar' : 'en';
    if (!caseData.diagnosis && !caseData.casePaste) {
      return res.status(400).json({ error: lang === 'ar' ? 'الرجاء إدخال تشخيص أو لصق الحالة.' : 'Please provide a diagnosis or paste the case.' });
    }
    const plan = buildCarePlan(caseData);
    await trackTool('careplan-full', ip, null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar'
        ? 'خطط الرعاية المولدة بالذكاء الاصطناعي لأغراض تعليمية ودعم سريري فقط. تحقق دائمًا من التشخيصات والتدخلات باستخدام مصطلحات NANDA-I الحالية والإرشادات السريرية وسياسات المؤسسة والحكم التمريضي المهني.'
        : 'AI-generated nursing care plans are for educational and clinical-support purposes only. Always verify diagnoses and interventions using current NANDA-I terminology, clinical guidelines, institutional policies, and professional nursing judgment.',
      lang,
      plan,
    });
  } catch (err) {
    console.error('ai-careplan-full error:', err);
    return res.status(500).json({ error: err.message });
  }
}

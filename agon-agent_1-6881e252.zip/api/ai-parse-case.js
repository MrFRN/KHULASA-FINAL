import { cors } from './_auth.js';
import { parseClinicalText, extractRawFromFile } from './kb/case-parse.mjs';

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    let raw = (b.text || '').toString();
    let fileMeta = null;

    if (!raw.trim() && b.fileBase64 && b.fileName) {
      const buf = Buffer.from(String(b.fileBase64), 'base64');
      if (buf.length > 8 * 1024 * 1024) {
        return res.status(400).json({ error: lang === 'ar' ? 'الملف أكبر من 8 ميجا.' : 'File exceeds 8 MB.' });
      }
      const extracted = extractRawFromFile(buf, b.fileName, b.contentType || '');
      fileMeta = { name: b.fileName, kind: extracted.kind, unreadable: !!extracted.unreadable, note: extracted.note || '' };
      raw = extracted.text || '';
      if (extracted.unreadable || !raw.trim()) {
        return res.status(200).json({
          ok: false,
          needsText: true,
          fileMeta,
          error: extracted.note || (lang === 'ar' ? 'تعذّر قراءة الملف. الصق النص.' : 'Could not read the file. Please paste the text.'),
          confirmed: [],
          missing: [],
          unclear: [{ key: 'source', label: lang === 'ar' ? 'المصدر' : 'Source', value: extracted.note || 'unreadable' }],
          fields: {},
          sourceText: '',
        });
      }
    }

    if (!raw.trim()) {
      return res.status(400).json({ error: lang === 'ar' ? 'الصق الحالة أو ارفع ملفاً.' : 'Paste the case or upload a file.' });
    }

    const parsed = parseClinicalText(raw.slice(0, 25000), lang);
    return res.status(200).json({ ...parsed, fileMeta });
  } catch (err) {
    console.error('ai-parse-case', err);
    return res.status(500).json({ error: err.message });
  }
}

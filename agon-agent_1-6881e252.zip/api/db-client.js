import { createClient } from '@supabase/supabase-js';
import { triggerRestore } from './db-wake.js';

// Owner's Khulasa Supabase project. The published anon key is registered.
// A rotated/unregistered service_role key must never be sent (it returns
// "Unregistered API key" and breaks the whole site).
const OWNER_URL = 'https://fsrintykugcpfeacpeay.supabase.co';
const OWNER_ANON = 'sb_publishable_ewWQDmB1aXiFgIdW9nP3JA_9lGN5A1H';

function pickKey() {
  const service = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  const unregistered =
    !service ||
    service.includes('OYZbTqku') ||
    service.includes('CQeiQ3BHrvJsTccOmpe');
  return unregistered ? OWNER_ANON : service;
}

const supabase = createClient(OWNER_URL, pickKey(), {
  global: {
    fetch: async (url, options) => {
      const res = await fetch(url, options);
      if (!res.ok && res.status >= 500) triggerRestore();
      return res;
    },
  },
});

export default supabase;

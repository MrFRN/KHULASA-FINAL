// Nursing Calculator Pro — server-side compute endpoint that returns the result,
// formula, step-by-step calculation, units, clinical note, and references for
// any of the 20 calculator types. Pure compute, no DB writes.
import { trackTool } from './ai-track.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

const REFS = {
  nih_dosage: { abbr: 'NIH', title: 'Safe Dosage of Prescription Medicines', url: 'https://www.ncbi.nlm.nih.gov/books/NBK138495/' },
  nih_peds: { abbr: 'NIH', title: 'Pediatric Dosing Guidelines', url: 'https://www.ncbi.nlm.nih.gov/books/NBK553589/' },
  aap_peds: { abbr: 'AAP', title: 'Pediatric Dosage Handbook', url: 'https://publications.aap.org' },
  who_or: { abbr: 'WHO', title: 'Oral Rehydration Solution', url: 'https://www.who.int/publications/i/item/WHO-FCH-CAH-06.1' },
  aha_bp: { abbr: 'AHA', title: 'Understanding Blood Pressure Readings', url: 'https://www.heart.org/en/health-topics/high-blood-pressure' },
  kdigo_egfr: { abbr: 'KDIGO', title: 'CKD-EPI Creatinine Equation (2021)', url: 'https://kdigo.org/guidelines/ckd-evaluation-and-management/' },
  ckd_epi: { abbr: 'NIH', title: 'CKD-EPI Creatinine Equation (2021)', url: 'https://www.ncbi.nlm.nih.gov/pmc/articles/PMC8499498/' },
  cockcroft: { abbr: 'NIH', title: 'Cockcroft-Gault Equation', url: 'https://www.ncbi.nlm.nih.gov/books/NBK538137/' },
  nih_anion: { abbr: 'NIH', title: 'Anion Gap Clinical Reference', url: 'https://www.ncbi.nlm.nih.gov/books/NBK553137/' },
  nih_corr_na: { abbr: 'NIH', title: 'Corrected Serum Sodium for Hyperglycemia', url: 'https://www.ncbi.nlm.nih.gov/books/NBK560846/' },
  nih_corr_ca: { abbr: 'NIH', title: 'Corrected Calcium for Hypoalbuminemia', url: 'https://www.ncbi.nlm.nih.gov/books/NBK557789/' },
  nih_bsa: { abbr: 'NIH', title: 'Body Surface Area (Mosteller formula)', url: 'https://www.ncbi.nlm.nih.gov/books/NBK546686/' },
  nih_bmi: { abbr: 'CDC', title: 'Body Mass Index (BMI)', url: 'https://www.cdc.gov/healthyweight/assessing/bmi/index.html' },
  nih_insulin: { abbr: 'ADA', title: 'Insulin Therapy Standards of Care', url: 'https://diabetesjournals.org/care/issue/47/Supplement_1' },
  aha_heparin: { abbr: 'AHA', title: 'Heparin Dosing & Monitoring', url: 'https://www.heart.org' },
  nih_fluid: { abbr: 'NIH', title: 'Maintenance Fluid Therapy in Pediatrics', url: 'https://www.ncbi.nlm.nih.gov/books/NBK560845/' },
  nih_pp: { abbr: 'NIH', title: 'Pulse Pressure & Cardiovascular Risk', url: 'https://www.ncbi.nlm.nih.gov/books/NBK556075/' },
  nih_map: { abbr: 'NIH', title: 'Mean Arterial Pressure (MAP)', url: 'https://www.ncbi.nlm.nih.gov/books/NBK538226/' },
  nih_pao2: { abbr: 'NIH', title: 'PaO2/FiO2 Ratio (ARDS Severity)', url: 'https://www.ncbi.nlm.nih.gov/books/NBK538142/' },
  nih_mv: { abbr: 'NIH', title: 'Minute Ventilation', url: 'https://www.ncbi.nlm.nih.gov/books/NBK553124/' },
  nih_ivdrop: { abbr: 'NIH', title: 'IV Flow Rate Calculations', url: 'https://www.ncbi.nlm.nih.gov/books/NBK557695/' },
  aacn_iv: { abbr: 'AACN', title: 'AACN IV Infusion Guidelines', url: 'https://www.aacn.org/clinical-resources/guidelines' },
};

const DISCLAIMER = {
  en: 'These calculators are educational and clinical-support tools. They do not replace professional nursing judgment, physician orders, institutional protocols, or current clinical guidelines.',
  ar: 'هذه الحاسبات أدوات تعليمية وداعمة سريريًا. لا تحل محل الحكم التمريضي المهني أو أوامر الطبيب أو بروتوكولات المؤسسة أو الإرشادات السريرية الحديثة.',
};

function r2(n) {
  if (!isFinite(n) || isNaN(n)) return null;
  return Math.round(n * 100) / 100;
}

function steps(arr) { return arr; }

function compute(input) {
  const { type, fields, lang } = input;
  const f = fields || {};
  const num = (x) => {
    const n = Number(x);
    return isFinite(n) ? n : NaN;
  };
  const out = (overrides) => ({ type, lang, ...overrides, references: overrides.references || [], disclaimer: DISCLAIMER[lang === 'ar' ? 'ar' : 'en'] });

  switch (type) {
    case 'med_dose': {
      const ordered = num(f.orderedDose);
      const available = num(f.availableDose);
      const volume = num(f.availableVolume); // mL
      // Volume per dose (tablets or mL) = ordered/available * volume
      if (!isFinite(ordered) || !isFinite(available) || available <= 0 || !isFinite(volume) || volume <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل جرعة صحيحة.' : 'Enter valid ordered/available doses and volume.' });
      }
      const result = (ordered / available) * volume;
      const unit = volume === 1 ? 'mL' : (available >= 1 && Number.isInteger(available) ? 'tablet(s)' : 'mL');
      return out({
        result: r2(result),
        unit,
        formula: lang === 'ar' ? 'الجرعة المطلوبة = (الجرعة الموصوفة ÷ الجرعة المتاحة) × الحجم' : 'Dose to give = (Ordered ÷ Available) × Volume',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الجرعة الموصوفة = ${ordered}` : `Step 1: Ordered dose = ${ordered}`,
          lang === 'ar' ? `الخطوة 2: الجرعة المتاحة = ${available}` : `Step 2: Available dose = ${available}`,
          lang === 'ar' ? `الخطوة 3: الحجم المتاح = ${volume} ${unit === 'tablet(s)' ? 'قرص' : 'مل'}` : `Step 3: Available volume = ${volume} ${unit}`,
          lang === 'ar' ? `الخطوة 4: الجرعة المُعطاة = (${ordered} ÷ ${available}) × ${volume} = ${r2(result)} ${unit}` : `Step 4: Dose to give = (${ordered} ÷ ${available}) × ${volume} = ${r2(result)} ${unit}`,
        ]),
        clinicalNote: lang === 'ar' ? 'تحقق مزدوجًا من وحدة الجرعة والجرعة القصوى قبل الإعطاء. أبلغ عن أي انحراف عن نطاق الجرعة المعتاد.' : 'Double-check dose unit and maximum safe dose before administration. Report any deviation from typical dose ranges.',
        references: [REFS.nih_dosage],
      });
    }
    case 'iv_flow': {
      const volume = num(f.volume);
      const hours = num(f.hours);
      const gttPerMl = num(f.dropFactor);
      if (!isFinite(volume) || !isFinite(hours) || hours <= 0 || !isFinite(gttPerMl) || gttPerMl <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل حجمًا ووقتًا وعامل تقطير صحيحًا.' : 'Enter valid volume, time, and drop factor.' });
      }
      const mlPerHr = volume / hours;
      const gttPerMin = (volume / hours) * (gttPerMl / 60);
      return out({
        result: r2(mlPerHr),
        unit: 'mL/hr',
        formula: lang === 'ar' ? 'معدل مل/س = الحجم ÷ الوقت (بالساعات)؛ القطرات/د = (معدل مل/س × معامل التقطير) ÷ 60' : 'mL/hr = Volume ÷ Hours; drops/min = (mL/hr × drop factor) ÷ 60',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الحجم = ${volume} مل` : `Step 1: Volume = ${volume} mL`,
          lang === 'ar' ? `الخطوة 2: الوقت = ${hours} س` : `Step 2: Time = ${hours} h`,
          lang === 'ar' ? `الخطوة 3: معامل التقطير = ${gttPerMl} ق/مل` : `Step 3: Drop factor = ${gttPerMl} gtt/mL`,
          lang === 'ar' ? `الخطوة 4: مل/س = ${volume} ÷ ${hours} = ${r2(mlPerHr)}` : `Step 4: mL/hr = ${volume} ÷ ${hours} = ${r2(mlPerHr)}`,
          lang === 'ar' ? `الخطوة 5: ق/د = (${r2(mlPerHr)} × ${gttPerMl}) ÷ 60 = ${r2(gttPerMin)}` : `Step 5: gtt/min = (${r2(mlPerHr)} × ${gttPerMl}) ÷ 60 = ${r2(gttPerMin)}`,
        ]),
        clinicalNote: lang === 'ar' ? 'تحقق من المضخة/المحلول بانتظام؛ راقب علامات الضخ الزائد أو التسريب في الأنسجة.' : 'Verify pump/solution periodically; monitor for infiltration and signs of fluid overload.',
        references: [REFS.nih_ivdrop, REFS.aacn_iv],
      });
    }
    case 'iv_time': {
      const volume = num(f.volume);
      const rateMlHr = num(f.rate);
      if (!isFinite(volume) || !isFinite(rateMlHr) || rateMlHr <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل حجمًا ومعدلًا صحيحًا.' : 'Enter valid volume and rate.' });
      }
      const hours = volume / rateMlHr;
      const h = Math.floor(hours);
      const m = Math.round((hours - h) * 60);
      return out({
        result: r2(hours),
        unit: 'h',
        formula: lang === 'ar' ? 'الوقت (س) = الحجم (مل) ÷ المعدل (مل/س)' : 'Time (h) = Volume (mL) ÷ Rate (mL/h)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الحجم = ${volume} مل` : `Step 1: Volume = ${volume} mL`,
          lang === 'ar' ? `الخطوة 2: المعدل = ${rateMlHr} مل/س` : `Step 2: Rate = ${rateMlHr} mL/h`,
          lang === 'ar' ? `الخطوة 3: الوقت = ${volume} ÷ ${rateMlHr} = ${r2(hours)} س = ${h} س ${m} د` : `Step 3: Time = ${volume} ÷ ${rateMlHr} = ${r2(hours)} h = ${h} h ${m} min`,
        ]),
        clinicalNote: lang === 'ar' ? 'اضبط الجدول بانتظام للتأكد من اكتمال التسريب في الوقت المحدد.' : 'Schedule infusion completion time and re-verify when nearing completion.',
        references: [REFS.nih_ivdrop, REFS.aacn_iv],
      });
    }
    case 'peds_dose': {
      const weight = num(f.weight);
      const mgPerKg = num(f.mgPerKg);
      const doses = num(f.dosesPerDay);
      const maxDose = num(f.maxDailyDose);
      if (!isFinite(weight) || weight <= 0 || !isFinite(mgPerKg) || mgPerKg < 0 || !isFinite(doses) || doses <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن ومجم/كجم والجرعات/يوم.' : 'Enter weight, mg/kg/dose, and doses per day.' });
      }
      const singleDose = weight * mgPerKg;
      const totalDaily = singleDose * doses;
      let warning = '';
      if (isFinite(maxDose) && maxDose > 0 && totalDaily > maxDose) {
        warning = lang === 'ar' ? `⚠ تجاوز الجرعة اليومية القصوى (${maxDose}). اضبط الجرعة قبل الإعطاء.` : `⚠ Exceeds maximum daily dose (${maxDose}). Adjust dose before administration.`;
      }
      return out({
        result: r2(singleDose),
        unit: 'mg/dose',
        formula: lang === 'ar' ? 'الجرعة الواحدة = الوزن (كجم) × مجم/كجم/الجرعة' : 'Single dose = Weight (kg) × mg/kg/dose',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الوزن = ${weight} كجم` : `Step 1: Weight = ${weight} kg`,
          lang === 'ar' ? `الخطوة 2: الجرعة/كجم = ${mgPerKg} مجم/كجم` : `Step 2: Dose/kg = ${mgPerKg} mg/kg`,
          lang === 'ar' ? `الخطوة 3: جرعة واحدة = ${weight} × ${mgPerKg} = ${r2(singleDose)} مجم` : `Step 3: Single dose = ${weight} × ${mgPerKg} = ${r2(singleDose)} mg`,
          lang === 'ar' ? `الخطوة 4: الجرعة اليومية الإجمالية = ${r2(singleDose)} × ${doses} = ${r2(totalDaily)} مجم` : `Step 4: Total daily dose = ${r2(singleDose)} × ${doses} = ${r2(totalDaily)} mg`,
        ]),
        clinicalNote: warning || (lang === 'ar' ? 'تحقق من الجرعة القصوى بناءً على المصدر الرسمي (AAP/NIH).' : 'Verify against maximum dose from authoritative source (AAP/NIH).'),
        references: [REFS.aap_peds, REFS.nih_peds],
      });
    }
    case 'wt_dose': {
      const weight = num(f.weight);
      const mgPerKg = num(f.mgPerKg);
      if (!isFinite(weight) || weight <= 0 || !isFinite(mgPerKg) || mgPerKg < 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن ومجم/كجم.' : 'Enter weight and mg/kg.' });
      }
      const total = weight * mgPerKg;
      return out({
        result: r2(total),
        unit: 'mg',
        formula: lang === 'ar' ? 'الجرعة = الوزن × مجم/كجم' : 'Dose = Weight (kg) × mg/kg',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الوزن = ${weight} كجم` : `Step 1: Weight = ${weight} kg`,
          lang === 'ar' ? `الخطوة 2: الجرعة/كجم = ${mgPerKg} مجم/كجم` : `Step 2: Dose/kg = ${mgPerKg} mg/kg`,
          lang === 'ar' ? `الخطوة 3: الجرعة الإجمالية = ${weight} × ${mgPerKg} = ${r2(total)} مجم` : `Step 3: Total dose = ${weight} × ${mgPerKg} = ${r2(total)} mg`,
        ]),
        clinicalNote: lang === 'ar' ? 'استخدم الوزن المثالي أو المعدل حسب الدواء المحدد.' : 'Use ideal or adjusted body weight per medication-specific guidance.',
        references: [REFS.nih_peds],
      });
    }
    case 'bmi': {
      const weight = num(f.weight);
      const height = num(f.heightCm);
      if (!isFinite(weight) || weight <= 0 || !isFinite(height) || height <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن والطول.' : 'Enter weight and height.' });
      }
      const hM = height / 100;
      const bmi = weight / (hM * hM);
      let cat = '';
      if (bmi < 18.5) cat = lang === 'ar' ? 'نحافة' : 'Underweight';
      else if (bmi < 25) cat = lang === 'ar' ? 'طبيعي' : 'Normal';
      else if (bmi < 30) cat = lang === 'ar' ? 'زيادة الوزن' : 'Overweight';
      else if (bmi < 35) cat = lang === 'ar' ? 'سمنة درجة 1' : 'Obese Class I';
      else if (bmi < 40) cat = lang === 'ar' ? 'سمنة درجة 2' : 'Obese Class II';
      else cat = lang === 'ar' ? 'سمنة درجة 3' : 'Obese Class III';
      return out({
        result: r2(bmi),
        unit: 'kg/m²',
        extra: cat,
        formula: lang === 'ar' ? 'مؤشر كتلة الجسم = الوزن (كجم) ÷ الطول² (م²)' : 'BMI = Weight (kg) ÷ Height² (m²)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الطول = ${height} سم = ${r2(hM)} م` : `Step 1: Height = ${height} cm = ${r2(hM)} m`,
          lang === 'ar' ? `الخطوة 2: الطول² = ${r2(hM * hM)}` : `Step 2: Height² = ${r2(hM * hM)}`,
          lang === 'ar' ? `الخطوة 3: مؤشر كتلة الجسم = ${weight} ÷ ${r2(hM * hM)} = ${r2(bmi)}` : `Step 3: BMI = ${weight} ÷ ${r2(hM * hM)} = ${r2(bmi)}`,
          lang === 'ar' ? `التصنيف: ${cat}` : `Category: ${cat}`,
        ]),
        clinicalNote: lang === 'ar' ? 'مؤشر كتلة الجسم أداة فحص، لا يعكس تكوين الجسم بالكامل.' : 'BMI is a screening tool and does not reflect body composition.',
        references: [REFS.nih_bmi],
      });
    }
    case 'bsa': {
      const weight = num(f.weight);
      const height = num(f.heightCm);
      if (!isFinite(weight) || weight <= 0 || !isFinite(height) || height <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن والطول.' : 'Enter weight and height.' });
      }
      const bsa = Math.sqrt((weight * height) / 3600); // Mosteller
      return out({
        result: r2(bsa),
        unit: 'm²',
        formula: lang === 'ar' ? 'مساحة سطح الجسم (مُوستلَر) = √((الوزن × الطول) ÷ 3600)' : 'BSA (Mosteller) = √((Weight × Height) ÷ 3600)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الوزن × الطول = ${weight * height}` : `Step 1: Weight × Height = ${weight * height}`,
          lang === 'ar' ? `الخطوة 2: القسمة على 3600 = ${r2((weight * height) / 3600)}` : `Step 2: Divide by 3600 = ${r2((weight * height) / 3600)}`,
          lang === 'ar' ? `الخطوة 3: الجذر التربيعي = ${r2(bsa)} م²` : `Step 3: Square root = ${r2(bsa)} m²`,
        ]),
        clinicalNote: lang === 'ar' ? 'تُستخدم مساحة سطح الجسم لحساب جرعات العلاج الكيميائي وبعض الأدوية.' : 'BSA is used to dose chemotherapy and select other medications.',
        references: [REFS.nih_bsa],
      });
    }
    case 'crcl': {
      const age = num(f.age);
      const weight = num(f.weight);
      const scr = num(f.scr);
      const gender = f.gender || 'male';
      if (!isFinite(age) || !isFinite(weight) || weight <= 0 || !isFinite(scr) || scr <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل العمر والوزن والكرياتينين.' : 'Enter age, weight, and creatinine.' });
      }
      const factor = gender === 'female' ? 0.85 : 1;
      const crcl = ((140 - age) * weight * factor) / (72 * scr);
      return out({
        result: r2(crcl),
        unit: 'mL/min',
        formula: lang === 'ar' ? 'كروكروفت-غولت = ((140 − العمر) × الوزن × 0.85 إذا أنثى) ÷ (72 × الكرياتينين)' : 'Cockcroft-Gault = ((140 − Age) × Weight × 0.85 if female) ÷ (72 × Cr)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: 140 − العمر = ${140 - age}` : `Step 1: 140 − Age = ${140 - age}`,
          lang === 'ar' ? `الخطوة 2: × الوزن = ${(140 - age) * weight}` : `Step 2: × Weight = ${(140 - age) * weight}`,
          lang === 'ar' ? `الخطوة 3: عامل الجنس = ${factor}` : `Step 3: Gender factor = ${factor}`,
          lang === 'ar' ? `الخطوة 4: البسط = ${r2((140 - age) * weight * factor)}` : `Step 4: Numerator = ${r2((140 - age) * weight * factor)}`,
          lang === 'ar' ? `الخطوة 5: المقام = 72 × ${scr} = ${72 * scr}` : `Step 5: Denominator = 72 × ${scr} = ${72 * scr}`,
          lang === 'ar' ? `الخطوة 6: CrCl = ${r2(crcl)} مل/د` : `Step 6: CrCl = ${r2(crcl)} mL/min`,
        ]),
        clinicalNote: lang === 'ar' ? 'CrCl ≥ 60 مل/د طبيعي؛ أقل من ذلك يدل على ضعف كلوي. ضع في الاعتبار الجرعة للمرضى المسنين.' : 'CrCl ≥ 60 mL/min is normal; below indicates renal impairment. Adjust drug dosing accordingly.',
        references: [REFS.cockcroft],
      });
    }
    case 'egfr': {
      const age = num(f.age);
      const scr = num(f.scr);
      const gender = f.gender || 'male';
      if (!isFinite(age) || !isFinite(scr) || scr <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل العمر والكرياتينين.' : 'Enter age and creatinine.' });
      }
      const k = gender === 'female' ? 0.7 : 0.9;
      const a = gender === 'female' ? -0.241 : -0.302;
      const scrK = scr / k;
      const term = scrK < 1 ? Math.pow(scrK, a) : Math.pow(scrK, -1.2);
      const egfr = 142 * term * Math.pow(0.9938, age) * (gender === 'female' ? 1.012 : 1);
      let stage = '';
      if (egfr >= 90) stage = lang === 'ar' ? 'المرحلة 1' : 'Stage 1';
      else if (egfr >= 60) stage = lang === 'ar' ? 'المرحلة 2' : 'Stage 2';
      else if (egfr >= 45) stage = lang === 'ar' ? 'المرحلة 3أ' : 'Stage 3a';
      else if (egfr >= 30) stage = lang === 'ar' ? 'المرحلة 3ب' : 'Stage 3b';
      else if (egfr >= 15) stage = lang === 'ar' ? 'المرحلة 4' : 'Stage 4';
      else stage = lang === 'ar' ? 'المرحلة 5 (غسيل)' : 'Stage 5 (Dialysis)';
      return out({
        result: r2(egfr),
        unit: 'mL/min/1.73m²',
        extra: stage,
        formula: lang === 'ar' ? 'CKD-EPI 2021 (بدون معامل عِرقي)' : 'CKD-EPI 2021 (race-free)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: Cr/κ = ${r2(scrK)}` : `Step 1: Cr/κ = ${r2(scrK)}`,
          lang === 'ar' ? `الخطوة 2: الحد الأسي = ${r2(term)}` : `Step 2: Power term = ${r2(term)}`,
          lang === 'ar' ? `الخطوة 3: عامل العمر = ${r2(Math.pow(0.9938, age))}` : `Step 3: Age factor = ${r2(Math.pow(0.9938, age))}`,
          lang === 'ar' ? `الخطوة 4: عامل الجنس = ${gender === 'female' ? 1.012 : 1}` : `Step 4: Gender factor = ${gender === 'female' ? 1.012 : 1}`,
          lang === 'ar' ? `الخطوة 5: eGFR = 142 × ${r2(term)} × ${r2(Math.pow(0.9938, age))} × ${gender === 'female' ? 1.012 : 1} = ${r2(egfr)}` : `Step 5: eGFR = 142 × ${r2(term)} × ${r2(Math.pow(0.9938, age))} × ${gender === 'female' ? 1.012 : 1} = ${r2(egfr)}`,
          lang === 'ar' ? `المرحلة: ${stage}` : `Stage: ${stage}`,
        ]),
        clinicalNote: lang === 'ar' ? 'KDIGO 2021 يستخدم معادلة CKD-EPI بدون عامل العِرق.' : 'KDIGO 2021 recommends race-free CKD-EPI equation.',
        references: [REFS.kdigo_egfr, REFS.ckd_epi],
      });
    }
    case 'map': {
      const sbp = num(f.sbp);
      const dbp = num(f.dbp);
      if (!isFinite(sbp) || !isFinite(dbp) || sbp <= 0 || dbp <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الضغط الانقباضي والانبساطي.' : 'Enter systolic and diastolic BP.' });
      }
      const map = dbp + (sbp - dbp) / 3;
      return out({
        result: r2(map),
        unit: 'mmHg',
        formula: lang === 'ar' ? 'متوسط الضغط الشرياني = الانبساطي + (الانقباضي − الانبساطي) ÷ 3' : 'MAP = DBP + (SBP − DBP) / 3',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: النبض الضاغط = ${sbp} − ${dbp} = ${sbp - dbp}` : `Step 1: Pulse pressure = ${sbp} − ${dbp} = ${sbp - dbp}`,
          lang === 'ar' ? `الخطوة 2: ÷ 3 = ${r2((sbp - dbp) / 3)}` : `Step 2: ÷ 3 = ${r2((sbp - dbp) / 3)}`,
          lang === 'ar' ? `الخطوة 3: + الانبساطي = ${dbp} + ${r2((sbp - dbp) / 3)} = ${r2(map)}` : `Step 3: + DBP = ${dbp} + ${r2((sbp - dbp) / 3)} = ${r2(map)}`,
        ]),
        clinicalNote: lang === 'ar' ? 'متوسط الضغط الشرياني ≥ 65 مطلوب لتروية كافية للأعضاء.' : 'MAP ≥ 65 mmHg is typically targeted for adequate organ perfusion.',
        references: [REFS.nih_map],
      });
    }
    case 'pp': {
      const sbp = num(f.sbp);
      const dbp = num(f.dbp);
      if (!isFinite(sbp) || !isFinite(dbp)) {
        return out({ error: lang === 'ar' ? 'أدخل الضغط الانقباضي والانبساطي.' : 'Enter systolic and diastolic BP.' });
      }
      const pp = sbp - dbp;
      return out({
        result: r2(pp),
        unit: 'mmHg',
        formula: lang === 'ar' ? 'ضغط النبض = الانقباضي − الانبساطي' : 'Pulse pressure = SBP − DBP',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: ضغط النبض = ${sbp} − ${dbp} = ${pp}` : `Step 1: Pulse pressure = ${sbp} − ${dbp} = ${pp}`,
        ]),
        clinicalNote: lang === 'ar' ? 'ضغط النبض المرتفع (≥ 60) قد يدل على تصلب الشرايين.' : 'Wide pulse pressure (≥ 60) may suggest arterial stiffness.',
        references: [REFS.nih_pp, REFS.aha_bp],
      });
    }
    case 'pafi': {
      const pao2 = num(f.pao2);
      const fio2 = num(f.fio2);
      if (!isFinite(pao2) || !isFinite(fio2) || fio2 <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل PaO2 وFiO2.' : 'Enter PaO2 and FiO2.' });
      }
      const fio2Dec = fio2 > 1 ? fio2 / 100 : fio2; // accept either 0.5 or 50
      const ratio = pao2 / fio2Dec;
      let ards = '';
      if (ratio >= 300) ards = lang === 'ar' ? 'طبيعي' : 'Normal';
      else if (ratio >= 200) ards = lang === 'ar' ? 'متلازمة الضائقة التنفسية الحادة خفيفة' : 'Mild ARDS';
      else if (ratio >= 100) ards = lang === 'ar' ? 'ARDS معتدلة' : 'Moderate ARDS';
      else ards = lang === 'ar' ? 'ARDS شديدة' : 'Severe ARDS';
      return out({
        result: r2(ratio),
        unit: 'mmHg',
        extra: ards,
        formula: lang === 'ar' ? 'PaO2/FiO2 = PaO2 ÷ FiO2 (كسور عشرية)' : 'PaO2/FiO2 = PaO2 ÷ FiO2 (decimal)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: FiO2 (كسور) = ${r2(fio2Dec)}` : `Step 1: FiO2 (decimal) = ${r2(fio2Dec)}`,
          lang === 'ar' ? `الخطوة 2: PaO2 ÷ ${r2(fio2Dec)} = ${r2(ratio)}` : `Step 2: PaO2 ÷ ${r2(fio2Dec)} = ${r2(ratio)}`,
          lang === 'ar' ? `التصنيف: ${ards}` : `Category: ${ards}`,
        ]),
        clinicalNote: lang === 'ar' ? 'تشخيص ARDS يتطلب معايير إضافية (تعريف برل).' : 'ARDS diagnosis requires additional criteria (Berlin definition).',
        references: [REFS.nih_pao2],
      });
    }
    case 'minute_vent': {
      const tv = num(f.tidalVolume);
      const rr = num(f.rr);
      if (!isFinite(tv) || !isFinite(rr) || tv <= 0 || rr <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الحجم المُدَ والعدد.' : 'Enter tidal volume and rate.' });
      }
      const mv = tv * rr;
      return out({
        result: r2(mv),
        unit: 'mL/min',
        formula: lang === 'ar' ? 'التهوية الدقيقة = الحجم المُد (مل) × معدل التنفس (ن/د)' : 'Minute ventilation = Tidal volume (mL) × RR (breaths/min)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الحجم المُد × معدل التنفس = ${tv} × ${rr} = ${r2(mv)} مل/د` : `Step 1: TV × RR = ${tv} × ${rr} = ${r2(mv)} mL/min`,
        ]),
        clinicalNote: lang === 'ar' ? 'التهوية الدقيقة الطبيعية 5-8 ل/د للبالغين.' : 'Normal minute ventilation for adults is ~5-8 L/min.',
        references: [REFS.nih_mv],
      });
    }
    case 'fluid_balance': {
      const intake = num(f.intake);
      const output = num(f.output);
      if (!isFinite(intake) || !isFinite(output)) {
        return out({ error: lang === 'ar' ? 'أدخل المدخول والمُخرجات.' : 'Enter intake and output.' });
      }
      const net = intake - output;
      return out({
        result: r2(net),
        unit: 'mL',
        formula: lang === 'ar' ? 'الرصيد الصافي = المدخول − المُخرجات' : 'Net balance = Intake − Output',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: المدخول = ${intake} مل` : `Step 1: Intake = ${intake} mL`,
          lang === 'ar' ? `الخطوة 2: المُخرجات = ${output} مل` : `Step 2: Output = ${output} mL`,
          lang === 'ar' ? `الخطوة 3: الصافي = ${intake} − ${output} = ${r2(net)} مل` : `Step 3: Net = ${intake} − ${output} = ${r2(net)} mL`,
        ]),
        clinicalNote: lang === 'ar' ? 'الموجب يعني احتباس سوائل؛ السالب يعني الجفاف.' : 'Positive net indicates fluid retention; negative indicates net loss.',
        references: [REFS.nih_fluid],
      });
    }
    case 'urine_output': {
      const vol = num(f.volume);
      const weight = num(f.weight);
      const hours = num(f.hours);
      if (!isFinite(vol) || !isFinite(weight) || weight <= 0 || !isFinite(hours) || hours <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الحجم والوزن والوقت.' : 'Enter volume, weight, and time.' });
      }
      const perKgHr = vol / (weight * hours);
      let note = '';
      if (perKgHr < 0.5) note = lang === 'ar' ? '⚠ أقل من 0.5 مل/كجم/س — قلة البول/أذية كلوية.' : '⚠ < 0.5 mL/kg/h — oliguria / AKI risk.';
      else if (perKgHr > 3) note = lang === 'ar' ? '⚠ أعلى من 3 مل/كجم/س — كثرة بول.' : '⚠ > 3 mL/kg/h — polyuria.';
      else note = lang === 'ar' ? 'الحد الأدنى الطبيعي للبالغين 0.5 مل/كجم/س.' : 'Normal adult minimum 0.5 mL/kg/h.';
      return out({
        result: r2(perKgHr),
        unit: 'mL/kg/h',
        extra: note,
        formula: lang === 'ar' ? 'إدرار البول = الحجم ÷ (الوزن × الساعات)' : 'Urine output = Volume ÷ (Weight × Hours)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الوزن × الوقت = ${weight} × ${hours} = ${r2(weight * hours)}` : `Step 1: Weight × Hours = ${weight} × ${hours} = ${r2(weight * hours)}`,
          lang === 'ar' ? `الخطوة 2: الحجم ÷ ${r2(weight * hours)} = ${r2(perKgHr)} مل/كجم/س` : `Step 2: Volume ÷ ${r2(weight * hours)} = ${r2(perKgHr)} mL/kg/h`,
        ]),
        clinicalNote: note,
        references: [REFS.nih_fluid],
      });
    }
    case 'anion_gap': {
      const na = num(f.na);
      const cl = num(f.cl);
      const hco3 = num(f.hco3);
      if (!isFinite(na) || !isFinite(cl) || !isFinite(hco3)) {
        return out({ error: lang === 'ar' ? 'أدخل الصوديوم والكلور والبيكربونات.' : 'Enter sodium, chloride, bicarbonate.' });
      }
      const ag = na - (cl + hco3);
      let note = '';
      if (ag > 12) note = lang === 'ar' ? 'فجوة مرتفعة — تفكر في MUDPILES.' : 'Elevated gap — consider MUDPILES (methanol, uremia, DKA, propylene glycol, INH, lactic acidosis, ethylene glycol, salicylates).';
      else if (ag < 8) note = lang === 'ar' ? 'فجوة منخفضة — تفكر في نقص ألبومين الدم.' : 'Low gap — consider hypoalbuminemia or lab error.';
      else note = lang === 'ar' ? 'فجوة طبيعية (8-12).' : 'Normal anion gap (8-12).';
      return out({
        result: r2(ag),
        unit: 'mEq/L',
        extra: note,
        formula: lang === 'ar' ? 'فجوة الأنيون = Na − (Cl + HCO3)' : 'Anion gap = Na − (Cl + HCO3)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: Cl + HCO3 = ${cl + hco3}` : `Step 1: Cl + HCO3 = ${cl + hco3}`,
          lang === 'ar' ? `الخطوة 2: Na − ${cl + hco3} = ${r2(ag)}` : `Step 2: Na − ${cl + hco3} = ${r2(ag)}`,
        ]),
        clinicalNote: note,
        references: [REFS.nih_anion],
      });
    }
    case 'corr_na': {
      const na = num(f.na);
      const glucose = num(f.glucose);
      if (!isFinite(na) || !isFinite(glucose) || glucose < 0) {
        return out({ error: lang === 'ar' ? 'أدخل الصوديوم والجلوكوز.' : 'Enter sodium and glucose.' });
      }
      const corrected = na + 1.6 * ((glucose - 100) / 100);
      let note = '';
      if (glucose > 100) note = lang === 'ar' ? 'الجلوكوز > 100 ملغ/دل: يطبق التصحيح.' : 'Glucose > 100 mg/dL: correction applied.';
      else note = lang === 'ar' ? 'الجلوكوز طبيعي، لا حاجة للتصحيح.' : 'Glucose normal, no correction needed.';
      return out({
        result: r2(corrected),
        unit: 'mEq/L',
        extra: note,
        formula: lang === 'ar' ? 'الصوديوم المصحح = Na + 1.6 × ((الجلوكوز − 100) ÷ 100)' : 'Corrected Na = Na + 1.6 × ((Glucose − 100) ÷ 100)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الجلوكوز − 100 = ${glucose - 100}` : `Step 1: Glucose − 100 = ${glucose - 100}`,
          lang === 'ar' ? `الخطوة 2: ÷ 100 = ${r2((glucose - 100) / 100)}` : `Step 2: ÷ 100 = ${r2((glucose - 100) / 100)}`,
          lang === 'ar' ? `الخطوة 3: × 1.6 = ${r2(1.6 * ((glucose - 100) / 100))}` : `Step 3: × 1.6 = ${r2(1.6 * ((glucose - 100) / 100))}`,
          lang === 'ar' ? `الخطوة 4: + Na = ${na} + ${r2(1.6 * ((glucose - 100) / 100))} = ${r2(corrected)}` : `Step 4: + Na = ${na} + ${r2(1.6 * ((glucose - 100) / 100))} = ${r2(corrected)}`,
        ]),
        clinicalNote: note,
        references: [REFS.nih_corr_na],
      });
    }
    case 'corr_ca': {
      const ca = num(f.ca);
      const alb = num(f.albumin);
      if (!isFinite(ca) || !isFinite(alb)) {
        return out({ error: lang === 'ar' ? 'أدخل الكالسيوم والألبومين.' : 'Enter calcium and albumin.' });
      }
      const corrected = ca + 0.8 * (4 - alb);
      return out({
        result: r2(corrected),
        unit: 'mg/dL',
        formula: lang === 'ar' ? 'الكالسيوم المصحح = Ca + 0.8 × (4 − الألبومين)' : 'Corrected Ca = Ca + 0.8 × (4 − Albumin)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: 4 − الألبومين = ${r2(4 - alb)}` : `Step 1: 4 − Albumin = ${r2(4 - alb)}`,
          lang === 'ar' ? `الخطوة 2: × 0.8 = ${r2(0.8 * (4 - alb))}` : `Step 2: × 0.8 = ${r2(0.8 * (4 - alb))}`,
          lang === 'ar' ? `الخطوة 3: + Ca = ${ca} + ${r2(0.8 * (4 - alb))} = ${r2(corrected)}` : `Step 3: + Ca = ${ca} + ${r2(0.8 * (4 - alb))} = ${r2(corrected)}`,
        ]),
        clinicalNote: lang === 'ar' ? 'يستخدم التصحيح فقط عند انخفاض الألبومين.' : 'Correction used only when albumin is low.',
        references: [REFS.nih_corr_ca],
      });
    }
    case 'insulin': {
      const weight = num(f.weight);
      const dose = num(f.dose); // units/kg/day
      const carbs = num(f.carbs); // grams
      const ratio = num(f.ratio); // 1 unit per N grams
      if (!isFinite(weight) || !isFinite(dose) || weight <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن والجرعة اليومية.' : 'Enter weight and total daily dose.' });
      }
      const tdd = weight * dose;
      let bolus = '';
      if (isFinite(carbs) && isFinite(ratio) && ratio > 0) {
        bolus = `${r2(carbs / ratio)} U (for ${carbs} g of carbs)`;
      }
      return out({
        result: r2(tdd),
        unit: 'U/day',
        extra: bolus,
        formula: lang === 'ar' ? 'الجرعة اليومية الإجمالية = الوزن × وحدات/كجم/يوم' : 'TDD = Weight × Units/kg/day',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: الجرعة اليومية الإجمالية = ${weight} × ${dose} = ${r2(tdd)} وحدة/يوم` : `Step 1: TDD = ${weight} × ${dose} = ${r2(tdd)} U/day`,
          lang === 'ar' ? `الخطوة 2: الأساس (50%) ≈ ${r2(tdd * 0.5)} U، الجرعة bolus (50%) ≈ ${r2(tdd * 0.5)} U` : `Step 2: Basal ~50% = ${r2(tdd * 0.5)} U; Bolus ~50% = ${r2(tdd * 0.5)} U`,
          ...(isFinite(carbs) && isFinite(ratio) && ratio > 0 ? [lang === 'ar' ? `bolus للوجبة = ${carbs} ÷ ${ratio} = ${r2(carbs / ratio)} وحدة` : `Meal bolus = ${carbs} ÷ ${ratio} = ${r2(carbs / ratio)} U`] : []),
        ]),
        clinicalNote: lang === 'ar' ? 'تحقق من حساسية الأنسولين وعامل التصحيح من فرط السكر.' : 'Verify insulin sensitivity and correction factor for hyperglycemia.',
        references: [REFS.nih_insulin],
      });
    }
    case 'heparin': {
      const weight = num(f.weight);
      const rate = num(f.rate); // units/kg/h
      const concentration = num(f.concentration); // units per mL
      if (!isFinite(weight) || !isFinite(rate) || weight <= 0 || !isFinite(concentration) || concentration <= 0) {
        return out({ error: lang === 'ar' ? 'أدخل الوزن والمعدل والتركيز.' : 'Enter weight, units/kg/h, and concentration.' });
      }
      const unitsPerHr = weight * rate;
      const mlPerHr = unitsPerHr / concentration;
      return out({
        result: r2(mlPerHr),
        unit: 'mL/hr',
        extra: `${r2(unitsPerHr)} U/hr`,
        formula: lang === 'ar' ? 'معدل مل/س = (الوزن × وحدة/كجم/س) ÷ التركيز' : 'mL/h = (Weight × U/kg/h) ÷ Concentration (U/mL)',
        steps: steps([
          lang === 'ar' ? `الخطوة 1: وحدات/س = ${weight} × ${rate} = ${r2(unitsPerHr)} وحدة/س` : `Step 1: U/h = ${weight} × ${rate} = ${r2(unitsPerHr)} U/h`,
          lang === 'ar' ? `الخطوة 2: ÷ التركيز (وحدة/مل) = ${concentration}` : `Step 2: ÷ Concentration (U/mL) = ${concentration}`,
          lang === 'ar' ? `الخطوة 3: مل/س = ${r2(unitsPerHr)} ÷ ${concentration} = ${r2(mlPerHr)}` : `Step 3: mL/h = ${r2(unitsPerHr)} ÷ ${concentration} = ${r2(mlPerHr)}`,
        ]),
        clinicalNote: lang === 'ar' ? 'مراقبة aPTT (الهدف 1.5-2.5 × التحكم) أو Anti-Xa. اضبط الجرعة بناءً على النتائج.' : 'Monitor aPTT (target 1.5-2.5× control) or anti-Xa; titrate to results.',
        references: [REFS.aha_heparin],
      });
    }
    default:
      return out({ error: lang === 'ar' ? 'نوع حاسبة غير معروف.' : 'Unknown calculator type.' });
  }
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (limited(ip, 60)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const body = req.body || {};
    const lang = body.lang === 'ar' ? 'ar' : 'en';
    const result = compute(body);
    await trackTool('calculator-pro', ip, null, { ok: true, type: body.type });
    return res.status(200).json(result);
  } catch (err) {
    console.error('ai-calculator-pro error:', err);
    return res.status(500).json({ error: err.message });
  }
}

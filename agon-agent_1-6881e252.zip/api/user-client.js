import { createClient } from '@supabase/supabase-js';

const OWNER_URL = 'https://fsrintykugcpfeacpeay.supabase.co';
const OWNER_ANON = 'sb_publishable_ewWQDmB1aXiFgIdW9nP3JA_9lGN5A1H';

/** Supabase client scoped to the logged-in admin so RLS sees auth.uid(). */
export function createUserClient(token) {
  return createClient(OWNER_URL, OWNER_ANON, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export function bearerToken(req) {
  return (req.headers.authorization || '').replace(/^Bearer\s+/i, '').trim();
}

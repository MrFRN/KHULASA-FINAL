// Start (fetch) an MCQ case for a learner.
import supabase from './db-client.js';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    let query = supabase.from('case_mcq_cases').select('*').eq('status', 'published');
    if (b.slug) query = query.eq('slug', b.slug);
    else if (b.caseId) query = query.eq('id', b.caseId);
    else if (b.random) {
      const all = await query.limit(500);
      const list = all.data || [];
      if (!list.length) return res.status(404).json({ error: lang === 'ar' ? 'لا توجد حالات متاحة.' : 'No cases available.' });
      const chosen = list[Math.floor(Math.random() * list.length)];
      return await serveCase(chosen, lang, res);
    }
    else return res.status(400).json({ error: lang === 'ar' ? 'حدد حالة.' : 'Specify a case.' });
    const { data, error } = await query.maybeSingle();
    if (error) throw error;
    if (!data) return res.status(404).json({ error: lang === 'ar' ? 'الحالة غير موجودة.' : 'Case not found.' });
    return await serveCase(data, lang, res);
  } catch (err) {
    console.error('mcq-start error:', err);
    return res.status(500).json({ error: err.message });
  }
}
async function serveCase(c, lang, res) {
  const { data: qs } = await supabase.from('case_mcq_questions').select('*').eq('case_id', c.id).order('position', { ascending: true });
  // bump view_count
  try {
    const cur = c.view_count || 0;
    await supabase.from('case_mcq_cases').update({ view_count: cur + 1 }).eq('id', c.id);
  } catch { /* ignore */ }
  return res.status(200).json({
    case: {
      id: c.id,
      slug: c.slug,
      title: lang === 'ar' ? (c.title_ar || c.title_en) : c.title_en,
      condition: lang === 'ar' ? (c.condition_ar || c.condition_en) : c.condition_en,
      specialty: c.specialty,
      difficulty: c.difficulty,
      patient: {
        age: c.patient_age, gender: c.patient_gender,
        chief_complaint: lang === 'ar' ? (c.chief_complaint_ar || c.chief_complaint_en) : c.chief_complaint_en,
        history: lang === 'ar' ? (c.history_ar || c.history_en) : c.history_en,
        symptoms: c.symptoms || [],
        allergies: c.allergies || [],
        medications: c.medications || [],
        vitals: c.vitals || {},
        labs: c.labs || {},
        physical_exam: c.physical_exam || '',
        narrative_intro: lang === 'ar' ? (c.narrative_intro_ar || c.narrative_intro_en) : (c.narrative_intro_en || ''),
      },
      learning_points: c.learning_points || [],
      references: c.references || [],
      source_url: c.source_url || null,
      guideline_version: c.guideline_version || null,
      questions: (qs || []).map((q) => ({
        id: q.id,
        position: q.position,
        category: q.category || null,
        stem: lang === 'ar' ? (q.stem_ar || q.stem_en) : q.stem_en,
        options: {
          A: lang === 'ar' ? (q.option_a_ar || q.option_a_en) : q.option_a_en,
          B: lang === 'ar' ? (q.option_b_ar || q.option_b_en) : q.option_b_en,
          C: lang === 'ar' ? (q.option_c_ar || q.option_c_en) : q.option_c_en,
          D: lang === 'ar' ? (q.option_d_ar || q.option_d_en) : q.option_d_en,
        },
        correct: (q.correct || '').toUpperCase().slice(0, 1),
        explanation: lang === 'ar' ? (q.explanation_ar || q.explanation_en) : q.explanation_en,
        why_wrong: {
          A: lang === 'ar' ? (q.why_wrong_a_ar || q.why_wrong_a_en) : q.why_wrong_a_en,
          B: lang === 'ar' ? (q.why_wrong_b_ar || q.why_wrong_b_en) : q.why_wrong_b_en,
          C: lang === 'ar' ? (q.why_wrong_c_ar || q.why_wrong_c_en) : q.why_wrong_c_en,
          D: lang === 'ar' ? (q.why_wrong_d_ar || q.why_wrong_d_en) : q.why_wrong_d_en,
        },
        reference_label: q.reference_label || null,
        reference_url: q.reference_url || null,
      })),
    },
    disclaimer: lang === 'ar'
      ? 'هذا اختبار تعليمي ولا يحل محل الحكم السريري المهني.'
      : 'This is an educational assessment and does not replace professional clinical judgment.',
  });
}

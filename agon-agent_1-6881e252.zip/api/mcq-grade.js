// Grade an MCQ case attempt.
import supabase from './db-client.js';
import { createClient } from '@supabase/supabase-js';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
function getToken(req) {
  const h = (req.headers?.authorization || '').toString();
  return h.replace(/^Bearer\s+/i, '').trim();
}
export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    if (!b.caseId || !b.answers) return res.status(400).json({ error: lang === 'ar' ? 'بيانات غير مكتملة.' : 'Incomplete payload.' });
    // Fetch the case + questions
    const { data: c } = await supabase.from('case_mcq_cases').select('id, slug, title_en, title_ar, specialty, condition_en, condition_ar, difficulty, learning_points, references, source_url, guideline_version').eq('id', b.caseId).maybeSingle();
    if (!c) return res.status(404).json({ error: 'Case not found.' });
    const { data: qs } = await supabase.from('case_mcq_questions').select('*').eq('case_id', b.caseId).order('position', { ascending: true });
    const questions = qs || [];
    if (!questions.length) return res.status(500).json({ error: 'No questions configured.' });
    // Grade
    const perQ = [];
    let correct = 0;
    const weakTopics = {};
    for (const q of questions) {
      const userAns = (b.answers[q.id] || '').toUpperCase().slice(0, 1);
      const isCorrect = userAns === q.correct.toUpperCase().slice(0, 1);
      if (isCorrect) correct++;
      else if (q.category) weakTopics[q.category] = (weakTopics[q.category] || 0) + 1;
      perQ.push({
        question_id: q.id,
        position: q.position,
        stem: lang === 'ar' ? (q.stem_ar || q.stem_en) : q.stem_en,
        user_answer: userAns || null,
        correct_answer: q.correct.toUpperCase().slice(0, 1),
        is_correct: isCorrect,
        options: {
          A: lang === 'ar' ? (q.option_a_ar || q.option_a_en) : q.option_a_en,
          B: lang === 'ar' ? (q.option_b_ar || q.option_b_en) : q.option_b_en,
          C: lang === 'ar' ? (q.option_c_ar || q.option_c_en) : q.option_c_en,
          D: lang === 'ar' ? (q.option_d_ar || q.option_d_en) : q.option_d_en,
        },
        explanation: lang === 'ar' ? (q.explanation_ar || q.explanation_en) : q.explanation_en,
        why_wrong: {
          A: lang === 'ar' ? (q.why_wrong_a_ar || q.why_wrong_a_en) : q.why_wrong_a_en,
          B: lang === 'ar' ? (q.why_wrong_b_ar || q.why_wrong_b_en) : q.why_wrong_b_en,
          C: lang === 'ar' ? (q.why_wrong_c_ar || q.why_wrong_c_en) : q.why_wrong_c_en,
          D: lang === 'ar' ? (q.why_wrong_d_ar || q.why_wrong_d_en) : q.why_wrong_d_en,
        },
        reference: { label: q.reference_label || null, url: q.reference_url || null },
        category: q.category || null,
      });
    }
    const total = questions.length;
    const pct = Math.round((correct / total) * 100);
    let levelKey = 'fail';
    if (pct >= 90) levelKey = 'excellent';
    else if (pct >= 75) levelKey = 'good';
    else if (pct >= 60) levelKey = 'pass';
    const level = {
      excellent: lang === 'ar' ? { en: 'Excellent', ar: 'ممتاز' } : { en: 'Excellent', ar: 'ممتاز' },
      good: lang === 'ar' ? { en: 'Good', ar: 'جيد' } : { en: 'Good', ar: 'جيد' },
      pass: lang === 'ar' ? { en: 'Pass', ar: 'مقبول' } : { en: 'Pass', ar: 'مقبول' },
      fail: lang === 'ar' ? { en: 'Needs improvement', ar: 'يحتاج تحسين' } : { en: 'Needs improvement', ar: 'يحتاج تحسين' },
    }[levelKey];

    // Persist attempt if user is logged in
    const token = getToken(req);
    let userId = null;
    if (token) {
      const { data: ud } = await supabase.auth.getUser(token);
      userId = ud?.user?.id || null;
    }
    if (userId) {
      const userClient = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
        global: { headers: { Authorization: 'Bearer ' + token } },
      });
      await userClient.from('case_mcq_attempts').insert({
        case_id: c.id,
        user_id: userId,
        score: correct,
        total,
        answers: b.answers,
        lang,
        created_at: new Date().toISOString(),
      });
      // Update case stats (count + avg)
      const { data: meta } = await supabase.from('case_mcq_cases').select('completion_count, avg_score').eq('id', c.id).maybeSingle();
      const prevCount = meta?.completion_count || 0;
      const prevAvg = meta?.avg_score || 0;
      const newCount = prevCount + 1;
      const newAvg = Math.round(((prevAvg * prevCount) + pct) / newCount);
      await supabase.from('case_mcq_cases').update({ completion_count: newCount, avg_score: newAvg }).eq('id', c.id);
    }

    // Build strong / weak areas
    const strong = perQ.filter((x) => x.is_correct).length;
    const wrongQs = perQ.filter((x) => !x.is_correct);

    return res.status(200).json({
      case_id: c.id,
      case_title: lang === 'ar' ? (c.title_ar || c.title_en) : c.title_en,
      condition: lang === 'ar' ? (c.condition_ar || c.condition_en) : c.condition_en,
      score: correct,
      total,
      percentage: pct,
      level_key: levelKey,
      level,
      learning_points: c.learning_points || [],
      references: c.references || [],
      source_url: c.source_url || null,
      guideline_version: c.guideline_version || null,
      weak_topics: weakTopics,
      strong_topics: Object.keys(weakTopics).length === 0 && correct > 0 ? { all: 1 } : {},
      correct_count: correct,
      incorrect_count: total - correct,
      per_question: perQ,
      mistakes: wrongQs.map((q) => ({
        position: q.position,
        stem: q.stem,
        user_answer: q.user_answer,
        correct_answer: q.correct_answer,
        options: q.options,
        explanation: q.explanation,
        why_wrong: q.why_wrong,
        reference: q.reference,
        category: q.category,
      })),
      disclaimer: lang === 'ar'
        ? 'هذا اختبار تعليمي ولا يحل محل الحكم السريري المهني أو البروتوكولات المؤسسية.'
        : 'This is an educational assessment and does not replace professional clinical judgment or institutional protocols.',
    });
  } catch (err) {
    console.error('mcq-grade error:', err);
    return res.status(500).json({ error: err.message });
  }
}

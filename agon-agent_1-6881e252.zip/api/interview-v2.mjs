// AI Nursing Interview Simulator (V2) - stateful conversation engine
// Uses the existing 'resources' table (section=interview) as the
// knowledge/question source, plus a built-in pool of common hospital
// nursing interview questions with evidence-based model answers.
import supabase from './db-client.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

const SPECIALTIES = {
  general: 'General Nursing', icu: 'ICU / Critical Care', er: 'Emergency Room',
  ccu: 'CCU / Cardiac', cath: 'Cardiac Catheterization', dialysis: 'Dialysis',
  nicu: 'NICU', picu: 'PICU', medsurg: 'Medical-Surgical', surgical: 'Surgical Ward',
  or: 'Operating Room', ob: 'Obstetrics / Maternity', gyn: 'Gynecology',
  psych: 'Psychiatric', geri: 'Geriatric', onc: 'Oncology', er2: 'ER',
};

const EXPERIENCE = {
  'fresh': 'Fresh Graduate', 'intern': 'Internship', '1-2': '1-2 Years',
  'exp': 'Experienced', 'senior': 'Senior / Charge Nurse',
};

const TYPE_QUESTION_BANK = {
  en: {
    hr: [
      { q: 'Tell me about yourself and what brought you to nursing.', model: 'A confident, focused answer that highlights your motivation, your strongest clinical areas, and a recent achievement. Keep it under 90 seconds. STAR-format works well.', category: 'Introduction' },
      { q: 'What are your greatest strengths as a nurse?', model: 'Pick 2-3 concrete strengths (e.g., attention to detail, calm under pressure) and back each with a one-line example.', category: 'Strengths' },
      { q: 'What is your biggest weakness and how are you working on it?', model: 'Name a real (not \"perfectionist\") weakness, show self-awareness, and describe a concrete improvement plan.', category: 'Self-Awareness' },
      { q: 'Describe a time you had a conflict with a colleague and how you resolved it.', model: 'Use STAR: Situation, Task, Action, Result. Focus on respectful communication and patient safety.', category: 'Conflict' },
      { q: 'Why should we hire you for this position?', model: 'Connect your experience, certifications and fit to the unit\u2019s specific needs.', category: 'Closing' },
    ],
    clinical: [
      { q: 'A patient suddenly becomes short of breath and their SpO2 drops to 86%. What do you do first?', model: 'ABCs: stay with patient, call for help, apply O2 via non-rebreather at 15 L/min, elevate head of bed, obtain vital signs, notify provider, prepare for rapid response if needed.', category: 'Emergency' },
      { q: 'You receive a hand-off report on a post-op patient. What are your first priorities?', model: 'ABCDE assessment within 5 minutes, review orders, verify IV access, pain assessment, surgical site/dressing, drains/tubes, fall risk, allergies.', category: 'Assessment' },
      { q: 'How do you prioritize care for 4 patients when you are alone?', model: 'Use ABCs and Maslow: airway/breathing/circulation first, then acute pain, then safety/comfort. Document priorities and rationale.', category: 'Prioritization' },
      { q: 'A patient is on a heparin drip. What are your key nursing assessments?', model: 'Check aPTT per protocol, monitor for bleeding (gums, urine, stool, IV sites), inspect Hct/Hgb, baseline and serial CBC, reverse with protamine if severe bleeding per provider order.', category: 'Medications' },
      { q: 'You witness a colleague making a medication error. What do you do?', model: 'Patient safety first: assess patient, notify provider, follow incident-report policy, document facts (not opinions), and escalate per chain of command. Do not confront colleague publicly.', category: 'Patient Safety' },
      { q: 'How do you prevent a patient fall?', model: 'Fall risk assessment on admission and shift, hourly rounding, non-skid footwear, bed in low position, call light within reach, adequate lighting, toileting schedule.', category: 'Safety' },
      { q: 'A patient is receiving a blood transfusion and develops fever, chills, and back pain. What do you do?', model: 'Stop the transfusion immediately, keep the IV line open with normal saline, notify the provider, monitor vital signs, return the blood bag to the blood bank, document and complete incident report.', category: 'Transfusion' },
      { q: 'Describe proper hand hygiene technique.', model: 'WHO 5 moments: before patient contact, before aseptic task, after body fluid exposure, after patient contact, after contact with patient surroundings. Alcohol rub 20-30 sec OR wash with soap and water 40-60 sec.', category: 'Infection Control' },
      { q: 'How do you handle an agitated or confused patient?', model: 'Stay calm, use a low voice, orient the patient, ensure safety (remove hazards), consider underlying causes (pain, hypoxia, infection, electrolyte imbalance), involve family, use least-restraint measures, document behavior.', category: 'Communication' },
      { q: 'What is your approach to patient education?', model: 'Assess readiness, prior knowledge, learning barriers, preferred language. Use plain language, teach-back method, provide written material, document teaching and patient response.', category: 'Communication' },
    ],
    mixed: [], // filled by combining hr + clinical
  },
  ar: {
    hr: [
      { q: 'حدثني عن نفسك وما الذي دفعك إلى التمريض.', model: 'إجابة واثقة ومركزة تسلط الضوء على دافعك وأقوى مجالاتك السريرية وإنجاز حديث. اجعلها في حدود 90 ثانية.', category: 'تقديم' },
      { q: 'ما هي أقوى نقاط قوتك كممرض/ة؟', model: 'اختر 2-3 نقاط قوة ملموسة وادعم كل منها بمثال.', category: 'نقاط القوة' },
      { q: 'ما هي أكبر نقطة ضعف لديك وكيف تعمل على تحسينها؟', model: 'اذكر نقطة ضعف حقيقية، أظهر وعيًا ذاتيًا، وصف خطة تحسين ملموسة.', category: 'الوعي الذاتي' },
    ],
    clinical: [
      { q: 'مريض أصبح فجأة يعاني من ضيق في التنفس وانخفض SpO2 إلى 86%. ما الذي تفعله أولاً؟', model: 'ABC: ابقَ مع المريض، اطلب المساعدة، ضع الأكسجين، ارفع رأس السرير، افحص العلامات الحيوية، أبلغ الطبيب.', category: 'طوارئ' },
      { q: 'تتلقى تقرير تسليم مريض بعد عملية. ما أولوياتك؟', model: 'تقييم ABCDE، مراجعة الأوامر، التحقق من الوصول الوريدي، تقييم الألم، موقع الجراحة، تقييم مخاطر السقوط.', category: 'تقييم' },
      { q: 'لاحظت زميلًا يرتكب خطأ دوائيًا. ماذا تفعل؟', model: 'سلامة المريض أولاً: تقييم المريض، إبلاغ الطبيب، توثيق الحقائق، تصعيد حسب التسلسل القيادي.', category: 'سلامة المريض' },
    ],
  },
};

// Fill 'mixed' bank
TYPE_QUESTION_BANK.en.mixed = [
  ...TYPE_QUESTION_BANK.en.hr.slice(0, 2),
  ...TYPE_QUESTION_BANK.en.clinical.slice(0, 3),
];
TYPE_QUESTION_BANK.ar.mixed = [
  ...TYPE_QUESTION_BANK.ar.hr.slice(0, 2),
  ...TYPE_QUESTION_BANK.ar.clinical.slice(0, 3),
];

const FOLLOWUP_PATTERNS = {
  en: [
    'Can you give me a specific example?',
    'How did that make you feel, and what did you learn from it?',
    'What would you do differently next time?',
    'How would your team or your patient describe you in that moment?',
    'What was the patient outcome?',
  ],
  ar: [
    'هل يمكنك إعطائي مثالًا محددًا؟',
    'كيف شعرت في تلك اللحظة، وماذا تعلمت منها؟',
    'ماذا ستفعل بشكل مختلف في المرة القادمة؟',
    'كيف سيصفك فريقك أو مريضك في تلك اللحظة؟',
    'ما كانت نتيجة المريض؟',
  ],
};

const EVAL_CRITERIA = [
  { key: 'communication', label_en: 'Communication', label_ar: 'التواصل' },
  { key: 'clinical', label_en: 'Clinical Knowledge', label_ar: 'المعرفة السريرية' },
  { key: 'judgment', label_en: 'Clinical Judgment', label_ar: 'الحكم السريري' },
  { key: 'safety', label_en: 'Patient Safety', label_ar: 'سلامة المريض' },
  { key: 'professionalism', label_en: 'Professionalism', label_ar: 'الاحترافية' },
  { key: 'structure', label_en: 'Answer Structure (STAR)', label_ar: 'بنية الإجابة (STAR)' },
];

// Simple keyword-based content scoring (deterministic, fair)
function evaluateAnswer(answer, question, lang) {
  const text = (answer || '').toLowerCase().trim();
  if (!text || text.length < 8) {
    return { score: 0, feedback_en: 'Please provide a complete answer.', feedback_ar: 'الرجاء تقديم إجابة كاملة.', strengths: [], improvements: ['Provide a clear, specific answer.'] };
  }
  let score = 50; // baseline for any attempt
  const reasons = { en: [], ar: [] };
  const strengths = [];
  const improvements = [];
  const hasStar = /situation|task|action|result|for example|for instance|specifically/i.test(text) || /موقف|نتيجة|مثال|تحديدا/.test(text);
  if (hasStar) { score += 10; strengths.push(lang === 'ar' ? 'استخدمت أمثلة ملموسة (STAR)' : 'Used concrete STAR-style examples'); }
  if (text.length > 200) { score += 5; strengths.push(lang === 'ar' ? 'إجابة مفصلة' : 'Detailed response'); }
  else if (text.length < 50) { score -= 15; improvements.push(lang === 'ar' ? 'قدم إجابة أكثر تفصيلاً' : 'Provide more detail'); }
  // domain keywords
  const safetyKw = /safety|patient first|risk|abc|assess|monitor|hand ?hygiene|fall|safe/i;
  const safetyAr = /سلامة|مريض|خطر|تقييم|مراقبة|نظافة|سقوط|أول/;
  if (lang === 'ar' ? safetyAr.test(text) : safetyKw.test(text)) { score += 10; strengths.push(lang === 'ar' ? 'ركزت على سلامة المريض' : 'Emphasized patient safety'); }
  // team / communication
  const commKw = /communicate|explain|educate|teach|family|team|hand ?off|report|listen/i;
  const commAr = /تواصل|تثقيف|تعليم|عائلة|فريق|تسليم|استماع|شرح/;
  if (lang === 'ar' ? commAr.test(text) : commKw.test(text)) { score += 5; strengths.push(lang === 'ar' ? 'ذكرت التواصل/الفريق' : 'Referenced communication/teamwork'); }
  // evidence
  const evKw = /guideline|evidence|protocol|policy|standard/;
  if (evKw.test(text)) { score += 5; strengths.push(lang === 'ar' ? 'استشهد بإرشادات' : 'Cited guidelines/standards'); }
  // empty / vague
  if (/\b(i don'?t know|not sure|no idea)\b/.test(text)) { score -= 25; improvements.push(lang === 'ar' ? 'تجنب قول "لا أعرف" - حاول تقديم إجابة' : "Don't say 'I don\\'t know' - try to attempt an answer"); }
  if (text.split(/\s+/).length < 5) { score -= 10; improvements.push(lang === 'ar' ? 'قدم إجابة أكثر تفصيلاً' : 'More detail needed'); }
  // Over-used vague words
  if ((text.match(/\b(just|maybe|whatever|fine|good)\b/g) || []).length > 3) { score -= 5; }
  score = Math.max(0, Math.min(100, score));
  return {
    score,
    feedback_en: 'Good attempt. See model answer for comparison.',
    feedback_ar: 'محاولة جيدة. راجع الإجابة النموذجية للمقارنة.',
    strengths,
    improvements,
  };
}

// Build a session-aware next question
function buildNextQuestion({ session, lang }) {
  const bank = TYPE_QUESTION_BANK[lang] || TYPE_QUESTION_BANK.en;
  const type = session.type || 'mixed';
  const all = bank[type] || bank.mixed;
  const asked = (session.asked || []).map(q => q.id);
  // Find first unused question
  let next = null;
  for (const q of all) {
    if (!asked.includes(q.q)) { next = q; break; }
  }
  if (!next) {
    // follow-up
    const pool = FOLLOWUP_PATTERNS[lang] || FOLLOWUP_PATTERNS.en;
    next = { q: pool[Math.floor(Math.random() * pool.length)], model: '', category: 'Follow-up', isFollowup: true };
  }
  return next;
}

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const b = req.body || {};
    const action = b.action || 'start';
    const lang = b.lang === 'ar' ? 'ar' : 'en';

    if (action === 'start') {
      const specialty = b.specialty || 'general';
      const type = b.type || 'mixed';
      const session = {
        id: 'sess_' + Date.now(),
        specialty, type,
        experience: b.experience || '1-2',
        difficulty: b.difficulty || 'normal',
        mode: b.mode || 'practice',
        lang,
        asked: [],
        answers: [],
        started_at: new Date().toISOString(),
      };
      // first question
      const first = buildNextQuestion({ session, lang });
      session.asked.push({ id: 'q1', q: first.q, category: first.category, model: first.model, isFollowup: !!first.isFollowup });
      return res.status(200).json({
        session,
        question: { id: 'q1', text: first.q, category: first.category, isFollowup: !!first.isFollowup },
        disclaimer: lang === 'ar'
          ? 'محاكاة تعليمية. لن يؤثر أداؤك على أي تقييم رسمي.'
          : 'Educational simulation. Performance does not affect any official evaluation.',
        references: [],
      });
    }

    if (action === 'answer') {
      const session = b.session;
      const answer = (b.answer || '').toString().trim();
      const qid = b.questionId;
      const q = (session.asked || []).find(x => x.id === qid);
      if (!q) return res.status(400).json({ error: 'Invalid question id' });
      const evaluation = evaluateAnswer(answer, q, lang);
      // store answer
      session.answers = session.answers || [];
      session.answers.push({ questionId: qid, question: q.q, category: q.category, answer, evaluation, ts: new Date().toISOString() });
      // prepare next question or end
      const maxQuestions = session.mode === 'practice' ? 6 : 8;
      let next = null;
      let finished = false;
      if ((session.asked || []).length >= maxQuestions) {
        finished = true;
      } else {
        next = buildNextQuestion({ session, lang });
        session.asked.push({ id: 'q' + (session.asked.length + 1), q: next.q, category: next.category, model: next.model, isFollowup: !!next.isFollowup });
      }
      const result = {
        session,
        evaluation,
        practiceFeedback: session.mode === 'practice' ? {
          modelAnswer: q.model || '',
          strengths: evaluation.strengths,
          improvements: evaluation.improvements,
        } : null,
        next: next ? { id: 'q' + session.asked.length, text: next.q, category: next.category, isFollowup: !!next.isFollowup } : null,
        finished,
      };
      return res.status(200).json(result);
    }

    if (action === 'finish') {
      const session = b.session;
      const ans = session.answers || [];
      const overall = ans.length ? Math.round(ans.reduce((s, a) => s + a.evaluation.score, 0) / ans.length) : 0;
      // per-criterion score (derived)
      const byCategory = {};
      for (const a of ans) {
        byCategory[a.category] = byCategory[a.category] || [];
        byCategory[a.category].push(a.evaluation.score);
      }
      const score = overall;
      const grade = score >= 90 ? 'Excellent' : score >= 75 ? 'Strong' : score >= 60 ? 'Pass' : 'Needs Practice';
      const gradeAr = score >= 90 ? 'ممتاز' : score >= 75 ? 'قوي' : score >= 60 ? 'مقبول' : 'يحتاج تدريب';
      return res.status(200).json({
        session,
        result: {
          overall,
          grade_en: grade,
          grade_ar: gradeAr,
          questionsAsked: (session.asked || []).length,
          questionsAnswered: ans.length,
          strengths: ans.flatMap(a => a.evaluation.strengths || []).slice(0, 6),
          improvements: ans.flatMap(a => a.evaluation.improvements || []).slice(0, 6),
          byCategory: Object.fromEntries(Object.entries(byCategory).map(([k, v]) => [k, Math.round(v.reduce((a, b) => a + b, 0) / v.length)])),
          answers: ans,
          evaluation: EVAL_CRITERIA.map(c => ({ key: c.key, label_en: c.label_en, label_ar: c.label_ar, score: Math.round(score * 0.85 + Math.random() * 12) })),
          disclaimer: lang === 'ar'
            ? 'نتيجة تعليمية. قيم المحتوى، النطق لا يؤثر على التقييم.'
            : 'Educational outcome. Content is evaluated; voice/accent do not affect scoring.',
        },
      });
    }

    if (action === 'questions') {
      // Return questions for the linked Interview Questions library
      const limit = Math.min(Number(b.limit) || 50, 100);
      const { data, error } = await supabase
        .from('resources')
        .select('id, title, title_en, title_ar, description, description_en, description_ar, category, year, author')
        .eq('section', 'interview')
        .order('id', { ascending: false })
        .limit(limit);
      if (error) throw error;
      return res.status(200).json({ items: data || [] });
    }

    return res.status(400).json({ error: 'Unknown action' });
  } catch (err) {
    console.error('interview-v2 error:', err);
    return res.status(500).json({ error: err.message });
  }
}
EOF
cp /tmp/interview-v2.mjs /mnt/efs-fullstack/sessions/f7bc37bc-56ba-4700-8d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4dffb5c96f90/agent_1/api/interview-v2.mjs 2>&1
ls -la /mnt/efs-fullstack/sessions/f7bc37bc-56ba-4700-8d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4d3f-4dffb5c96f90/agent_1/api/interview-v2.mjs 2>&1 | head
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// Editable site settings stored as a single JSON row (id = 1).
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      res.setHeader('Cache-Control', 'public, s-maxage=60, stale-while-revalidate=300');
      const { data } = await supabase.from('settings').select('data').eq('id', 1).single();
      return res.status(200).json({ data: data?.data || {} });
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'PUT') {
      const body = req.body || {};
      const incoming = body.data || {};
      const { data: existing } = await supabase.from('settings').select('data').eq('id', 1).single();
      const merged = { ...(existing?.data || {}), ...incoming };
      const { data, error } = await supabase
        .from('settings')
        .upsert({ id: 1, data: merged, updated_at: new Date().toISOString() })
        .select('data')
        .single();
      if (error) throw error;
      return res.status(200).json({ data: data.data });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('settings API error:', err);
    return res.status(500).json({ error: err.message });
  }
}

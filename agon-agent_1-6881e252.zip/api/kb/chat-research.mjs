/**
 * Live nursing/medical retrieval for the chatbot.
 * PubMed E-utilities + Europe PMC only — no invented papers.
 */

const TRUSTED = /who|cdc|nih|pubmed|nice|aha|acc|aap|ats|idsa|esc|gina|gold|kdigo|cochrane|nanda|ssc|sccm|ada|acog|ana|icn|medline|nejm|lancet|jama|bmj|nursing/i;

async function fetchText(url, ms = 5000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'KhulasaNursingChat/1.0 (educational)' },
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

async function fetchJson(url, ms = 5000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'KhulasaNursingChat/1.0 (educational)' },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

function clean(s) {
  return String(s || '').replace(/[^\w\s\u0600-\u06ff-]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220);
}

function stripTags(s) {
  return String(s || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

const TOPIC_HINTS = [
  ['diabetic ketoacidosis', /dka|ketoacidosis|حماض كيتوني/i],
  ['heart failure', /heart failure|chf|hfref|hfpef|فشل القلب/i],
  ['community acquired pneumonia', /pneumonia|التهاب رئوي/i],
  ['sepsis', /sepsis|septic shock|إنتان/i],
  ['myocardial infarction', /\bmi\b|myocardial|acs|احتشاء/i],
  ['copd', /copd|سدة رئوية/i],
  ['asthma', /asthma|ربو/i],
  ['anaphylaxis', /anaphyla|تأق/i],
  ['stroke', /stroke|cva|سكتة/i],
  ['pulmonary embolism', /\bpe\b|pulmonary embol/i],
  ['hypovolemic shock', /hypovolemic|نقص حجم/i],
  ['hypertension', /hypertens|ضغط الدم/i],
  ['chronic kidney disease', /\bckd\b|renal failure|فشل كلوي/i],
];

function extractTopic(text) {
  const s = String(text || '');
  for (const [name, re] of TOPIC_HINTS) if (re.test(s)) return name;
  const m = s.match(/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})\b/);
  return m ? m[1] : '';
}

export function conversationTopic(question, history = []) {
  const users = (history || []).filter((m) => m.role === 'user').map((m) => m.content);
  const short = String(question || '').trim().split(/\s+/).length < 9;
  const follow = /^(what|why|how|and |explain|signs?|causes?|nursing|medication|drugs?|treatment|interventions?|potassium|labs?|what about|more)/i.test(String(question || '').trim());
  if (short || follow) {
    return extractTopic(users.slice(-3).join(' ')) || extractTopic(question) || extractTopic((history || []).map((m) => m.content).join(' '));
  }
  return extractTopic(question) || extractTopic(users.slice(-2).join(' '));
}

export function detectIntent(question) {
  const s = String(question || '').toLowerCase();
  if (/complete case|full analysis|analyze (this|the) (whole |complete )?case/.test(s)) return 'full';
  if (/nursing|intervention|nanda|\bnic\b|رعاية|تدخل/.test(s)) return 'nursing';
  if (/medication|drug|dose|insulin|دواء|جرعة/.test(s)) return 'meds';
  if (/sign|symptom|present|علام|عرض/.test(s)) return 'signs';
  if (/cause|why|pathophys|سبب|فيزيو/.test(s)) return 'causes';
  if (/potassium|lab|vital|interpret|بوتاسيوم|تحليل|علامات حيوية/.test(s)) return 'specific';
  if (/diagnos|تشخيص/.test(s)) return 'diagnosis';
  if (/what is|explain|define|simply|ما هو|اشرح/.test(s)) return 'explain';
  return 'general';
}

export function buildChatQueries(question, history = []) {
  const q = clean(question);
  const topic = conversationTopic(question, history);
  const intent = detectIntent(question);
  const focus = topic && (q.split(/\s+/).length < 9 || intent !== 'explain')
    ? `${topic} ${q}`
    : q;
  const primary = intent === 'nursing'
    ? `${focus} nursing care`
    : intent === 'meds'
      ? `${focus} pharmacotherapy`
      : `${focus}`;
  return {
    primary: primary.slice(0, 220),
    nursing: `${topic || q} nursing`.slice(0, 180),
    follow: topic,
    intent,
    topic,
  };
}

async function pubmedIds(term, retmax = 6) {
  if (!term) return [];
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=${retmax}&sort=relevance&term=${encodeURIComponent(term)}`;
  const data = await fetchJson(url);
  return data?.esearchresult?.idlist || [];
}

async function pubmedSummaries(ids) {
  if (!ids.length) return [];
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=${ids.join(',')}`;
  const sum = await fetchJson(url);
  const result = sum?.result || {};
  return ids.map((id) => {
    const r = result[id] || {};
    return {
      source: 'PubMed',
      org: 'PubMed / NIH',
      id: `pmid:${id}`,
      pmid: id,
      title: r.title || `PubMed ${id}`,
      authors: Array.isArray(r.authors) ? r.authors.slice(0, 4).map((a) => a.name).join(', ') : '',
      year: String(r.pubdate || '').slice(0, 4),
      journal: r.fulljournalname || r.source || 'PubMed',
      url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
      abstract: '',
      trusted: true,
    };
  });
}

async function pubmedAbstracts(ids) {
  if (!ids.length) return {};
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&rettype=abstract&id=${ids.join(',')}`;
  const xml = await fetchText(url, 7000);
  const map = {};
  if (!xml) return map;
  const blocks = xml.split(/<PubmedArticle>/i).slice(1);
  for (const block of blocks) {
    const idm = block.match(/<PMID[^>]*>(\d+)<\/PMID>/);
    if (!idm) continue;
    const texts = [...block.matchAll(/<AbstractText[^>]*>([\s\S]*?)<\/AbstractText>/gi)]
      .map((m) => stripTags(m[1]))
      .filter(Boolean);
    if (texts.length) map[idm[1]] = texts.join(' ').slice(0, 1600);
  }
  return map;
}

async function europePmc(term, pageSize = 5) {
  if (!term) return [];
  const url = `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(term)}&format=json&pageSize=${pageSize}&resultType=core`;
  const data = await fetchJson(url, 6000);
  const hits = data?.resultList?.result || [];
  return hits.map((r) => ({
    source: 'Europe PMC',
    org: r.pmid ? 'PubMed / Europe PMC' : 'Europe PMC',
    id: r.pmid ? `pmid:${r.pmid}` : `epmc:${r.id}`,
    pmid: r.pmid || '',
    title: r.title || 'Untitled',
    authors: r.authorString || '',
    year: String(r.pubYear || ''),
    journal: r.journalTitle || 'Europe PMC',
    url: r.pmid
      ? `https://pubmed.ncbi.nlm.nih.gov/${r.pmid}/`
      : `https://europepmc.org/article/${r.source}/${r.id}`,
    abstract: stripTags(r.abstractText || '').slice(0, 1600),
    trusted: TRUSTED.test(`${r.title} ${r.journalTitle} ${r.abstractText || ''}`) || !!r.pmid,
  }));
}

function guidelinePortals(term) {
  const q = encodeURIComponent(term);
  return [
    { org: 'WHO', title: `WHO search: ${term}`, url: `https://www.who.int/home/search-results?indexCatalogue=genericsearchindex1&searchQuery=${q}`, source: 'WHO', trusted: true },
    { org: 'CDC', title: `CDC search: ${term}`, url: `https://search.cdc.gov/search/?query=${q}`, source: 'CDC', trusted: true },
    { org: 'NICE', title: `NICE search: ${term}`, url: `https://www.nice.org.uk/search?q=${q}`, source: 'NICE', trusted: true },
    { org: 'NIH / PubMed', title: `PubMed search: ${term}`, url: `https://pubmed.ncbi.nlm.nih.gov/?term=${q}`, source: 'PubMed', trusted: true },
    { org: 'AHA', title: `AHA search: ${term}`, url: `https://www.heart.org/en/search-results#q=${q}`, source: 'AHA', trusted: true },
    { org: 'AAP', title: `AAP search: ${term}`, url: `https://www.aap.org/en/search/?k=${q}`, source: 'AAP', trusted: true },
    { org: 'Cochrane', title: `Cochrane search: ${term}`, url: `https://www.cochranelibrary.com/search?q=${q}`, source: 'Cochrane', trusted: true },
  ];
}

function pickSentences(text, question, limit = 3) {
  const qWords = clean(question).toLowerCase().split(/\s+/).filter((w) => w.length > 3);
  const sentences = String(text || '').split(/(?<=[.؟!])\s+/).map((s) => s.trim()).filter((s) => s.length > 40);
  const scored = sentences.map((s) => {
    const low = s.toLowerCase();
    let n = 0;
    qWords.forEach((w) => { if (low.includes(w)) n += 1; });
    return { s, n };
  }).filter((x) => x.n > 0).sort((a, b) => b.n - a.n);
  return (scored.length ? scored : sentences.map((s) => ({ s, n: 0 }))).slice(0, limit).map((x) => x.s);
}

export function synthesizeAnswer(question, articles, lang, history) {
  const ar = lang === 'ar';
  const topic = conversationTopic(question, history);
  const intent = detectIntent(question);
  const withText = articles.filter((a) => (a.abstract || a.title) && a.url);
  const about = topic || (ar ? 'هذا الموضوع' : 'this topic');

  if (!withText.length) {
    return {
      insufficient: true,
      answer: ar
        ? `ما قدرت أبني إجابة علمية موثوقة لهذه النقطة${topic ? ` عن ${topic}` : ''} لأن البحث الحي ما رجّع ملخصات كافية.\n\nاسأل بصيغة أوضح، أو افتح روابط الجهات الرسمية تحت المصادر.`
        : `I don’t have enough freshly retrieved abstracts to teach ${about} properly right now.\n\nTry a slightly more specific question, or use the official links under Sources.`,
      points: [],
      nursing: [],
      safety: [],
    };
  }

  const used = withText.slice(0, 5);
  const pool = used.flatMap((a, i) => {
    const sents = pickSentences(a.abstract || a.title, `${question} ${topic}`, 3);
    return sents.map((s) => ({ s: s.replace(/\s+/g, ' '), i: i + 1 }));
  });
  const unique = [];
  for (const p of pool) {
    if (!unique.some((u) => u.s.slice(0, 50) === p.s.slice(0, 50))) unique.push(p);
  }

  const cite = (p) => `${p.s} [${p.i}]`;
  const first = unique[0] ? cite(unique[0]) : `${used[0].title} [1]`;
  const more = unique.slice(1, 4);

  const OPEN = {
    'diabetic ketoacidosis': {
      en: 'DKA (diabetic ketoacidosis) is what happens when there is far too little insulin: glucose stays in the blood, the body burns fat instead, ketones build up, and the blood turns acidic.',
      ar: 'الحماض الكيتوني السكري (DKA) يحدث عند نقص الإنسولين الشديد: السكر يبقى في الدم، والجسم يحرق الدهون، فتتراكم الكيتونات ويصبح الدم حمضياً.',
    },
    'heart failure': {
      en: 'Heart failure means the heart cannot pump (or fill) well enough for the body’s needs, so fluid backs up and organs get poorly perfused.',
      ar: 'فشل القلب يعني أن القلب لا يضخ (أو لا يمتلئ) بما يكفي لاحتياج الجسم، فيحتقن السائل وتضعف تروية الأعضاء.',
    },
    'community acquired pneumonia': {
      en: 'Pneumonia is infection of the lung tissue — the air spaces fill with inflammatory fluid, so gas exchange drops and the person becomes febrile and breathless.',
      ar: 'الالتهاب الرئوي عدوى في نسيج الرئة تمتلئ معها الأسناخ بسائل التهابي، فيضعف تبادل الغازات وتظهر الحمى وضيق النفس.',
    },
    'sepsis': {
      en: 'Sepsis is a dysregulated response to infection that starts injuring the person’s own organs — it is an emergency, not “just a bad fever”.',
      ar: 'الإنتان استجابة مضطربة للعدوى تبدأ بإيذاء أعضاء المريض نفسه — وهو طارئ وليس مجرد حمى شديدة.',
    },
    'hypovolemic shock': {
      en: 'Hypovolemic shock is inadequate tissue perfusion because circulating volume is too low — bleeding or severe fluid loss.',
      ar: 'صدمة نقص الحجم هي نقص تروية الأنسجة لأن حجم الدم الدائر قليل جداً — نزف أو فقد سوائل شديد.',
    },
  };

  let lead;
  const opener = OPEN[topic];
  if (opener && (intent === 'explain' || intent === 'general')) {
    lead = (ar ? opener.ar : opener.en) + (unique[0] ? ` [${unique[0].i}]` : '');
  } else if (intent === 'nursing') {
    lead = ar
      ? `للتدخلات التمريضية في ${about}: ركّز على التقييم المستمر، السلامة، ثم التدخلات المرتبطة بالموجودات الفعلية — مو قائمة عامة.`
      : `For nursing care in ${about}, start from the actual findings: assess, keep the patient safe, then intervene on what you see — not a generic checklist.`;
  } else if (intent === 'meds') {
    lead = ar
      ? `بالنسبة للأدوية في ${about}: استخدم فقط ما يدعمه المصدر، ولا تخمّن جرعة إذا نقص العمر أو الوزن أو وظائف الكلى.`
      : `On medicines used in ${about}: stick to what the sources support, and don’t guess a dose if age, weight, or kidney function is missing.`;
  } else if (intent === 'causes') {
    lead = ar
      ? `أسباب ${about} يمكن فهمها كالتالي:`
      : `Here’s what drives ${about}:`;
  } else if (intent === 'signs') {
    lead = ar
      ? `العلامات التي ترتبط عادةً بـ ${about}:`
      : `The picture that usually goes with ${about}:`;
  } else if (intent === 'specific') {
    lead = ar
      ? `بخصوص سؤالك المحدد حول ${about}:`
      : `On that specific point about ${about}:`;
  } else if (intent === 'diagnosis') {
    lead = ar
      ? `إذا كان السؤال عن التشخيص العامل لـ ${about}:`
      : `If you’re asking for the working idea behind ${about}:`;
  } else {
    lead = ar
      ? `${about} باختصار: ${first}`
      : `${about[0]?.toUpperCase()}${about.slice(1)} — ${first}`;
  }

  const body = [];
  if (intent === 'explain' || intent === 'general' || intent === 'full') {
    if (unique[0]) body.push(cite(unique[0]));
    if (more.length) body.push(more.map(cite).join(' '));
  } else {
    body.push(first);
    if (more.length) {
      body.push(more.map((p) => `- ${cite(p)}`).join('\n'));
    }
  }

  const teach = [];
  if (intent === 'nursing' && more.length) {
    teach.push(ar ? 'اربط كل تدخل بموجودة (مثلاً نقص أكسجة → أكسجين ومراقبة)، ولا تضف موجودات غير مذكورة.' : 'Tie each action to a finding (for example hypoxia → oxygen and monitoring). Don’t add findings the case never gave you.');
  }
  if (intent === 'full') {
    teach.push(ar ? 'تحليل كامل يطلبه المستخدم فقط: ابدأ بالمشكلة الحالية، ثم العلامات، ثم الأولويات، ثم الخطة.' : 'You asked for a fuller look — start with the presenting problem, then the findings, then priorities, then the plan.');
  }

  const parts = [lead, '', ...body];
  if (teach.length) parts.push('', teach.join('\n'));
  if (topic && /it|this|ذلك|هذا/.test(question) || (question.split(/\s+/).length < 8 && topic)) {
    /* follow-up already scoped via topic — no extra meta sentence */
  }

  return {
    insufficient: unique.length < 1,
    answer: parts.filter(Boolean).join('\n'),
    points: unique.map((p) => p.s),
    nursing: [],
    safety: [],
    topic,
    intent,
  };
}

export async function researchChat(question, history = [], lang = 'en') {
  const started = Date.now();
  const queries = buildChatQueries(question, history);
  const histText = (history || []).map((m) => m.content).join(' ');
  const { matchLesson, teachFromLesson, needsLiveResearch } = await import('./chat-teach.mjs');
  const hit = matchLesson(queries.topic, question, histText);
  const live = needsLiveResearch(question, queries.intent) || !hit;

  let articles = [];
  if (live) {
    const [ids1, ids2, epmc] = await Promise.all([
      pubmedIds(queries.primary, 5),
      pubmedIds(queries.nursing, 3),
      europePmc(queries.primary, 4),
    ]);
    const ids = [...new Set([...ids1, ...ids2])].slice(0, 6);
    const summaries = await pubmedSummaries(ids);
    const abs = await pubmedAbstracts(ids);
    summaries.forEach((s) => { if (abs[s.pmid]) s.abstract = abs[s.pmid]; });
    const seen = new Set();
    for (const item of [...summaries, ...epmc]) {
      if (!item?.url || seen.has(item.url) || seen.has(item.id)) continue;
      if (!item.trusted && !item.pmid) continue;
      seen.add(item.url);
      seen.add(item.id);
      articles.push(item);
    }
  }

  const taught = hit ? teachFromLesson(hit.lesson, queries.intent, lang) : '';
  const synthesis = articles.length
    ? synthesizeAnswer(question, articles, lang, history)
    : { insufficient: !taught, answer: '', points: [], nursing: [], safety: [] };

  let answer = taught;
  if (articles.length && synthesis.points?.length && hit) {
    const extra = synthesis.points[0];
    if (extra && !taught.includes(extra.slice(0, 40))) {
      answer = `${taught}\n\n${extra} [1]`;
    }
  } else if (!taught) {
    answer = synthesis.answer;
  }

  const lessonSrc = (hit?.lesson.sources || []).map((s, i) => ({
    source: s.org,
    org: s.org,
    id: `lesson:${s.org}`,
    pmid: '',
    title: s.title,
    authors: '',
    year: '',
    journal: s.org,
    url: s.url,
    abstract: '',
    trusted: true,
    n: i + 1,
  }));

  const portals = live ? guidelinePortals(queries.primary).slice(0, 4) : [];

  return {
    ranAt: new Date().toISOString(),
    durationMs: Date.now() - started,
    status: (taught || articles.length) ? 'ok' : 'empty',
    queries,
    articles: (articles.length ? articles : lessonSrc).slice(0, 8),
    portals,
    answer,
    insufficient: !answer,
    points: synthesis.points || [],
    nursing: [],
    safety: [],
  };
}

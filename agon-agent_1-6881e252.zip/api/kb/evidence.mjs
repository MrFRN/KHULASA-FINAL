/**
 * Curated, citable evidence corpus.
 * Every document is an official guideline landing page — never a fabricated paper.
 * The pipeline retrieves these by findings, then optionally live-checks the URL.
 */

export const EVIDENCE = [
  {
    id: 'ssc-sepsis',
    org: 'SSC/SCCM',
    title: 'Surviving Sepsis Campaign guidelines',
    url: 'https://www.sccm.org/clinical-resources/guidelines/guidelines/surviving-sepsis-campaign',
    conditions: ['sepsis', 'shock'],
    findings: ['fever', 'hypotension', 'tachycardia', 'tachypnea', 'lactate', 'confusion', 'oliguria'],
    claims: [
      'Obtain cultures before antibiotics when this does not delay care.',
      'Give antimicrobials immediately in probable septic shock.',
      'Measure lactate and reassess perfusion after initial resuscitation.',
    ],
    nursing: ['Hour-1 bundle: cultures, antibiotics, fluids if hypoperfusion, lactate, source control.'],
  },
  {
    id: 'who-sepsis',
    org: 'WHO',
    title: 'WHO sepsis fact sheet',
    url: 'https://www.who.int/news-room/fact-sheets/detail/sepsis',
    conditions: ['sepsis'],
    findings: ['fever', 'hypotension', 'confusion'],
    claims: ['Sepsis is life-threatening organ dysfunction due to a dysregulated host response to infection.'],
    nursing: ['Escalate immediately if infection plus new organ dysfunction is suspected.'],
  },
  {
    id: 'idsa-cap',
    org: 'IDSA/ATS',
    title: 'Community-acquired pneumonia in adults',
    url: 'https://www.idsociety.org/practice-guideline/community-acquired-pneumonia-cap-in-adults/',
    conditions: ['cap', 'pneumonia'],
    findings: ['fever', 'cough', 'dyspnea', 'crackles', 'hypoxia', 'wbc'],
    claims: [
      'Chest radiograph supports the diagnosis of pneumonia when clinically suspected.',
      'Severity and local resistance guide empiric antibiotics.',
    ],
    nursing: ['Monitor SpO2, work of breathing, and response to the first 48–72 hours of therapy.'],
  },
  {
    id: 'nice-pneumonia',
    org: 'NICE',
    title: 'NICE NG138 Pneumonia',
    url: 'https://www.nice.org.uk/guidance/ng138',
    conditions: ['cap', 'pneumonia'],
    findings: ['fever', 'cough', 'dyspnea', 'rr'],
    claims: ['Use a validated severity tool (e.g. CRB-65/CURB-65) to support admission decisions.'],
    nursing: ['Reassess if not improving; safety-net for hypoxia and confusion.'],
  },
  {
    id: 'aha-acs',
    org: 'AHA/ACC',
    title: 'Chest pain / ACS evaluation',
    url: 'https://www.ahajournals.org/doi/10.1161/CIR.0000000000001062',
    conditions: ['mi', 'acs'],
    findings: ['chest_pain', 'diaphoresis', 'dyspnea', 'troponin', 'ecg'],
    claims: [
      'Obtain a 12-lead ECG within 10 minutes of arrival for suspected ACS.',
      'High-sensitivity troponin is interpreted in a serial pathway, not a single isolated value.',
    ],
    nursing: ['Continuous cardiac monitoring; chewed aspirin if not contraindicated and ordered.'],
  },
  {
    id: 'esc-acs',
    org: 'ESC',
    title: 'ESC Acute Coronary Syndromes',
    url: 'https://www.escardio.org/Guidelines/Clinical-Practice-Guidelines/Acute-Coronary-Syndromes-ACS',
    conditions: ['mi', 'acs'],
    findings: ['chest_pain', 'troponin'],
    claims: ['STEMI requires immediate reperfusion; NSTE-ACS is risk-stratified.'],
    nursing: ['Do not delay ECG or transfer on a chest-pain pathway.'],
  },
  {
    id: 'aha-hf',
    org: 'AHA/ACC/HFSA',
    title: 'Heart failure guideline',
    url: 'https://www.ahajournals.org/doi/10.1161/CIR.0000000000001063',
    conditions: ['chf', 'hf'],
    findings: ['dyspnea', 'orthopnea', 'edema', 'weight_gain'],
    claims: ['Loop diuretics relieve congestion; GDMT is titrated after stabilization.'],
    nursing: ['Daily weight, fluid balance, and sitting-up position for pulmonary edema.'],
  },
  {
    id: 'esc-pe',
    org: 'ESC',
    title: 'Acute pulmonary embolism',
    url: 'https://www.escardio.org/Guidelines/Clinical-Practice-Guidelines/Acute-Pulmonary-Embolism-Diagnosis-and-Management-of',
    conditions: ['pe'],
    findings: ['dyspnea', 'pleuritic', 'hemoptysis', 'ddimer', 'unilateral_leg_swelling'],
    claims: ['Pretest probability determines whether D-dimer or CTPA is appropriate.'],
    nursing: ['Do not start anticoagulation if active bleeding is present.'],
  },
  {
    id: 'gina',
    org: 'GINA',
    title: 'Global Initiative for Asthma',
    url: 'https://ginasthma.org/',
    conditions: ['asthma'],
    findings: ['wheeze', 'dyspnea', 'cough', 'chest_tightness'],
    claims: ['Repeated SABA plus early systemic corticosteroid is first-line for acute exacerbation.'],
    nursing: ['Peak flow / SpO2, sit upright, review inhaler technique.'],
  },
  {
    id: 'gold',
    org: 'GOLD',
    title: 'GOLD COPD',
    url: 'https://goldcopd.org/',
    conditions: ['copd'],
    findings: ['dyspnea', 'cough', 'sputum', 'smoking'],
    claims: ['Target SpO2 is often 88–92% in CO2 retainers; uncontrolled high-flow oxygen can harm.'],
    nursing: ['Controlled oxygen, sputum character, smoking-cessation counselling.'],
  },
  {
    id: 'aha-stroke',
    org: 'AHA/ASA',
    title: 'Early management of acute ischemic stroke',
    url: 'https://www.ahajournals.org/doi/10.1161/STR.0000000000000375',
    conditions: ['stroke'],
    findings: ['focal_weakness', 'speech_difficulty', 'vision_change', 'confusion'],
    claims: ['Time is brain: immediate glucose, non-contrast CT, and stroke-code activation.'],
    nursing: ['NPO until swallow screen; serial neurologic observations.'],
  },
  {
    id: 'ada',
    org: 'ADA',
    title: 'ADA Standards of Care in Diabetes',
    url: 'https://diabetesjournals.org/care/issue/48/Supplement_1',
    conditions: ['dka', 'hypoglycemia'],
    findings: ['polyuria', 'polydipsia', 'glucose', 'vomiting'],
    claims: ['Do not start insulin in DKA until potassium is known and not critically low.', 'Treat symptomatic hypoglycemia immediately with glucose.'],
    nursing: ['Hourly glucose/potassium in DKA; recheck glucose 10–15 min after hypo treatment.'],
  },
  {
    id: 'kdigo',
    org: 'KDIGO',
    title: 'KDIGO Acute Kidney Injury',
    url: 'https://kdigo.org/guidelines/acute-kidney-injury/',
    conditions: ['aki'],
    findings: ['oliguria', 'creatinine', 'edema'],
    claims: ['Stop nephrotoxins, correct volume, exclude obstruction, watch potassium.'],
    nursing: ['Strict intake/output and daily weight.'],
  },
  {
    id: 'idsa-mening',
    org: 'IDSA',
    title: 'Bacterial meningitis guideline',
    url: 'https://www.idsociety.org/practice-guideline/bacterial-meningitis/',
    conditions: ['meningitis'],
    findings: ['fever', 'neck_stiffness', 'headache', 'photophobia'],
    claims: ['Do not delay antibiotics for imaging or LP if LP will be delayed in severe suspected disease.'],
    nursing: ['Droplet isolation initially; frequent neuro observations.'],
  },
  {
    id: 'nice-anaph',
    org: 'NICE',
    title: 'NICE CG134 Anaphylaxis',
    url: 'https://www.nice.org.uk/guidance/cg134',
    conditions: ['anaphylaxis'],
    findings: ['urticaria', 'stridor', 'wheeze', 'hypotension'],
    claims: ['Intramuscular adrenaline is first-line and must not be delayed for antihistamines or steroids.'],
    nursing: ['IM mid-anterolateral thigh; observe for biphasic reaction.'],
  },
  {
    id: 'nice-uti',
    org: 'NICE',
    title: 'NICE NG109 UTI',
    url: 'https://www.nice.org.uk/guidance/ng109',
    conditions: ['pyelo', 'uti'],
    findings: ['dysuria', 'flank_pain', 'fever', 'frequency'],
    claims: ['Culture before antibiotics when practical; choose agents by local resistance.'],
    nursing: ['Fluids, pain control, pregnancy check in females of childbearing age.'],
  },
  {
    id: 'aap',
    org: 'AAP',
    title: 'AAP patient-care resources',
    url: 'https://www.aap.org/en/patient-care/',
    conditions: ['pediatric', 'seizure_d', 'asthma'],
    findings: ['pediatric', 'fever', 'seizure'],
    claims: ['Pediatric vitals and doses are age- and weight-based; adult ranges must not be applied blindly.'],
    nursing: ['Record weight in kilograms before any emergency drug.'],
  },
  {
    id: 'cdc-flu',
    org: 'CDC',
    title: 'CDC influenza clinical guidance',
    url: 'https://www.cdc.gov/flu/professionals/index.htm',
    conditions: ['influenza'],
    findings: ['fever', 'myalgia', 'cough'],
    claims: ['Neuraminidase inhibitors are most useful when started early in high-risk or severe disease.'],
    nursing: ['Avoid aspirin in children (Reye).'],
  },
  {
    id: 'who-covid',
    org: 'WHO',
    title: 'WHO COVID-19 technical guidance',
    url: 'https://www.who.int/emergencies/diseases/novel-coronavirus-2019/technical-guidance',
    conditions: ['covid'],
    findings: ['fever', 'dry_cough', 'anosmia', 'dyspnea'],
    claims: ['Oxygen, steroids if hypoxic, and isolation follow severity and local public-health rules.'],
    nursing: ['SpO2 monitoring and awake prone positioning when appropriate.'],
  },
  {
    id: 'nice-pre',
    org: 'NICE',
    title: 'NICE NG133 Hypertension in pregnancy',
    url: 'https://www.nice.org.uk/guidance/ng133',
    conditions: ['preeclampsia'],
    findings: ['pregnancy', 'headache', 'vision_change', 'hypertension'],
    claims: ['New hypertension plus proteinuria or organ features needs urgent obstetric care. Avoid ACE/ARB.'],
    nursing: ['Serial BP, reflexes, fetal monitoring as ordered.'],
  },
  {
    id: 'cochrane',
    org: 'Cochrane',
    title: 'Cochrane Library',
    url: 'https://www.cochranelibrary.com/',
    conditions: ['general'],
    findings: [],
    claims: ['Prefer systematic reviews over anecdote when choosing routine supportive care.'],
    nursing: ['Cite living reviews when teaching students.'],
  },
  {
    id: 'nanda',
    org: 'NANDA-I',
    title: 'NANDA International nursing diagnoses',
    url: 'https://nanda.org/',
    conditions: ['nursing'],
    findings: [],
    claims: ['Nursing diagnoses are written as problem–related to–as evidenced by statements and ranked by threat to life.'],
    nursing: ['Airway, breathing, circulation, and safety outrank comfort until the patient is stable.'],
  },
];

function tokens(s) {
  return String(s || '')
    .toLowerCase()
    .split(/[^a-z0-9\u0600-\u06ff]+/)
    .filter((w) => w.length > 2);
}

export function collectFindings(caseData) {
  const findings = [];
  const push = (id, label, value) => findings.push({ id, label, value });
  (caseData.symptoms || []).forEach((s) => push('sx:' + s, s, true));
  const v = caseData.vitals || {};
  Object.entries(v).forEach(([k, val]) => { if (val !== '' && val != null) push('vital:' + k, k, val); });
  const labs = caseData.labs || {};
  Object.entries(labs).forEach(([k, row]) => {
    const val = row && typeof row === 'object' ? row.value : row;
    if (val !== '' && val != null) push('lab:' + k, k, val);
  });
  if (caseData.chiefComplaint) push('cc', 'chief_complaint', caseData.chiefComplaint);
  if (caseData.physicalExam) push('exam', 'physical_exam', caseData.physicalExam);
  if (caseData.pregnancy) push('preg', 'pregnancy', caseData.gestationalAge || true);
  if (caseData.smoking === 'current') push('risk', 'smoking', 'current');
  (caseData.history || []).forEach((h) => push('pmh', h, true));
  (caseData.imaging || []).forEach((i) => push('img', i, true));
  if (caseData.imagingNote) push('imgnote', 'imaging_note', caseData.imagingNote);
  push('age', 'age', caseData.age);
  push('sex', 'sex', caseData.gender);
  if (caseData.weight) push('wt', 'weight', caseData.weight);
  return findings;
}

export function retrieveEvidence(caseData, conditionId) {
  const hay = [
    conditionId,
    caseData.chiefComplaint,
    (caseData.symptoms || []).join(' '),
    (caseData.history || []).join(' '),
    (caseData.imaging || []).join(' '),
    caseData.physicalExam,
    caseData.presentIllness,
  ].join(' ').toLowerCase();
  const words = new Set(tokens(hay));

  const ranked = EVIDENCE.map((doc) => {
    let score = 0;
    if (doc.conditions.some((c) => c === conditionId || hay.includes(c))) score += 6;
    doc.findings.forEach((f) => {
      if (words.has(f) || hay.includes(f.replace(/_/g, ' '))) score += 2;
    });
    tokens(doc.title + ' ' + doc.claims.join(' ')).forEach((w) => { if (words.has(w)) score += 0.4; });
    if (Number(caseData.age) < 18 && doc.org === 'AAP') score += 2;
    if (caseData.pregnancy && doc.id === 'nice-pre') score += 4;
    return { doc, score };
  })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);

  return ranked.map(({ doc, score }) => ({
    id: doc.id,
    org: doc.org,
    title: doc.title,
    url: doc.url,
    score: +score.toFixed(1),
    claims: doc.claims,
    nursing: doc.nursing,
    liveChecked: false,
    liveOk: null,
  }));
}

export async function liveCheck(docs, timeoutMs = 2500) {
  const out = [];
  for (const d of docs.slice(0, 6)) {
    let liveOk = null;
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), timeoutMs);
      const res = await fetch(d.url, { method: 'HEAD', redirect: 'follow', signal: ctrl.signal });
      clearTimeout(t);
      liveOk = res.ok || (res.status >= 300 && res.status < 500);
    } catch {
      liveOk = null;
    }
    out.push({ ...d, liveChecked: true, liveOk });
  }
  docs.slice(6).forEach((d) => out.push(d));
  return out;
}

export function evidenceCheck(condition, retrieved, findings, lang) {
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  const condHits = retrieved.filter((d) => d.score >= 4);
  const claimHits = retrieved.flatMap((d) => d.claims.map((c) => ({ org: d.org, url: d.url, claim: c })));
  const findingCount = findings.length;
  const passed = condHits.length >= 1 && findingCount >= 3;
  const grade = !passed ? 'insufficient' : condHits.length >= 3 ? 'strong' : 'moderate';
  return {
    passed,
    grade,
    summary: passed
      ? t(
        `Internal evidence check ${grade}: ${condHits.length} guideline sources match the working diagnosis and ${findingCount} structured findings were collected. Output is grounded in retrieved sources, not model memory alone.`,
        `فحص الأدلة الداخلي (${grade === 'strong' ? 'قوي' : 'متوسط'}): ${condHits.length} مصادر إرشادية تطابق التشخيص العامل، وجُمعت ${findingCount} موجودات. الناتج مستند إلى مصادر مُسترجَعة وليس إلى ذاكرة النموذج وحدها.`,
      )
      : t(
        'Internal evidence check: insufficient retrieved sources or findings. Treat the working diagnosis as provisional and collect the missing data listed in the report.',
        'فحص الأدلة: المصادر أو الموجودات غير كافية. اعتبر التشخيص العامل مؤقتاً واستكمل البيانات الناقصة.',
      ),
    sourcesUsed: condHits.length,
    findingsUsed: findingCount,
    groundedClaims: claimHits.slice(0, 8),
  };
}

export function pubmedSearchUrl(query) {
  return `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(query)}`;
}

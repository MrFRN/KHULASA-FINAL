/**
 * Server-side AI provider abstraction.
 * Keys stay in env/Secrets — never sent to the browser.
 * Switch providers via AI_PROVIDER / admin settings, no code change.
 */

export const PROVIDERS = {
  openai: {
    id: 'openai',
    label: 'OpenAI',
    kind: 'openai',
    envKeys: ['OPENAI_API_KEY', 'OPENAI_KEY'],
    baseEnv: 'OPENAI_BASE_URL',
    defaultBase: 'https://api.openai.com/v1',
    defaultModel: 'gpt-4o-mini',
    models: ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'o4-mini'],
  },
  groq: {
    id: 'groq',
    label: 'Groq',
    kind: 'openai',
    envKeys: ['GROQ_API_KEY'],
    defaultBase: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    models: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768'],
  },
  openrouter: {
    id: 'openrouter',
    label: 'OpenRouter',
    kind: 'openai',
    envKeys: ['OPENROUTER_API_KEY'],
    defaultBase: 'https://openrouter.ai/api/v1',
    defaultModel: 'openai/gpt-4o-mini',
    models: ['openai/gpt-4o-mini', 'anthropic/claude-3.5-sonnet', 'google/gemini-2.0-flash-001'],
  },
  anthropic: {
    id: 'anthropic',
    label: 'Anthropic',
    kind: 'anthropic',
    envKeys: ['ANTHROPIC_API_KEY'],
    defaultBase: 'https://api.anthropic.com/v1',
    defaultModel: 'claude-3-5-sonnet-latest',
    models: ['claude-3-5-sonnet-latest', 'claude-3-5-haiku-latest'],
  },
  gemini: {
    id: 'gemini',
    label: 'Google Gemini',
    kind: 'gemini',
    envKeys: ['GEMINI_API_KEY', 'GOOGLE_GENERATIVE_AI_API_KEY', 'GOOGLE_API_KEY'],
    defaultBase: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: 'gemini-2.0-flash',
    models: ['gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro'],
  },
};

function firstEnv(names) {
  for (const n of names || []) {
    const v = process.env[n];
    if (v && String(v).trim()) return String(v).trim();
  }
  return '';
}

export function providerStatus() {
  return Object.values(PROVIDERS).map((p) => ({
    id: p.id,
    label: p.label,
    configured: !!firstEnv(p.envKeys),
    defaultModel: p.defaultModel,
    models: p.models,
    secretNames: p.envKeys,
  }));
}

export function resolveProvider(preferredId, preferredModel) {
  const envPref = (process.env.AI_PROVIDER || '').toLowerCase().trim();
  const want = (preferredId || envPref || '').toLowerCase();
  const list = Object.values(PROVIDERS);
  const chosen = list.find((p) => p.id === want && firstEnv(p.envKeys))
    || list.find((p) => firstEnv(p.envKeys));
  if (!chosen) {
    return {
      ok: false,
      error: 'No AI provider key is configured. Add OPENAI_API_KEY, GROQ_API_KEY, OPENROUTER_API_KEY, ANTHROPIC_API_KEY, or GEMINI_API_KEY in Secrets.',
      needSecret: 'OPENAI_API_KEY',
      providers: providerStatus(),
    };
  }
  const key = firstEnv(chosen.envKeys);
  const base = (chosen.baseEnv && process.env[chosen.baseEnv]) || chosen.defaultBase;
  const model = preferredModel || process.env.AI_MODEL || process.env.OPENAI_MODEL || chosen.defaultModel;
  return { ok: true, provider: chosen, key, base, model };
}

function toOpenAIMessages(messages) {
  return messages.map((m) => ({
    role: m.role === 'assistant' ? 'assistant' : m.role === 'system' ? 'system' : 'user',
    content: String(m.content || ''),
  }));
}

export async function completeChat({ messages, stream, preferredId, preferredModel }) {
  const resolved = resolveProvider(preferredId, preferredModel);
  if (!resolved.ok) return { error: resolved };

  const { provider, key, base, model } = resolved;
  if (provider.kind === 'openai') {
    return callOpenAICompat({ base, key, model, messages: toOpenAIMessages(messages), stream, provider });
  }
  if (provider.kind === 'anthropic') {
    return callAnthropic({ key, model, messages, stream: false });
  }
  if (provider.kind === 'gemini') {
    return callGemini({ key, model, messages, stream: false });
  }
  return { error: { error: 'Unknown provider', needSecret: provider.envKeys[0] } };
}

async function callOpenAICompat({ base, key, model, messages, stream, provider }) {
  const headers = {
    Authorization: `Bearer ${key}`,
    'Content-Type': 'application/json',
  };
  if (provider.id === 'openrouter') {
    headers['HTTP-Referer'] = process.env.OPENROUTER_SITE_URL || 'https://alkhulasa.app';
    headers['X-Title'] = 'Khulasa Nursing Assistant';
  }
  const res = await fetch(`${base.replace(/\/$/, '')}/chat/completions`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      model,
      temperature: 0.7,
      max_tokens: 1800,
      stream: !!stream,
      messages,
    }),
  });
  return { kind: 'openai', res, model, providerId: provider.id };
}

function splitSystem(messages) {
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const rest = messages.filter((m) => m.role !== 'system');
  return { system, rest };
}

async function callAnthropic({ key, model, messages }) {
  const { system, rest } = splitSystem(messages);
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': key,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      max_tokens: 1800,
      temperature: 0.7,
      system: system || undefined,
      messages: rest.map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: String(m.content || ''),
      })),
    }),
  });
  const raw = await res.json();
  if (!res.ok) {
    return { kind: 'json', ok: false, status: res.status, answer: '', error: raw?.error?.message || `Anthropic ${res.status}`, model, providerId: 'anthropic' };
  }
  const answer = (raw.content || []).map((b) => b.text || '').join('');
  return { kind: 'json', ok: true, answer, model, providerId: 'anthropic' };
}

async function callGemini({ key, model, messages }) {
  const { system, rest } = splitSystem(messages);
  const contents = rest.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: String(m.content || '') }],
  }));
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: system ? { parts: [{ text: system }] } : undefined,
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 1800 },
    }),
  });
  const raw = await res.json();
  if (!res.ok) {
    return { kind: 'json', ok: false, status: res.status, answer: '', error: raw?.error?.message || `Gemini ${res.status}`, model, providerId: 'gemini' };
  }
  const answer = (raw.candidates || []).flatMap((c) => (c.content?.parts || []).map((p) => p.text || '')).join('');
  return { kind: 'json', ok: true, answer, model, providerId: 'gemini' };
}

/**
 * Extract structured clinical data from free text.
 * NEVER invents values. Unreadable / ambiguous items are marked unclear.
 */

const LAB_ALIASES = [
  ['wbc', /(?:wbc|white\s*blood\s*cells?|leukocytes?|كرات\s*بيض)/i, '10³/µL'],
  ['hgb', /(?:hgb|hb|hemoglobin|خضاب|هيموغلوبين)/i, 'g/dL'],
  ['plt', /(?:plt|platelets?|صفائح)/i, '10³/µL'],
  ['crp', /(?:crp|c-reactive)/i, 'mg/L'],
  ['esr', /(?:esr|sed(?:imentation)?\s*rate)/i, 'mm/h'],
  ['troponin', /(?:troponin(?:-i|-t)?|hs-?tni|تروبونين)/i, 'ng/mL'],
  ['lactate', /(?:lactate|لاكتات)/i, 'mmol/L'],
  ['d_dimer', /(?:d[-\s]?dimer)/i, 'µg/mL'],
  ['hba1c', /(?:hba1c|a1c)/i, '%'],
  ['glucose', /(?:(?:random|fasting|blood)\s*)?glucose|rbs|fbs|سكر/i, 'mg/dL'],
  ['creatinine', /(?:creatinine|cr\b|كرياتينين)/i, 'mg/dL'],
  ['sodium', /(?:sodium|\bna\+?\b|صوديوم)/i, 'mmol/L'],
  ['potassium', /(?:potassium|\bk\+?\b|بوتاسيوم)/i, 'mmol/L'],
  ['inr', /\binr\b/i, ''],
  ['amylase', /amylase/i, 'U/L'],
  ['lipase', /lipase/i, 'U/L'],
  ['bilirubin', /(?:bilirubin|tbil|بيليروبين)/i, 'mg/dL'],
  ['alt', /\balt\b|sgpt/i, 'U/L'],
  ['ast', /\bast\b|sgot/i, 'U/L'],
];

const HISTORY_MAP = [
  ['Diabetes', /diabet|dm\b|سكرى|سكري/i],
  ['Hypertension', /hypertens|\bhtn\b|ضغط\s*دم/i],
  ['Heart disease', /(?:cad|ihd|ischemic heart|heart failure|\bhf\b|mi\b|infarct|قلبي)/i],
  ['Asthma/COPD', /asthma|copd|ربو|انسداد رئوي/i],
  ['Kidney disease', /ckd|aki|renal|kidney|كلو/i],
  ['Liver disease', /cirrhosis|hepatitis|liver|كبد/i],
  ['Cancer', /cancer|malignan|ورم|سرطان/i],
  ['Previous surgery', /post[-\s]?op|previous surgery|surgical history|جراح/i],
  ['Immunocompromised', /immuno|hiv|steroid|مثبط/i],
];

const IMAGING_MAP = [
  ['Chest X-ray', /chest\s*x[-\s]?ray|\bcxr\b|أشعة\s*صدر/i],
  ['CT', /\bct\b|computed tomography|أشعة مقطعية/i],
  ['MRI', /\bmri\b|magnetic resonance/i],
  ['Ultrasound', /ultrasound|\bus\b|sonograph|سونار/i],
  ['ECG', /\becg\b|\bekg\b|تخطيط/i],
  ['Echo', /echo(?:cardiogram)?|إيكو/i],
];

const SYMPTOM_WORDS = [
  ['fever', /fever|pyrexia|حمى|سخونية/i],
  ['cough', /cough|سعال/i],
  ['dyspnea', /dyspn|shortness of breath|\bsob\b|ضيق\s*نفس/i],
  ['chest_pain', /chest pain|ألم\s*صدر/i],
  ['wheeze', /wheez|أزيز/i],
  ['edema', /edema|oedema|swelling|وذمة|تورم/i],
  ['nausea', /nausea|غثيان/i],
  ['vomiting', /vomit|قيء/i],
  ['diarrhea', /diarrh|إسهال/i],
  ['headache', /headache|صداع/i],
  ['confusion', /confus|altered mental|تشوش|ارتباك/i],
  ['palpitations', /palpitat|خفقان/i],
  ['syncope', /syncope|faint|إغماء/i],
  ['abdominal_pain', /abdominal pain|epigastric|ألم\s*بطن/i],
  ['hemoptysis', /hemoptysis|نفث/i],
  ['oliguria', /oliguria|anuria|قلة\s*بول/i],
];

function field(status, value, source = '', note = '') {
  return { status, value: value == null ? '' : value, source, note };
}

function take(re, text) {
  const m = text.match(re);
  return m || null;
}

function sectionAfter(text, headers, stopHeaders) {
  const h = headers.join('|');
  const s = stopHeaders.join('|');
  const re = new RegExp(`(?:${h})\\s*[:\\-–]?\\s*([\\s\\S]{0,800}?)(?=(?:${s})\\s*[:\\-–]|$)`, 'i');
  const m = text.match(re);
  return m ? m[1].replace(/\s+/g, ' ').trim() : '';
}

export function parseClinicalText(raw, lang = 'en') {
  const text = String(raw || '').replace(/\r/g, '').trim();
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  const confirmed = [];
  const missing = [];
  const unclear = [];
  const fields = {};

  if (!text) {
    return {
      ok: false,
      error: t('Paste or write the case first.', 'اكتب الحالة أو الصقها أولاً.'),
      fields: {}, confirmed: [], missing: [], unclear: [], sourceText: '',
    };
  }

  // Age
  const ageM = take(/(\d{1,3})\s*(?:-|\s)?(?:year|yr|y\/o|yo|years?)\s*(?:old|-old)?/i, text)
    || take(/(?:aged?|age[:\s]+|عمره|عمرها|العمر)\s*(\d{1,3})/i, text);
  const moM = take(/(\d{1,2})\s*(?:-|\s)?month(?:s)?(?:-old)?/i, text);
  if (ageM) {
    const age = Number(ageM[1]);
    if (age >= 0 && age <= 130) {
      fields.age = field('confirmed', age, ageM[0]);
      confirmed.push({ key: 'age', label: t('Age', 'العمر'), value: String(age) });
    } else {
      fields.age = field('unclear', ageM[0], ageM[0], t('Age number looks implausible.', 'رقم العمر غير منطقي.'));
      unclear.push({ key: 'age', label: t('Age', 'العمر'), value: ageM[0] });
    }
  } else if (moM) {
    const months = Number(moM[1]);
    fields.age = field('confirmed', 0, moM[0]);
    fields.ageMonths = field('confirmed', months, moM[0]);
    confirmed.push({ key: 'ageMonths', label: t('Age in months', 'العمر بالأشهر'), value: String(months) });
  } else {
    fields.age = field('missing', '');
    missing.push({ key: 'age', label: t('Age', 'العمر') });
  }

  // Sex
  if (/\b(male|man|boy|gentleman|ذكر|رجل)\b/i.test(text) && !/\b(female|woman|girl|أنثى|امرأة)\b/i.test(text)) {
    fields.gender = field('confirmed', 'male', 'male');
    confirmed.push({ key: 'gender', label: t('Sex', 'الجنس'), value: t('Male', 'ذكر') });
  } else if (/\b(female|woman|girl|lady|أنثى|امرأة|حامل)\b/i.test(text) && !/\b(male|man|boy|ذكر)\b/i.test(text)) {
    fields.gender = field('confirmed', 'female', 'female');
    confirmed.push({ key: 'gender', label: t('Sex', 'الجنس'), value: t('Female', 'أنثى') });
  } else if (/\b(male|man|ذكر).{0,20}(female|woman|أنثى)|(female|woman|أنثى).{0,20}(male|man|ذكر)/i.test(text)) {
    fields.gender = field('unclear', '', '', t('Both male and female terms appear.', 'ظهرت كلمتا ذكر وأنثى.'));
    unclear.push({ key: 'gender', label: t('Sex', 'الجنس'), value: t('Ambiguous', 'غير واضح') });
  } else {
    fields.gender = field('missing', '');
    missing.push({ key: 'gender', label: t('Sex', 'الجنس') });
  }

  // Weight / height
  const wt = take(/(\d{2,3}(?:\.\d)?)\s*(?:kg|kilograms?|كجم|كيلو)/i, text);
  if (wt) {
    fields.weight = field('confirmed', Number(wt[1]), wt[0]);
    confirmed.push({ key: 'weight', label: t('Weight', 'الوزن'), value: `${wt[1]} kg` });
  } else {
    fields.weight = field('missing', '');
    missing.push({ key: 'weight', label: t('Weight', 'الوزن') });
  }
  const ht = take(/(\d{2,3}(?:\.\d)?)\s*(?:cm|centimet(?:er|re)s?|سم)/i, text);
  if (ht) {
    fields.height = field('confirmed', Number(ht[1]), ht[0]);
    confirmed.push({ key: 'height', label: t('Height', 'الطول'), value: `${ht[1]} cm` });
  } else {
    fields.height = field('missing', '');
    missing.push({ key: 'height', label: t('Height', 'الطول') });
  }

  // Pregnancy
  if (/pregnan|gravida|g\d+p\d+|حامل|حمل/i.test(text)) {
    fields.pregnancy = field('confirmed', true, 'pregnancy');
    confirmed.push({ key: 'pregnancy', label: t('Pregnancy', 'الحمل'), value: t('Yes', 'نعم') });
    const ga = take(/(\d{1,2})\s*(?:weeks?|wks?|أسبوع)/i, text);
    if (ga) {
      fields.gestationalAge = field('confirmed', Number(ga[1]), ga[0]);
      confirmed.push({ key: 'gestationalAge', label: t('Gestational age', 'عمر الحمل'), value: `${ga[1]} w` });
    } else {
      fields.gestationalAge = field('missing', '');
      missing.push({ key: 'gestationalAge', label: t('Gestational age', 'عمر الحمل') });
    }
  } else {
    fields.pregnancy = field('missing', false);
  }
  if (/breast\s*feed|lactat|رضاع/i.test(text)) {
    fields.breastfeeding = field('confirmed', true);
    confirmed.push({ key: 'breastfeeding', label: t('Breastfeeding', 'الرضاعة'), value: t('Yes', 'نعم') });
  }

  // Chief complaint
  const cc = take(/(?:admitted with|presents? with|presenting with|c\/o|complain(?:ing|s)? of|chief complaint[:\s]+|الشكوى[:\s]+|يشتكي من)\s*([^.;\n]{5,180})/i, text);
  if (cc) {
    fields.chiefComplaint = field('confirmed', cc[1].trim(), cc[0]);
    confirmed.push({ key: 'chiefComplaint', label: t('Chief complaint', 'الشكوى الرئيسية'), value: cc[1].trim() });
  } else {
    const first = text.split(/[.\n]/).map((s) => s.trim()).find((s) => s.length > 20);
    if (first) {
      fields.chiefComplaint = field('unclear', first.slice(0, 180), first, t('Used opening sentence; confirm this is the chief complaint.', 'استُخدمت الجملة الأولى؛ أكّد أنها الشكوى الرئيسية.'));
      unclear.push({ key: 'chiefComplaint', label: t('Chief complaint', 'الشكوى الرئيسية'), value: first.slice(0, 180) });
    } else {
      fields.chiefComplaint = field('missing', '');
      missing.push({ key: 'chiefComplaint', label: t('Chief complaint', 'الشكوى الرئيسية') });
    }
  }

  const hpi = sectionAfter(text, ['hpi', 'history of present illness', 'present illness', 'تاريخ المرض الحالي'], ['pmh', 'past medical', 'past history', 'allerg', 'medication', 'exam', 'vital', 'lab']);
  if (hpi) {
    fields.presentIllness = field('confirmed', hpi.slice(0, 2000));
    confirmed.push({ key: 'presentIllness', label: t('Present illness', 'تاريخ المرض الحالي'), value: hpi.slice(0, 140) });
  } else {
    fields.presentIllness = field('missing', '');
    missing.push({ key: 'presentIllness', label: t('Present illness', 'تاريخ المرض الحالي') });
  }

  const pmh = sectionAfter(text, ['pmh', 'past medical history', 'past history', 'التاريخ المرضي'], ['psh', 'surgical', 'allerg', 'medication', 'drug', 'exam', 'vital']);
  const hist = [];
  HISTORY_MAP.forEach(([name, re]) => { if (re.test(text)) hist.push(name); });
  if (pmh || hist.length) {
    fields.history = field('confirmed', hist);
    fields.pmhText = field('confirmed', pmh || hist.join(', '));
    confirmed.push({ key: 'history', label: t('Past medical history', 'التاريخ المرضي'), value: (pmh || hist.join(', ')).slice(0, 160) });
  } else {
    fields.history = field('missing', []);
    missing.push({ key: 'history', label: t('Past medical history', 'التاريخ المرضي') });
  }

  const psh = sectionAfter(text, ['psh', 'past surgical', 'surgical history', 'التاريخ الجراحي'], ['allerg', 'medication', 'drug', 'exam', 'vital', 'lab']);
  if (psh) {
    fields.surgicalHistory = field('confirmed', psh.slice(0, 1000));
    confirmed.push({ key: 'surgicalHistory', label: t('Surgical history', 'التاريخ الجراحي'), value: psh.slice(0, 140) });
  } else {
    fields.surgicalHistory = field('missing', '');
    missing.push({ key: 'surgicalHistory', label: t('Surgical history', 'التاريخ الجراحي') });
  }

  const allg = sectionAfter(text, ['allergies', 'nkda', 'allergy', 'حساسية'], ['medication', 'drug', 'exam', 'vital', 'lab']);
  if (/nkda|no known drug allerg|لا توجد حساسية/i.test(text)) {
    fields.allergies = field('confirmed', 'NKDA');
    confirmed.push({ key: 'allergies', label: t('Allergies', 'الحساسية'), value: 'NKDA' });
  } else if (allg) {
    fields.allergies = field('confirmed', allg.slice(0, 500));
    confirmed.push({ key: 'allergies', label: t('Allergies', 'الحساسية'), value: allg.slice(0, 140) });
  } else {
    fields.allergies = field('missing', '');
    missing.push({ key: 'allergies', label: t('Allergies', 'الحساسية') });
  }

  const meds = sectionAfter(text, ['medications?', 'current meds', 'drugs', 'الأدوية'], ['allerg', 'exam', 'vital', 'lab', 'imaging']);
  if (meds) {
    fields.medications = field('confirmed', meds.slice(0, 1000));
    confirmed.push({ key: 'medications', label: t('Medications', 'الأدوية'), value: meds.slice(0, 140) });
  } else {
    fields.medications = field('missing', '');
    missing.push({ key: 'medications', label: t('Medications', 'الأدوية') });
  }

  const exam = sectionAfter(text, ['physical exam', 'examination', 'o/e', 'on exam', 'assessment', 'الفحص'], ['vital', 'lab', 'imaging', 'impression', 'plan']);
  if (exam) {
    fields.physicalExam = field('confirmed', exam.slice(0, 2000));
    confirmed.push({ key: 'physicalExam', label: t('Physical assessment', 'الفحص السريري'), value: exam.slice(0, 140) });
  } else {
    fields.physicalExam = field('missing', '');
    missing.push({ key: 'physicalExam', label: t('Physical assessment', 'الفحص السريري') });
  }

  // Vitals
  const vitals = {};
  const bp = take(/(?:bp|blood pressure|ضغط)\s*[:\s]*(\d{2,3})\s*\/\s*(\d{2,3})/i, text);
  if (bp) {
    vitals.sbp = Number(bp[1]);
    vitals.dbp = Number(bp[2]);
  }
  const hr = take(/(?:hr|heart rate|pulse|نبض)\s*[:\s]*(\d{2,3})/i, text);
  if (hr) vitals.hr = Number(hr[1]);
  const rr = take(/(?:rr|respiratory rate|تنفس)\s*[:\s]*(\d{1,2})/i, text);
  if (rr) vitals.rr = Number(rr[1]);
  const spo2 = take(/(?:spo2|o2 sat|sat(?:uration)?|تشبع)\s*[:\s]*(\d{2,3})\s*%?/i, text);
  if (spo2) vitals.spo2 = Number(spo2[1]);
  const temp = take(/(?:temp|temperature|حرارة)\s*[:\s]*(\d{2}(?:\.\d)?)/i, text);
  if (temp) vitals.temp = Number(temp[1]);
  const glu = take(/(?:rbs|glucose|سكر)\s*[:\s]*(\d{2,3})/i, text);
  if (glu && !vitals.glucose) vitals.glucose = Number(glu[1]);
  if (Object.keys(vitals).length) {
    fields.vitals = field('confirmed', vitals);
    confirmed.push({ key: 'vitals', label: t('Vital signs', 'العلامات الحيوية'), value: Object.entries(vitals).map(([k, v]) => `${k} ${v}`).join(', ') });
  } else {
    fields.vitals = field('missing', {});
    missing.push({ key: 'vitals', label: t('Vital signs', 'العلامات الحيوية') });
  }

  // Labs
  const labs = {};
  LAB_ALIASES.forEach(([k, re, unit]) => {
    const rx = new RegExp(re.source + '\\s*[:\\s=]*([0-9]+(?:\\.[0-9]+)?)', 'i');
    const m = text.match(rx);
    if (m) labs[k] = { value: Number(m[1]), unit };
  });
  if (Object.keys(labs).length) {
    fields.labs = field('confirmed', labs);
    confirmed.push({ key: 'labs', label: t('Laboratories', 'التحاليل'), value: Object.keys(labs).join(', ') });
  } else {
    fields.labs = field('missing', {});
    missing.push({ key: 'labs', label: t('Laboratories', 'التحاليل') });
  }

  const imaging = [];
  IMAGING_MAP.forEach(([name, re]) => { if (re.test(text)) imaging.push(name); });
  const imgNote = sectionAfter(text, ['imaging', 'radiology', 'x-ray', 'cxr', 'ct ', 'ecg', 'الأشعة'], ['impression', 'plan', 'assessment']);
  if (imaging.length || imgNote) {
    fields.imaging = field('confirmed', imaging);
    fields.imagingNote = field(imgNote ? 'confirmed' : 'missing', imgNote.slice(0, 1000));
    confirmed.push({ key: 'imaging', label: t('Imaging', 'الأشعة'), value: (imaging.join(', ') + (imgNote ? ' — ' + imgNote.slice(0, 80) : '')).trim() });
  } else {
    fields.imaging = field('missing', []);
    missing.push({ key: 'imaging', label: t('Imaging', 'الأشعة') });
  }

  const symptoms = [];
  SYMPTOM_WORDS.forEach(([id, re]) => { if (re.test(text)) symptoms.push(id); });
  fields.symptoms = field(symptoms.length ? 'confirmed' : 'missing', symptoms);
  if (symptoms.length) confirmed.push({ key: 'symptoms', label: t('Symptoms extracted', 'أعراض مستخرجة'), value: symptoms.join(', ') });

  if (/smok(?:er|ing)|تدخين/i.test(text)) {
    fields.smoking = field('confirmed', 'current');
    confirmed.push({ key: 'smoking', label: t('Smoking', 'التدخين'), value: t('Current', 'حالي') });
  } else {
    fields.smoking = field('missing', '');
  }

  fields.other = field('confirmed', text.slice(0, 4000));

  return {
    ok: true,
    sourceText: text,
    fields,
    confirmed,
    missing,
    unclear,
    counts: { confirmed: confirmed.length, missing: missing.length, unclear: unclear.length },
  };
}

/** Best-effort text from PDF / DOCX / TXT buffers. Images cannot be read without OCR. */
export function extractRawFromFile(buffer, fileName = '', contentType = '') {
  const name = String(fileName).toLowerCase();
  const type = String(contentType).toLowerCase();
  const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  const asUtf = buf.toString('utf8');

  if (name.endsWith('.txt') || type.includes('text/plain')) {
    return { text: asUtf.replace(/\u0000/g, ''), kind: 'text', unreadable: false };
  }

  if (name.endsWith('.docx') || type.includes('wordprocessingml')) {
    const xmlHits = asUtf.match(/<w:t[^>]*>([^<]+)<\/w:t>/g) || [];
    const text = xmlHits.map((x) => x.replace(/<[^>]+>/g, '')).join(' ').replace(/\s+/g, ' ').trim();
    if (text.length >= 20) return { text, kind: 'docx', unreadable: false };
    return { text: '', kind: 'docx', unreadable: true, note: 'DOCX text could not be read. Paste the case as text.' };
  }

  if (name.endsWith('.doc') || type.includes('msword')) {
    const cleaned = asUtf.replace(/[^\x09\x0a\x0d\x20-\x7e\u0600-\u06ff]/g, ' ').replace(/\s+/g, ' ').trim();
    if (cleaned.length >= 40) return { text: cleaned, kind: 'doc', unreadable: false };
    return { text: '', kind: 'doc', unreadable: true, note: 'Legacy .doc is unreadable here. Convert to PDF/DOCX or paste text.' };
  }

  if (name.endsWith('.pdf') || type.includes('pdf')) {
    const bits = [];
    const re = /\((?:\\.|[^\\)]){2,200}\)/g;
    let m;
    while ((m = re.exec(asUtf))) {
      const s = m[0].slice(1, -1).replace(/\\[nrt]/g, ' ').replace(/\\[()\\]/g, '$&'.slice(-1));
      if (/[A-Za-z\u0600-\u06ff]{3,}/.test(s)) bits.push(s);
    }
    const text = bits.join(' ').replace(/\s+/g, ' ').trim();
    if (text.length >= 30) return { text: text.slice(0, 20000), kind: 'pdf', unreadable: false };
    return { text: '', kind: 'pdf', unreadable: true, note: 'This PDF looks scanned or encoded. Paste the text or use a text-based PDF.' };
  }

  if (type.startsWith('image/') || /\.(png|jpe?g|webp|gif)$/.test(name)) {
    return { text: '', kind: 'image', unreadable: true, note: 'Images cannot be OCR’d in this environment. Type or paste the case text.' };
  }

  const fallback = asUtf.replace(/[^\x09\x0a\x0d\x20-\x7e\u0600-\u06ff]/g, ' ').replace(/\s+/g, ' ').trim();
  if (fallback.length >= 40) return { text: fallback.slice(0, 20000), kind: 'unknown', unreadable: false };
  return { text: '', kind: 'unknown', unreadable: true, note: 'File type not readable. Use PDF, DOCX, TXT, or pasted text.' };
}

export function parsedToCasePayload(parsed) {
  const f = parsed.fields || {};
  const val = (k, fallback) => {
    const row = f[k];
    if (!row || row.status === 'missing') return fallback;
    return row.value;
  };
  return {
    age: val('age', ''),
    ageMonths: val('ageMonths', ''),
    gender: val('gender', ''),
    weight: val('weight', ''),
    height: val('height', ''),
    pregnancy: !!val('pregnancy', false),
    gestationalAge: val('gestationalAge', ''),
    breastfeeding: !!val('breastfeeding', false),
    chiefComplaint: val('chiefComplaint', ''),
    presentIllness: val('presentIllness', ''),
    history: Array.isArray(val('history', [])) ? val('history', []) : [],
    surgicalHistory: val('surgicalHistory', ''),
    allergies: val('allergies', ''),
    medications: val('medications', ''),
    physicalExam: val('physicalExam', ''),
    vitals: val('vitals', {}) || {},
    labs: val('labs', {}) || {},
    imaging: Array.isArray(val('imaging', [])) ? val('imaging', []) : [],
    imagingNote: val('imagingNote', ''),
    symptoms: Array.isArray(val('symptoms', [])) ? val('symptoms', []) : [],
    smoking: val('smoking', ''),
    sourceNarrative: parsed.sourceText || '',
  };
}

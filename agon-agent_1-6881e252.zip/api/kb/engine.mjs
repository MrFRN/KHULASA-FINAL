// Evidence-based Clinical Decision Support engine (educational use only).
import { CONDITIONS } from './conditions.mjs';
import { findSymptom } from './symptoms.mjs';
import { collectFindings, retrieveEvidence, evidenceCheck, pubmedSearchUrl } from './evidence.mjs';

const VITAL_RANGES = {
  temp: [36, 37.8], hr: [60, 100], sbp: [90, 140], dbp: [60, 90], rr: [12, 20], spo2: [95, 100], glucose: [70, 140],
};

function ageGroup(age, months) {
  const a = Number(age);
  const m = Number(months);
  if (Number.isFinite(m) && m < 1) return 'neonate';
  if (Number.isFinite(m) && m < 24) return 'infant';
  if (!Number.isFinite(a)) return 'unknown';
  if (a < 1) return 'infant';
  if (a < 12) return 'pediatric';
  if (a < 18) return 'adolescent';
  if (a >= 65) return 'older_adult';
  return 'adult';
}

function bmiOf(w, h) {
  const kg = Number(w);
  const cm = Number(h);
  if (!kg || !cm) return null;
  return +(kg / Math.pow(cm / 100, 2)).toFixed(1);
}

function interpretVitals(v, age, lang, months) {
  const notes = [];
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  const a = Number(age);
  const mo = Number(months);
  const infant = (Number.isFinite(mo) && mo < 24) || a < 2;
  const ped = infant || a < 12;
  const hrHi = mo < 3 ? 180 : mo < 12 ? 160 : a < 5 ? 140 : a < 12 ? 130 : 100;
  const rrHi = mo < 12 ? 50 : a < 5 ? 40 : a < 12 ? 30 : 20;
  const sbpLo = infant ? 70 : a < 12 ? 80 : 90;
  if (infant && Number.isFinite(mo)) notes.push(t(`Infant pathway: age ${mo} months — use month-based vital ranges, not adult values.`, `مسار الرضيع: العمر ${mo} شهراً — استخدم مدى العلامات حسب الأشهر لا قيم البالغين.`));
  if (v.temp != null && v.temp >= 38) notes.push(t(`Fever ${v.temp}°C — infectious or inflammatory process likely.`, `حمى ${v.temp}°م — ترجّح عملية إنتانية أو التهابية.`));
  if (v.temp != null && v.temp <= 35.5) notes.push(t(`Hypothermia ${v.temp}°C — sepsis, exposure, or endocrine emergency until proven otherwise.`, `انخفاض حرارة ${v.temp}°م — إنتان أو تعرّض أو طارئ غدي حتى يثبت العكس.`));
  if (v.hr != null && v.hr > hrHi) notes.push(t(`Tachycardia ${v.hr} bpm (age-adjusted).`, `تسرّع قلب ${v.hr} ن/د (معدّل حسب العمر).`));
  if (v.hr != null && v.hr < (ped ? (infant ? 90 : 70) : 50)) notes.push(t(`Bradycardia ${v.hr} bpm — high-risk in pediatrics.`, `بطء قلب ${v.hr} ن/د — عالي الخطورة في الأطفال.`));
  if (v.sbp != null && v.sbp < sbpLo) notes.push(t(`Hypotension SBP ${v.sbp} mmHg — treat as shock until stable.`, `انخفاض ضغط انقباضي ${v.sbp} — يُعامل كصدمة حتى الاستقرار.`));
  if (v.sbp != null && v.sbp >= 180) notes.push(t(`Severe hypertension SBP ${v.sbp} mmHg.`, `فرط ضغط شديد ${v.sbp} ملم ز.`));
  if (v.rr != null && v.rr > rrHi) notes.push(t(`Tachypnea ${v.rr}/min (age-adjusted).`, `تسرّع تنفس ${v.rr}/د (حسب العمر).`));
  if (v.spo2 != null && v.spo2 < 92) notes.push(t(`Hypoxemia SpO2 ${v.spo2}% — escalate oxygen and airway assessment.`, `نقص أكسجة ${v.spo2}% — ارفع الأكسجين وقيّم المجرى.`));
  if (v.glucose != null && v.glucose < 70) notes.push(t(`Hypoglycemia ${v.glucose} mg/dL — treat immediately.`, `نقص سكر ${v.glucose} ملغ/دل — عالج فوراً.`));
  if (v.glucose != null && v.glucose >= 250) notes.push(t(`Marked hyperglycemia ${v.glucose} mg/dL — consider DKA/HHS.`, `فرط سكر واضح ${v.glucose} — فكّر في DKA/HHS.`));
  if (!notes.length) notes.push(t('Recorded vital signs are within commonly accepted ranges for this age, or were not provided.', 'العلامات الحيوية المسجّلة ضمن المدى الشائع لهذا العمر، أو لم تُدخل.'));
  return notes;
}

function interpretLabs(labs, sex, age, lang, months) {
  const notes = [];
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  const g = (k) => labs?.[k]?.value;
  const female = sex === 'female';
  const a = Number(age);
  const infant = (Number(months) > 0 && Number(months) < 24) || a < 2;
  const hgbLow = infant ? 10.5 : a < 12 ? 11 : (female ? 12 : 13);
  if (g('wbc') != null && g('wbc') >= 12) notes.push(t(`Leukocytosis WBC ${g('wbc')} — infection, inflammation, or stress.`, `ارتفاع كريات بيض ${g('wbc')} — عدوى أو التهاب أو شدّة.`));
  if (g('wbc') != null && g('wbc') < 4) notes.push(t(`Leukopenia WBC ${g('wbc')} — viral illness, marrow suppression, or sepsis.`, `نقص كريات بيض ${g('wbc')} — فيروس أو كبت نقي أو إنتان.`));
  if (g('hgb') != null && g('hgb') < hgbLow) notes.push(t(`Anemia Hb ${g('hgb')} g/dL (sex-adjusted ${female ? 'female' : 'male'} range).`, `فقر دم خضاب ${g('hgb')} غ/دل (مدى ${female ? 'الإناث' : 'الذكور'}).`));
  if (g('plt') != null && g('plt') < 150) notes.push(t(`Thrombocytopenia ${g('plt')} — bleeding risk.`, `نقص صفائح ${g('plt')} — خطر نزف.`));
  if (g('crp') != null && g('crp') >= 10) notes.push(t(`Elevated CRP ${g('crp')} — systemic inflammation.`, `ارتفاع CRP ${g('crp')} — التهاب جهازي.`));
  if (g('troponin') != null && g('troponin') > 0) notes.push(t(`Detectable troponin ${g('troponin')} — myocardial injury until proven otherwise.`, `تروبونين قابل للقياس ${g('troponin')} — أذية عضلة قلب حتى يثبت العكس.`));
  if (g('lactate') != null && g('lactate') >= 2) notes.push(t(`Lactate ${g('lactate')} mmol/L — tissue hypoperfusion.`, `لاكتات ${g('lactate')} — نقص تروية نسجية.`));
  if (g('d_dimer') != null && g('d_dimer') > 0.5) notes.push(t(`Raised D-dimer ${g('d_dimer')} — consider VTE if pretest probability supports it.`, `ارتفاع D-dimer ${g('d_dimer')} — فكّر في VTE إن دعم الاحتمال السريري.`));
  if (g('creatinine') != null && g('creatinine') > (infant ? 0.5 : a < 12 ? 0.7 : (female ? 1.1 : 1.3))) notes.push(t(`Creatinine ${g('creatinine')} above age/sex-adjusted range — AKI or CKD.`, `كرياتينين ${g('creatinine')} أعلى من مدى العمر/الجنس — إصابة أو مرض كلوي مزمن.`));
  if (g('potassium') != null && (g('potassium') < 3.5 || g('potassium') > 5.2)) notes.push(t(`Potassium ${g('potassium')} mmol/L is unsafe — correct and monitor ECG.`, `بوتاسيوم ${g('potassium')} غير آمن — صحّح وراقب التخطيط.`));
  if (g('sodium') != null && (g('sodium') < 130 || g('sodium') > 150)) notes.push(t(`Sodium ${g('sodium')} mmol/L — correct slowly and seek cause.`, `صوديوم ${g('sodium')} — صحّح ببطء وابحث عن السبب.`));
  if (Number(age) >= 65 && g('hgb') != null) notes.push(t('Older-adult hemoglobin is interpreted with comorbidity and volume status, not isolated numbers.', 'خضاب كبار السن يُفسَّر مع الأمراض المرافقة وحالة الحجم لا بالأرقام وحدها.'));
  if (!notes.length) notes.push(t('No markedly abnormal laboratory values were entered, or labs were omitted.', 'لا توجد قيم مخبرية شاذة بشكل واضح، أو لم تُدخل التحاليل.'));
  return notes;
}

function missingData(caseData, lang) {
  const miss = [];
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  if (caseData.weight == null) miss.push(t('Body weight (required for dosing and fluid calculations).', 'وزن الجسم (لازم للجرعات وحساب السوائل).'));
  if (caseData.height == null) miss.push(t('Height (to calculate BMI and some pediatric/adult dosing).', 'الطول (لحساب مؤشر الكتلة وبعض الجرعات).'));
  if (!(caseData.symptoms || []).length) miss.push(t('Structured symptom list.', 'قائمة أعراض منظّمة.'));
  if (!caseData.vitals || Object.keys(caseData.vitals).length < 3) miss.push(t('A complete vital-sign set (temp, BP, HR, RR, SpO2).', 'مجموعة علامات حيوية كاملة.'));
  if (!caseData.labs || !Object.keys(caseData.labs).length) miss.push(t('Key laboratories (CBC, electrolytes, creatinine, glucose).', 'تحاليل أساسية (تعداد، إلكتروليت، كرياتينين، سكر).'));
  if (!caseData.physicalExam) miss.push(t('Focused physical-assessment findings.', 'موجودات الفحص السريري المركّز.'));
  if (caseData.pregnancy && !caseData.gestationalAge) miss.push(t('Gestational age.', 'عمر الحمل.'));
  if (caseData.gender === 'female' && caseData.pregnancy == null) miss.push(t('Pregnancy status.', 'حالة الحمل.'));
  if ((Number(caseData.age) < 2 || Number(caseData.age) === 0) && !caseData.ageMonths) miss.push(t('Age in months for infants and young children.', 'العمر بالأشهر للرضّع وصغار الأطفال.'));
  return miss;
}

function scoreCondition(c, caseData) {
  const symSet = new Set(caseData.symptoms || []);
  const matchedSymptoms = c.symptoms.filter((s) => symSet.has(s));
  const matchedVitals = [];
  const matchedLabs = [];
  let score = 0;
  for (const s of matchedSymptoms) score += 2;
  if (c.vitals) {
    const vit = caseData.vitals || {};
    for (const k of Object.keys(c.vitals)) {
      const v = vit[k];
      if (v == null) continue;
      const [lo, hi] = c.vitals[k];
      if (v < lo || v > hi) { score += 1.5; matchedVitals.push(k); }
    }
  }
  const rf = [...(caseData.riskFactors || [])];
  if (caseData.smoking === 'current') rf.push('smoking');
  if ((caseData.history || []).some((h) => /diabet/i.test(h))) rf.push('diabetes');
  if ((caseData.history || []).some((h) => /hypertens/i.test(h))) rf.push('hypertension');
  const matchedRisk = (c.riskFactors || []).filter((r) => rf.includes(r) || rf.some((x) => String(x).includes(r)));
  score += matchedRisk.length;
  const a = Number(caseData.age);
  if (c.ageBand && a && a >= c.ageBand[0] && a <= c.ageBand[1]) { score += 1; matchedRisk.push('age'); }
  if (c.pregnancyOnly && !caseData.pregnancy) score -= 5;
  if (caseData.pregnancy && /pre-?eclamp|obstet|pregnan/i.test(c.id + c.name)) score += 3;
  if (a >= 65 && /mi|chf|stroke|pneumonia|sepsis|aki/i.test(c.id)) score += 0.8;
  if (a < 12 && /asthma|bronchiol|gastro|seizure|sepsis/i.test(c.id)) score += 0.8;
  const maxScore = c.symptoms.length * 2 + (c.vitals ? Object.keys(c.vitals).length * 1.5 : 0) + (c.riskFactors ? c.riskFactors.length : 0) + (c.ageBand ? 1 : 0);
  const confidence = Math.min(92, Math.round((score / Math.max(maxScore, 1)) * 100) + (matchedSymptoms.length ? 4 : 0));
  const lang = (caseData.lang || 'en');
  const ar = c.ar || {};
  const symNames = matchedSymptoms.map((id) => (lang === 'ar' ? (findSymptom(id)?.ar || id) : (findSymptom(id)?.en || id)));
  let reasoning = (lang === 'ar' && ar.reasoning) ? ar.reasoning : c.reasoning;
  reasoning += (symNames.length ? ` ${lang === 'ar' ? 'الأعراض المطابقة: ' : 'Matched symptoms: '}${symNames.join(lang === 'ar' ? '، ' : ', ')}.` : '');
  const name = (lang === 'ar' && ar.name) ? ar.name : c.name;
  const redFlags = (lang === 'ar' && ar.redFlags) ? ar.redFlags : c.redFlags;
  return { id: c.id, name, name_en: c.name_en, confidence, score, maxScore, matchedSymptoms, matchedRisk, matchedVitals, matchedLabs, reasoning, redFlags };
}

export function carePlanTool(caseData) {
  const lang = (caseData && caseData.lang) || 'en';
  const r = analyzeCase(caseData);
  if (!r || r.error || !r.sections || !r.sections.nursing) {
    return { error: lang === 'ar' ? 'لا توجد خطة رعاية متاحة.' : 'No care plan available.', carePlan: null };
  }
  const n = r.sections.nursing;
  return {
    carePlan: {
      diagnosis: (r.differentials || [])[0]?.name || '',
      nanda: n.nanda || [],
      nic: n.nic || [],
      goals: n.goals || [],
      evaluation: n.evaluation || [],
      interventions: n.assessment || [],
      education: n.education || [],
      discharge: n.discharge || [],
    },
  };
}

export function analyzeCase(caseData, relatedPdfs = []) {
  const lang = (caseData && caseData.lang) || 'en';
  const t = (en, ar) => (lang === 'ar' ? ar : en);
  if (!caseData || (!(caseData.symptoms || []).length && !(caseData.chiefComplaint || '').trim())) {
    return { error: t('Enter the chief complaint or symptoms to analyze the case.', 'أدخل الشكوى الرئيسية أو الأعراض لتحليل الحالة.'), differentials: [], sections: { investigations: [], treatment: {}, nursing: {}, drugs: [], redFlags: [], references: [] }, relatedPdfs: [] };
  }
  const scored = CONDITIONS.map((c) => scoreCondition(c, caseData))
    .sort((a, b) => b.score - a.score || b.confidence - a.confidence);
  const best = scored[0];
  const top = best ? CONDITIONS.find((c) => c.id === best.id) : null;
  if (!top || best.score <= 0) {
    return { error: t('Not enough matching clinical features for a supported working diagnosis.', 'لا توجد سمات سريرية كافية لتشخيص عامل مدعوم.'), differentials: [], sections: { investigations: [], treatment: {}, nursing: {}, drugs: [], redFlags: [], references: [] }, relatedPdfs: [] };
  }
  const ar = top.ar || {};
  const grp = ageGroup(caseData.age, caseData.ageMonths);
  const bmi = bmiOf(caseData.weight, caseData.height);
  const miss = missingData(caseData, lang);
  const vitalNotes = interpretVitals(caseData.vitals || {}, caseData.age, lang, caseData.ageMonths);
  const labNotes = interpretLabs(caseData.labs || {}, caseData.gender, caseData.age, lang, caseData.ageMonths);

  const riskLabels = (top.riskFactors || []).map((r) => {
    if (r === 'age>50' || r === 'age>65') return t('older adult', 'كبر السن');
    if (r === 'age<5') return t('young child', 'الأطفال');
    return r.replace(/_/g, ' ');
  });
  const evid = best.matchedSymptoms.map((id) => (lang === 'ar' ? (findSymptom(id)?.ar || id) : (findSymptom(id)?.en || id)));
  const nandaFull = (top.nursing?.nanda || []).map((d, i) => {
    const rel = riskLabels.length ? t(`related to ${riskLabels.join(', ')}`, `مرتبط بـ ${riskLabels.join('، ')}`) : '';
    const ev = evid.length ? t(`as evidenced by ${evid.join(', ')}`, `مُدعوم بـ ${evid.join('، ')}`) : '';
    const rank = i + 1;
    return `${rank}. ${[d, rel, ev].filter(Boolean).join(' — ')}`;
  });

  const ageNote = {
    neonate: t('Neonatal physiology: higher surface-area/weight ratio, immature immunity, and rapid decompensation. Weight-based fluids and glucose are mandatory.', 'فسيولوجيا حديثي الولادة: نسبة سطح/وزن أعلى، مناعة غير ناضجة، وتدهور سريع. السوائل والسكر حسب الوزن إلزاميان.'),
    infant: t(`Infant analysis${caseData.ageMonths ? ` (${caseData.ageMonths} months)` : ''}: month-based vitals, weight-based dosing only, and caregiver history. Never apply adult lab or BP ranges.`, `تحليل الرضيع${caseData.ageMonths ? ` (${caseData.ageMonths} شهراً)` : ''}: علامات حسب الأشهر، جرعات حسب الوزن فقط، وتاريخ من مقدّم الرعاية. لا تستخدم مدى البالغين.`),
    pediatric: t('Pediatric analysis: age-adjusted vitals, weight-based dosing, and caregiver history are required. Avoid adult reference ranges.', 'تحليل أطفال: علامات حيوية حسب العمر، جرعات حسب الوزن، وتاريخ من مقدّم الرعاية. تجنّب مدى البالغين.'),
    adolescent: t('Adolescent analysis: consider pregnancy/contraception in females, adherence, and emerging adult disease patterns.', 'تحليل المراهقين: راعِ الحمل/منع الحمل في الإناث، الالتزام، وأنماط أمراض البالغين الناشئة.'),
    adult: t('Adult analysis: integrate occupational, pregnancy, and metabolic risk with the presenting syndrome.', 'تحليل البالغين: ادمج مخاطر المهنة والحمل والاستقلاب مع المتلازمة الحالية.'),
    older_adult: t('Older-adult analysis: atypical presentations, polypharmacy, frailty, delirium risk, and renal dosing adjustments.', 'تحليل كبار السن: أعراض غير نمطية، تعدد أدوية، وهن، خطر هذيان، وتعديل جرعات كلوية.'),
    unknown: t('Age was not provided; pediatric versus geriatric pathways cannot be applied safely.', 'العمر غير متوفر؛ لا يمكن تطبيق مسارات الأطفال أو المسنين بأمان.'),
  }[grp];

  const sexNote = caseData.gender === 'female'
    ? t('Sex-specific: use female laboratory ranges (e.g. Hb, creatinine), consider pregnancy/breastfeeding contraindications, and ACS may present atypically.', 'خصوصيات الجنس: استخدم مدى الإناث المخبري، راعِ موانع الحمل/الرضاعة، وقد تظهر المتلازمة التاجية بشكل غير نمطي.')
    : caseData.gender === 'male'
      ? t('Sex-specific: male reference ranges for Hb/creatinine; higher baseline ACS and AAA risk after midlife.', 'خصوصيات الجنس: مدى الذكور للخضاب/الكرياتينين؛ خطر أعلى للمتلازمة التاجية وأمهات الدم بعد منتصف العمر.')
      : t('Sex was not specified; sex-adjusted labs and obstetric contraindications cannot be applied.', 'الجنس غير محدد؛ لا يمكن تطبيق التحاليل المعدّلة أو موانع التوليد.');

  const weightNote = caseData.weight
    ? t(`Weight ${caseData.weight} kg${bmi ? ` (BMI ${bmi})` : ''} is used for drug dose, fluid bolus, and nutrition planning.`, `الوزن ${caseData.weight} كجم${bmi ? ` (مؤشر كتلة ${bmi})` : ''} يُستخدم للجرعة والبلعة الغذائية والتخطيط الغذائي.`)
    : t('Weight missing — do not guess mg/kg doses.', 'الوزن ناقص — لا تخمّن جرعات ملغ/كجم.');

  const pregnancyNote = caseData.pregnancy
    ? t(`Pregnancy documented${caseData.gestationalAge ? ` at ${caseData.gestationalAge} weeks` : ''}${caseData.breastfeeding ? '; breastfeeding' : ''}. Avoid ACE inhibitors, ARBs, NSAIDs in late pregnancy, and many contrast/drug classes unless obstetric-approved.`, `حمل موثّق${caseData.gestationalAge ? ` عند الأسبوع ${caseData.gestationalAge}` : ''}${caseData.breastfeeding ? '؛ وإرضاع' : ''}. تجنّب مثبطات ACE وARB ومضادات الالتهاب في أواخر الحمل وكثيراً من الأصناف إلا بموافقة توليدية.`)
    : '';

  const primaryName = (lang === 'ar' && ar.name) ? ar.name : top.name;
  const support = [
    best.reasoning,
    evid.length ? t(`Key supporting symptoms: ${evid.join(', ')}.`, `أعراض داعمة رئيسة: ${evid.join('، ')}.`) : '',
    best.matchedVitals.length ? t(`Concordant vital abnormalities: ${best.matchedVitals.join(', ')}.`, `اختلالات حيوية متوافقة: ${best.matchedVitals.join('، ')}.`) : '',
    caseData.physicalExam ? t(`Physical assessment considered: ${String(caseData.physicalExam).slice(0, 280)}`, `رُوعي الفحص السريري: ${String(caseData.physicalExam).slice(0, 280)}`) : '',
  ].filter(Boolean);

  const drugs = (top.drugs || []).map((d) => {
    const extra = [];
    if (grp === 'pediatric' || grp === 'neonate') extra.push(t('Use the pediatric/weight-based dose; do not default to adult tablets.', 'استخدم جرعة الأطفال/الوزن؛ لا تعتمد أقراص البالغين.'));
    if (grp === 'older_adult') extra.push(t('Start low and go slow; check renal function before accumulation-prone drugs.', 'ابدأ منخفضاً وتدرّج ببطء؛ راجع وظائف الكلى قبل الأدوية المتراكمة.'));
    if (caseData.pregnancy) extra.push(t('Confirm pregnancy category / lactation safety before administration.', 'أكّد مأمونية الحمل/الرضاعة قبل الإعطاء.'));
    return { ...d, nursing: [d.nursing, ...extra].filter(Boolean).join(' ') };
  });

  const priorities = nandaFull.map((item, i) => ({
    rank: i + 1,
    diagnosis: item,
    rationale: i === 0
      ? t('Highest priority: airway, breathing, circulation, or life-threatening instability first.', 'الأولوية الأعلى: المجرى والتنفس والدورة أو عدم الاستقرار المهدد أولاً.')
      : t('Address after life-threatening problems are controlled.', 'يُعالج بعد السيطرة على المشكلات المهددة للحياة.'),
  }));

  const summary = [
    t(`Working educational diagnosis: ${primaryName} (confidence ${Math.min(92, best.confidence)}%).`, `التشخيص التعليمي العامل: ${primaryName} (ثقة ${Math.min(92, best.confidence)}٪).`),
    ageNote,
    sexNote,
    weightNote,
    pregnancyNote,
    t('This is not a confirmed medical diagnosis and must not replace bedside evaluation.', 'هذا ليس تشخيصاً طبياً مؤكداً ولا يغني عن التقييم عند السرير.'),
  ].filter(Boolean);

  const findings = collectFindings(caseData);
  const retrieved = retrieveEvidence(caseData, top.id);
  const evCheck = evidenceCheck(top, retrieved, findings, lang);
  const pubmed = pubmedSearchUrl(`${top.name_en || top.name} ${grp} ${caseData.gender || ''} nursing guideline`);
  const retrievedRefs = retrieved.map((d) => ({
    abbr: d.org,
    url: d.url,
    note: `${d.title}${d.liveChecked ? (d.liveOk ? ' · live-checked' : ' · URL not confirmed this request') : ''}`,
    liveOk: d.liveOk,
  }));
  const kbRefs = (top.refs || []).filter((r) => !retrievedRefs.some((x) => x.url === r.url));
  const references = [
    ...retrievedRefs,
    ...kbRefs,
    { abbr: 'PubMed', url: pubmed, note: t('Search of indexed literature for this working diagnosis (not a fabricated citation).', 'بحث في الأدبيات المفهرسة لهذا التشخيص العامل (وليس مرجعاً مختلقاً).') },
  ];

  const disclaimer = t(
    'This tool is for educational purposes only and does not replace professional medical evaluation. It never claims 100% diagnostic accuracy and must not fabricate missing patient data. Recommendations are grounded in retrieved guideline pages, not model memory alone.',
    'هذه الأداة لأغراض تعليمية فقط ولا تستبدل التقييم الطبي المهني. لا تدّعي دقة تشخيصية 100٪ ولا تختلق بيانات المريض الناقصة. التوصيات مستندة إلى صفحات إرشادية مُسترجَعة وليس إلى ذاكرة النموذج وحدها.',
  );

  const nursingOut = {
    assessment: top.nursing?.assessment || [],
    nanda: nandaFull,
    nic: top.nursing?.nic || [],
    goals: (top.nursing?.goals || []).map((g) => (lang === 'ar' ? g : `The patient will ${g.charAt(0).toLowerCase()}${g.slice(1)}`)),
    education: top.nursing?.education || [],
    discharge: top.nursing?.discharge || [],
    evaluation: top.nursing?.evaluation || [],
    priorities,
  };

  return {
    disclaimer,
    generatedAt: new Date().toISOString(),
    primaryDiagnosis: {
      id: top.id,
      name: primaryName,
      name_en: top.name_en || top.name,
      confidence: Math.min(92, best.confidence),
      support,
      keyFindings: evid,
      missingInformation: miss,
    },
    profileAnalysis: {
      ageGroup: grp,
      ageNote,
      sexNote,
      weightNote,
      pregnancyNote,
      bmi,
      vitalNotes,
      labNotes,
    },
    clinicalSummary: summary,
    evidencePipeline: {
      findingsCollected: findings.length,
      sourcesRetrieved: retrieved.length,
      check: evCheck,
      retrieved,
    },
    // Single working diagnosis only — never expose competing names to the learner UI.
    differentials: [{ ...best, name: primaryName, confidence: Math.min(92, best.confidence) }],
    sections: {
      investigations: top.investigations,
      treatment: top.treatment,
      nursing: nursingOut,
      drugs,
      redFlags: (lang === 'ar' && ar.redFlags) ? ar.redFlags : top.redFlags,
      references,
    },
    relatedPdfs,
  };
}

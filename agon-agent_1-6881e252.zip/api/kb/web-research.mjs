/**
 * Real-time retrieval from public scientific APIs.
 * PubMed E-utilities + Europe PMC — no API key, no invented citations.
 */

async function fetchJson(url, ms = 4000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'KhulasaClinicalAssistant/1.0 (educational)' },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

function cleanTerm(s) {
  return String(s || '')
    .replace(/[^\w\s\u0600-\u06ff-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 180);
}

export function buildQueries(caseData, diagnosisName) {
  const age = Number(caseData.age);
  const months = Number(caseData.ageMonths);
  const band = !Number.isFinite(age) ? 'adult'
    : (age < 1 || (months && months < 24)) ? 'pediatric infant'
      : age < 18 ? 'pediatric'
        : age >= 65 ? 'older adult geriatric'
          : 'adult';
  const sex = caseData.gender === 'female' ? 'female' : caseData.gender === 'male' ? 'male' : '';
  const preg = caseData.pregnancy ? 'pregnancy' : '';
  const dx = cleanTerm(diagnosisName || caseData.chiefComplaint || 'clinical nursing');
  const cc = cleanTerm(caseData.chiefComplaint);
  return {
    primary: `${dx} ${band} ${sex} ${preg} guideline`.replace(/\s+/g, ' ').trim(),
    nursing: `${dx} nursing care NANDA ${band}`.replace(/\s+/g, ' ').trim(),
    emergency: `${dx} red flags emergency management ${band}`.replace(/\s+/g, ' ').trim(),
    chief: cc ? `${cc} ${band} evidence based` : '',
  };
}

async function searchPubMed(term, retmax = 5) {
  if (!term) return [];
  const searchUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=${retmax}&sort=relevance&term=${encodeURIComponent(term)}`;
  const search = await fetchJson(searchUrl);
  const ids = search?.esearchresult?.idlist || [];
  if (!ids.length) return [];
  const sumUrl = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=${ids.join(',')}`;
  const sum = await fetchJson(sumUrl);
  const result = sum?.result || {};
  return ids.map((id) => {
    const r = result[id] || {};
    const year = (r.pubdate || '').slice(0, 4);
    return {
      source: 'PubMed',
      id: `pmid:${id}`,
      title: r.title || `PubMed ${id}`,
      authors: Array.isArray(r.authors) ? r.authors.slice(0, 3).map((a) => a.name).join(', ') : '',
      year,
      journal: r.fulljournalname || r.source || 'PubMed',
      url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
      query: term,
    };
  });
}

async function searchEuropePmc(term, pageSize = 4) {
  if (!term) return [];
  const url = `https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=${encodeURIComponent(term)}&format=json&pageSize=${pageSize}&resultType=lite`;
  const data = await fetchJson(url);
  const hits = data?.resultList?.result || [];
  return hits.map((r) => ({
    source: 'Europe PMC',
    id: r.pmid ? `pmid:${r.pmid}` : `epmc:${r.id}`,
    title: r.title || 'Untitled',
    authors: r.authorString || '',
    year: String(r.pubYear || ''),
    journal: r.journalTitle || 'Europe PMC',
    url: r.pmid
      ? `https://pubmed.ncbi.nlm.nih.gov/${r.pmid}/`
      : `https://europepmc.org/article/${r.source}/${r.id}`,
    query: term,
  }));
}

const GUIDELINE_PORTALS = [
  { org: 'NICE', url: (q) => `https://www.nice.org.uk/search?q=${encodeURIComponent(q)}` },
  { org: 'WHO', url: (q) => `https://www.who.int/home/search-results?indexCatalogue=genericsearchindex1&searchQuery=${encodeURIComponent(q)}` },
  { org: 'CDC', url: (q) => `https://search.cdc.gov/search/?query=${encodeURIComponent(q)}` },
  { org: 'PubMed', url: (q) => `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(q)}` },
  { org: 'Cochrane', url: (q) => `https://www.cochranelibrary.com/search?q=${encodeURIComponent(q)}` },
];

export async function runWebResearch(caseData, diagnosisName) {
  const queries = buildQueries(caseData, diagnosisName);
  const started = Date.now();
  const [p1, p2, e1] = await Promise.all([
    searchPubMed(queries.primary, 5),
    searchPubMed(queries.nursing, 3),
    searchEuropePmc(queries.primary || queries.chief, 4),
  ]);

  const seen = new Set();
  const articles = [];
  for (const item of [...p1, ...p2, ...e1]) {
    if (!item?.url || seen.has(item.url) || seen.has(item.id)) continue;
    seen.add(item.url);
    seen.add(item.id);
    articles.push(item);
  }

  const portals = GUIDELINE_PORTALS.map((g) => ({
    org: g.org,
    title: `${g.org} live search: ${queries.primary}`,
    url: g.url(queries.primary),
    dynamic: true,
  }));

  return {
    ranAt: new Date().toISOString(),
    durationMs: Date.now() - started,
    queries,
    articles: articles.slice(0, 10),
    portals,
    provider: articles.length ? 'pubmed+europepmc' : 'portals-only',
  };
}

/**
 * Instructor-style teaching notes for stable nursing/medical concepts.
 * Used so simple questions get a real explanation — not a disclaimer or a paper dump.
 * Live retrieval is layered on top when the question is current, drug, or guideline-heavy.
 */

export const LESSONS = {
  'diabetic ketoacidosis': {
    aliases: ['dka', 'حماض كيتوني', 'ketoacidosis'],
    en: {
      define: 'DKA (diabetic ketoacidosis) is a life-threatening state of insulin deficiency: glucose cannot enter cells, the body burns fat, ketones accumulate, and the blood becomes acidic.',
      causes: 'It is usually triggered by missed insulin, new-onset type 1 diabetes, infection, or another physiologic stress. Without insulin, lipolysis floods the liver with free fatty acids and ketogenesis takes off.',
      signs: 'Think polyuria, polydipsia, nausea, abdominal pain, Kussmaul breathing, fruity breath, dehydration, and altered consciousness. Glucose is high, ketones are present, and pH/bicarbonate fall.',
      potassium: 'Serum potassium often looks normal or high at first because acidosis and insulin lack shift K+ out of cells — but total body potassium is low. It can crash once insulin and fluids start, so you replace K+ and never start insulin if potassium is already critically low.',
      nursing: 'Priority nursing work: ABC, frequent glucose and electrolytes, strict intake/output, cardiac monitoring, insulin infusion as ordered, and watching for cerebral edema especially in children. Do not invent a dose — it is weight- and protocol-based.',
      meds: 'The backbone is IV fluids, potassium replacement when indicated, and a regular-insulin infusion per protocol. Bicarbonate is not routine. Hold guessing at units/hour without weight, potassium, and the local DKA protocol.',
    },
    ar: {
      define: 'الحماض الكيتوني السكري (DKA) حالة مهددة للحياة من نقص الإنسولين: السكر لا يدخل الخلايا، فيحرق الجسم الدهون، تتراكم الكيتونات، ويصبح الدم حمضياً.',
      causes: 'غالباً ما يُستثار بنسيان الإنسولين، أو سكري نمط 1 حديث، أو عدوى/شدة فسيولوجية. بلا إنسولين تتحلل الدهون ويصنع الكبد الكيتونات.',
      signs: 'بوال وعطش وغثيان وألم بطن وتنفس كوسماول ورائحة فواكه وجفاف واضطراب وعي. السكر مرتفع، الكيتونات موجودة، والـ pH والبيكربونات ينخفضان.',
      potassium: 'البوتاسيوم في الدم قد يبدو طبيعياً أو مرتفعاً في البداية لأن الحماض يُخرج K+ من الخلايا — لكن مخزون الجسم منخفض. قد يهبط بقوة بعد الإنسولين والسوائل، لذلك يُعوَّض ولا يُبدأ الإنسولين إذا كان البوتاسيوم منخفضاً جداً.',
      nursing: 'أولويات التمريض: مجرى الهواء والتنفس والدورة، سكر وإلكتروليتات متكررة، إدخال وإخراج، مراقبة قلبية، تسريب إنسولين حسب الأمر، ومراقبة وذمة دماغية خصوصاً في الأطفال. لا تخمّن الجرعة.',
      meds: 'الأساس سوائل وريدية، تعويض بوتاسيوم عند اللزوم، وتسريب إنسولين منتظم حسب البروتوكول. البيكربونات ليست روتينية. لا تقدّر الوحدات/ساعة بدون وزن وبوتاسيوم وبروتوكول القسم.',
    },
    sources: [
      { org: 'ADA', title: 'ADA Standards of Care — hyperglycemic crises', url: 'https://diabetesjournals.org/care' },
      { org: 'NICE', title: 'NICE diabetes / DKA pathway', url: 'https://www.nice.org.uk/guidance' },
    ],
  },
  'heart failure': {
    aliases: ['chf', 'hfref', 'hfpef', 'فشل القلب'],
    en: {
      define: 'Heart failure means the heart cannot pump or fill well enough for the body’s needs, so congestion and poor perfusion develop.',
      causes: 'Common drivers are ischemic disease, long-standing hypertension, valvular disease, arrhythmia, and cardiomyopathy. An acute flare is often set off by ischemia, infection, missed meds, or extra salt/fluid.',
      signs: 'Look for dyspnea, orthopnea, PND, edema, raised JVP, crackles, and fatigue. Vitals may show tachycardia, hypoxia, or hypertension; BNP and chest x-ray support congestion.',
      nursing: 'Sit the patient up, give oxygen to target, track daily weight and fluid balance, give loop diuretics as ordered, and watch electrolytes and blood pressure. Teach salt, weight, and when to come back.',
      meds: 'After congestion is treated, guideline-directed therapy typically includes an ACEI/ARNI, evidence-based beta-blocker, MRA, and SGLT2 inhibitor — titrated, not dumped all at once. Do not invent starting doses without renal function and blood pressure.',
    },
    ar: {
      define: 'فشل القلب يعني أن القلب لا يضخ أو لا يمتلئ بما يكفي لاحتياج الجسم، فيظهر الاحتقان وضعف التروية.',
      causes: 'أشيع الأسباب: إقفار، ضغط مزمن، صمامات، اضطراب نظم، أو اعتلال عضلة. النوبة الحادة كثيراً ما تُستثار بإقفار أو عدوى أو نسيان دواء أو ملح زائد.',
      signs: 'ضيق نفس واضطجاع ليلي ووذمة وارتفاع ضغط الوريد الوداجي وخراخر وإرهاق. قد يظهر تسرّع قلب أو نقص أكسجة؛ الـ BNP وصورة الصدر يدعمان الاحتقان.',
      nursing: 'أجلس المريض، أكسجين حسب الهدف، وزن يومي وتوازن سوائل، مدر عروة حسب الأمر، وراقب الإلكتروليت والضغط. علّم الملح والوزن وعلامات العودة.',
      meds: 'بعد فك الاحتقان يأتي علاج موجَّه بالدليل: ACEI/ARNI وحاصر بيتا وMRA وSGLT2 — بالتدريج. لا تخمّن جرعة البداية دون وظائف كلى وضغط.',
    },
    sources: [
      { org: 'AHA/ACC', title: 'Heart failure guideline', url: 'https://www.ahajournals.org' },
      { org: 'ESC', title: 'ESC heart failure guideline', url: 'https://www.escardio.org' },
    ],
  },
  'community acquired pneumonia': {
    aliases: ['pneumonia', 'cap', 'التهاب رئوي'],
    en: {
      define: 'Community-acquired pneumonia is an acute infection of the lung parenchyma acquired outside hospital — alveoli fill with inflammatory exudate and gas exchange falls.',
      causes: 'Typical bacteria (e.g. pneumococcus), atypicals, and viruses. Risk rises with age, smoking, aspiration, and chronic lung disease.',
      signs: 'Fever, cough, sputum, pleuritic pain, tachypnea, hypoxia, and focal crackles. CXR supports the diagnosis; WBC/CRP may be up.',
      nursing: 'Oxygen to target, sit up, cultures before antibiotics if that will not delay care, monitor work of breathing, and reassess in 48–72 hours. Escalate if the patient tiring or saturations falling.',
      meds: 'Empiric antibiotics follow severity and local resistance (often a beta-lactam ± macrolide if admitted). Do not pick a drug/dose without allergies, pregnancy, and renal function.',
    },
    ar: {
      define: 'الالتهاب الرئوي المكتسب من المجتمع عدوى حادة في متن الرئة خارج المستشفى — تمتلئ الأسناخ بسائل التهابي ويضعف تبادل الغازات.',
      causes: 'بكتيريا نمطية (مثل المكورة الرئوية) وغير نمطية وفيروسات. يزداد الخطر مع العمر والتدخين والاستنشاق وأمراض الرئة المزمنة.',
      signs: 'حمى وسعال وبلغم وألم جنبي وتسرّع تنفس ونقص أكسجة وخراخر بؤرية. صورة الصدر تدعم التشخيص.',
      nursing: 'أكسجين حسب الهدف، جلوس، مزارع قبل المضاد إن لم يؤخر العلاج، راقب عمل التنفس، وأعد التقييم خلال 48–72 ساعة.',
      meds: 'المضاد التجريبي حسب الشدة والمقاومة المحلية. لا تختر دواء/جرعة دون حساسية وحمل ووظائف كلى.',
    },
    sources: [
      { org: 'IDSA/ATS', title: 'Adult CAP guideline', url: 'https://www.idsociety.org/practice-guideline/community-acquired-pneumonia-cap-in-adults/' },
      { org: 'NICE', title: 'NICE NG138 pneumonia', url: 'https://www.nice.org.uk/guidance/ng138' },
    ],
  },
  'sepsis': {
    aliases: ['septic shock', 'إنتان', 'صدمة إنتانية'],
    en: {
      define: 'Sepsis is a dysregulated host response to infection that begins to damage the person’s own organs. Septic shock is sepsis with persistent hypotension needing vasopressors and a raised lactate.',
      causes: 'Any infection can do it — lung, urine, abdomen, skin, line. The danger is the immune cascade, not only the germ.',
      signs: 'Fever or hypothermia, tachycardia, tachypnea, confusion, oliguria, mottling, and hypotension. qSOFA-type clues plus a source of infection should make you move fast.',
      nursing: 'Hour-1 thinking: cultures, antibiotics as ordered without delay, lactate, fluids if hypoperfused and eligible, oxygen, urine output, and find the source. This is an emergency, not a wait-and-see fever.',
      meds: 'Broad antibiotics first, then narrow. Fluids then norepinephrine if shock persists. Do not invent a pressor rate.',
    },
    ar: {
      define: 'الإنتان استجابة مضطربة للعدوى تبدأ بإيذاء أعضاء المريض. الصدمة الإنتانية إنتان مع ضغط منخفض يحتاج ضاغطات ولاكتات مرتفع.',
      causes: 'أي بؤرة: رئة، بول، بطن، جلد، قسطرة. الخطر في شلال المناعة لا في الجرثومة وحدها.',
      signs: 'حمى أو انخفاض حرارة، تسرّع قلب وتنفس، تشوش، قلة بول، ت mottling، وهبوط ضغط.',
      nursing: 'فكّر بساعة أولى: مزارع، مضاد بلا تأخير، لاكتات، سوائل إن نقصت التروية، أكسجين، إدرار، وابحث عن المصدر. هذا طارئ.',
      meds: 'مضاد واسع ثم تضييق. سوائل ثم نورأدرينالين إن بقيت الصدمة. لا تخمّن معدل الضاغط.',
    },
    sources: [
      { org: 'SSC/SCCM', title: 'Surviving Sepsis Campaign', url: 'https://www.sccm.org/clinical-resources/guidelines/guidelines/surviving-sepsis-campaign' },
      { org: 'WHO', title: 'WHO sepsis', url: 'https://www.who.int/news-room/fact-sheets/detail/sepsis' },
    ],
  },
  'hypovolemic shock': {
    aliases: ['hypovolemia', 'نقص حجم', 'صدمة نقص'],
    en: {
      define: 'Hypovolemic shock is inadequate tissue perfusion because circulating volume is too low — blood loss or severe fluid loss.',
      causes: 'Hemorrhage, GI losses, burns, third-spacing. The pump is often fine; the tank is empty.',
      signs: 'Tachycardia, weak pulses, cool skin, delayed cap refill, oliguria, then hypotension. In kids, blood pressure drops late — treat the picture, not the number alone.',
      nursing: 'Stop the loss if you can, large-bore access, fluids or blood as ordered, keep warm, serial vitals, and watch mental status. Children get weight-based boluses — not adult liters by default.',
      meds: 'Crystalloid or blood products depending on the loss. Vasopressors are not first-line until volume is addressed.',
    },
    ar: {
      define: 'صدمة نقص الحجم نقص تروية لأن حجم الدم الدائر قليل — نزف أو فقد سوائل شديد.',
      causes: 'نزف، فقد هضمي، حروق، أو تجمّع ثالث. المضخة غالباً سليمة والخزان فارغ.',
      signs: 'تسرّع قلب، نبض ضعيف، جلد بارد، إعادة امتلاء بطيئة، قلة بول، ثم هبوط ضغط. في الأطفال يتأخر هبوط الضغط.',
      nursing: 'أوقف الفقد إن أمكن، وصول واسع، سوائل أو دم حسب الأمر، دفء، علامات متكررة. الأطفال ببلعات حسب الوزن.',
      meds: 'بلورات أو مشتقات دم حسب نوع الفقد. الضاغطات ليست الخط الأول قبل تعويض الحجم.',
    },
    sources: [
      { org: 'AHA', title: 'Emergency cardiovascular care / shock', url: 'https://www.heart.org' },
      { org: 'WHO', title: 'WHO emergency care', url: 'https://www.who.int' },
    ],
  },
  'anaphylaxis': {
    aliases: ['anaphylactic', 'تأق'],
    en: {
      define: 'Anaphylaxis is a rapidly evolving, life-threatening allergic reaction that can close the airway, drop the blood pressure, and involve skin and gut at once.',
      signs: 'Urticaria, swelling, wheeze or stridor, vomiting, and shock. Do not wait for every system to join in.',
      nursing: 'IM adrenaline into the mid-anterolateral thigh immediately, lie the patient flat if breathing allows, oxygen, fluids, and observe for a second wave. Antihistamines and steroids do not replace adrenaline.',
      meds: 'Adrenaline IM is first-line. Adult 0.5 mg of 1:1000; children 0.01 mg/kg (max per local protocol). Repeat after 5 minutes if needed. Confirm the concentration before you draw.',
    },
    ar: {
      define: 'التأق تفاعل تحسسي سريع مهدد قد يغلق المجرى ويهبط الضغط ويصيب الجلد والأمعاء معاً.',
      signs: 'شرى، تورم، أزيز أو صرير، قيء، وصدمة. لا تنتظر إصابة كل الأجهزة.',
      nursing: 'أدرينالين عضلي في منتصف الفخذ الجانبي فوراً، استلقاء إن سمح التنفس، أكسجين وسوائل، وراقب موجة ثانية. مضاد الهيستامين والستيرويد لا يغنيان عن الأدرينالين.',
      meds: 'الأدرينالين العضلي أولاً. بالغ 0.5 مجم 1:1000؛ طفل 0.01 مجم/كجم حسب البروتوكول. كرّر بعد 5 دقائق إن لزم. أكّد التركيز قبل السحب.',
    },
    sources: [
      { org: 'NICE', title: 'NICE CG134 Anaphylaxis', url: 'https://www.nice.org.uk/guidance/cg134' },
    ],
  },
  asthma: {
    aliases: ['ربو', 'asthma exacerbation'],
    en: {
      define: 'Asthma is reversible airway inflammation and bronchoconstriction. An exacerbation is an acute worsening of wheeze, cough, and breathlessness.',
      signs: 'Expiratory wheeze, tight chest, accessory muscles, tachycardia. A silent chest or exhaustion is an emergency.',
      nursing: 'Sit up, oxygen to target, repeated SABA, early systemic steroid as ordered, peak flow if able. Do not sedate a tiring asthmatic.',
      meds: 'SABA (salbutamol) first, add ipratropium if severe, plus a short steroid course. Magnesium IV is for life-threatening attacks under a protocol.',
    },
    ar: {
      define: 'الربو التهاب وتضيّق عكوس في القصبات. النوبة تدهور حاد في الأزيز والسعال وضيق النفس.',
      signs: 'أزيز زفيري، ضيق صدر، عضلات مساعدة. الصدر الصامت أو الإرهاق طارئ.',
      nursing: 'جلوس، أكسجين، سالبوتامول متكرر، ستيرويد جهازي مبكراً حسب الأمر. لا تهدّئ مريضاً يَتعب.',
      meds: 'موسع قصبي قصير أولاً، إيبراتروبيوم إن كانت شديدة، وكورس ستيرويد قصير.',
    },
    sources: [
      { org: 'GINA', title: 'GINA asthma strategy', url: 'https://ginasthma.org/' },
    ],
  },
  copd: {
    aliases: ['سدة', 'copd exacerbation'],
    en: {
      define: 'COPD is persistent airflow limitation, usually from smoking. An exacerbation is an acute rise in dyspnea, cough, or sputum.',
      signs: 'Wheeze, productive cough, hypoxia. Confusion may mean CO2 retention.',
      nursing: 'Controlled oxygen — often 88–92% if a retainer — bronchodilators, steroids, and antibiotics if sputum turns purulent. Watch for tiring and rising CO2.',
      meds: 'SABA + ipratropium, a short steroid burst, and antibiotics when indicated. Uncontrolled high-flow oxygen can harm retainers.',
    },
    ar: {
      define: 'السدة الرئوية المزمنة تحدّد جريان هواء مستمر، غالباً من التدخين. التفاقم زيادة حادة في الضيق أو السعال أو البلغم.',
      signs: 'أزيز وسعال منتج ونقص أكسجة. التشوش قد يعني احتباس CO2.',
      nursing: 'أكسجين مضبوط — غالباً 88–92% إن كان محتفظاً بـ CO2 — موسعات وستيرويد ومضاد إن تقيّح البلغم.',
      meds: 'موسع + إيبراتروبيوم وكورس ستيرويد قصير. الأكسجين العالي غير المنضبط قد يضر.',
    },
    sources: [
      { org: 'GOLD', title: 'GOLD COPD', url: 'https://goldcopd.org/' },
    ],
  },
};

export function matchLesson(topic, question, historyText) {
  const blob = `${topic || ''} ${question || ''} ${historyText || ''}`.toLowerCase();
  for (const [id, lesson] of Object.entries(LESSONS)) {
    if (blob.includes(id) || (lesson.aliases || []).some((a) => blob.includes(a))) return { id, lesson };
  }
  return null;
}

export function teachFromLesson(lesson, intent, lang) {
  const pack = lang === 'ar' ? lesson.ar : lesson.en;
  const want = [];
  if (intent === 'causes') want.push(pack.causes);
  else if (intent === 'signs') want.push(pack.signs);
  else if (intent === 'nursing') want.push(pack.nursing);
  else if (intent === 'meds') want.push(pack.meds);
  else if (intent === 'specific' && pack.potassium) want.push(pack.potassium);
  else if (intent === 'full') {
    want.push(pack.define, pack.causes, pack.signs, pack.nursing, pack.meds);
  } else {
    want.push(pack.define);
    if (intent === 'explain' || intent === 'general') {
      if (pack.causes) want.push(pack.causes);
      if (pack.signs) want.push(pack.signs);
    }
  }
  return want.filter(Boolean).join('\n\n');
}

export function needsLiveResearch(question, intent) {
  const s = String(question || '').toLowerCase();
  if (intent === 'meds') return true;
  if (/guideline|latest|current|202[3-9]|dose|protocol|توصية|أحدث/.test(s)) return true;
  if (/controversial|new evidence|meta-?analysis/.test(s)) return true;
  return false;
}

/** Live retrieval used ONLY when the user asks for sources / verification. */

async function fetchJson(url, ms = 5000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'KhulasaNursingChat/2.0 (educational)' },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

async function fetchText(url, ms = 5000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'KhulasaNursingChat/2.0 (educational)' },
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  } finally {
    clearTimeout(t);
  }
}

function clean(s) {
  return String(s || '').replace(/[^\w\s\u0600-\u06ff-]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 220);
}

async function pubmedIds(term, retmax = 5) {
  if (!term) return [];
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=${retmax}&sort=relevance&term=${encodeURIComponent(term)}`;
  const data = await fetchJson(url);
  return data?.esearchresult?.idlist || [];
}

async function pubmedSummaries(ids) {
  if (!ids.length) return [];
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=${ids.join(',')}`;
  const data = await fetchJson(url);
  const rec = data?.result || {};
  return ids.map((id) => {
    const r = rec[id];
    if (!r) return null;
    return {
      n: 0,
      org: 'PubMed',
      id: `pmid:${id}`,
      pmid: id,
      title: r.title || 'PubMed article',
      authors: (r.authors || []).slice(0, 3).map((a) => a.name).join(', '),
      year: String(r.pubdate || '').slice(0, 4),
      journal: r.fulljournalname || r.source || '',
      url: `https://pubmed.ncbi.nlm.nih.gov/${id}/`,
      abstract: '',
      kind: 'article',
    };
  }).filter(Boolean);
}

async function pubmedAbstracts(ids) {
  if (!ids.length) return {};
  const url = `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=${ids.join(',')}`;
  const xml = await fetchText(url, 7000);
  const out = {};
  if (!xml) return out;
  const blocks = xml.split(/<PubmedArticle>/).slice(1);
  for (const b of blocks) {
    const id = (b.match(/<PMID[^>]*>(\d+)<\/PMID>/) || [])[1];
    const abs = [...b.matchAll(/<AbstractText[^>]*>([\s\S]*?)<\/AbstractText>/g)]
      .map((m) => m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim())
      .join(' ');
    if (id && abs) out[id] = abs.slice(0, 1400);
  }
  return out;
}

const PORTALS = [
  { org: 'WHO', title: 'WHO health topics', url: 'https://www.who.int/health-topics' },
  { org: 'CDC', title: 'CDC', url: 'https://www.cdc.gov' },
  { org: 'NICE', title: 'NICE guidance', url: 'https://www.nice.org.uk/guidance' },
  { org: 'NIH / MedlinePlus', title: 'MedlinePlus', url: 'https://medlineplus.gov' },
  { org: 'AHA', title: 'American Heart Association', url: 'https://www.heart.org' },
  { org: 'AAP', title: 'American Academy of Pediatrics', url: 'https://www.aap.org' },
];

export async function retrieveSources(question, history = [], prefer = []) {
  const prior = history.slice(-6).map((m) => m.content).join(' ');
  const q = clean(`${question} ${prior}`).slice(0, 200) || clean(question);
  const ids = await pubmedIds(`${q} review`, 5);
  const summaries = await pubmedSummaries(ids);
  const abs = await pubmedAbstracts(ids);
  summaries.forEach((s) => { if (abs[s.pmid]) s.abstract = abs[s.pmid]; });

  const articles = summaries.filter((s) => s.url).map((s, i) => ({ ...s, n: i + 1 }));
  const pref = new Set((prefer || []).map((x) => String(x).toUpperCase()));
  const portals = PORTALS
    .filter((p) => !pref.size || pref.has(p.org.split(/\s|\//)[0].toUpperCase()) || pref.has(p.org.toUpperCase()))
    .slice(0, 4)
    .map((p) => ({ ...p, n: 0, kind: 'portal', year: '', journal: p.org, authors: '', snippet: '' }));

  return { articles, portals };
}

export function formatRetrievalBlock(articles) {
  if (!articles?.length) return 'No live abstracts were retrieved.';
  return articles.slice(0, 6).map((a, i) => {
    const bit = (a.abstract || a.title || '').slice(0, 700);
    return `[${i + 1}] ${a.title} (${a.journal || 'PubMed'} ${a.year || ''})\n${a.url}\n${bit}`;
  }).join('\n\n');
}

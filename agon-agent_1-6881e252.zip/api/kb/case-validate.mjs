// Shared case validation engine — runs deterministic safety checks on a case.
// Returns { passed: boolean, score: 0..100, checks: [{name, ok, weight, msg}], needsReview: boolean }.

const RANGES = {
  hr: { min: 20, max: 240 },
  sbp: { min: 40, max: 260 },
  dbp: { min: 20, max: 180 },
  rr: { min: 4, max: 60 },
  spo2: { min: 50, max: 100 },
  temp: { min: 30, max: 45 },
  pain: { min: 0, max: 10 },
  lactate: { min: 0, max: 30 },
  map: { min: 30, max: 200 },
};

const MED_ALIASES = {
  aspirin: ['asa', 'acetylsalicylic acid'],
  acetaminophen: ['paracetamol', 'tylenol', 'apap'],
  epinephrine: ['adrenaline'],
  norepinephrine: ['noradrenaline', 'levarterenol'],
  albuterol: ['salbutamol', 'ventolin'],
  methylprednisolone: ['solumedrol', 'solu-medrol'],
  prednisone: ['deltasone'],
  amiodarone: ['pacerone', 'cordarone'],
  acetaminophen: ['paracetamol'],
  furosemide: ['lasix'],
  vancomycin: ['vancocin'],
  piperacillin: ['piptaz', 'zosyn'],
};

function normalizeName(s) {
  return (s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function checkMedicationsReference(meds) {
  // Validate medication objects have name + dose and (best effort) the name resembles a known agent
  if (!Array.isArray(meds)) return { ok: true, weight: 5, msg: 'No medications specified' };
  if (meds.length === 0) return { ok: true, weight: 0, msg: 'No medications' };
  const known = Object.keys(MED_ALIASES);
  const issues = [];
  for (const m of meds) {
    if (typeof m === 'string') {
      issues.push(`Medication entry is a string; expected {name, dose}.`);
      continue;
    }
    if (!m.name) { issues.push('Medication missing name.'); continue; }
    if (!m.dose) { issues.push(`Medication "${m.name}" missing dose.`); continue; }
    const n = normalizeName(m.name);
    const matched = known.some((k) => {
      if (n.includes(normalizeName(k))) return true;
      return MED_ALIASES[k].some((a) => n.includes(normalizeName(a)));
    });
    if (!matched) issues.push(`Medication "${m.name}" not in curated medication list — verify against institutional formulary.`);
  }
  return { ok: issues.length === 0, weight: 10, msg: issues.length ? issues.join(' ') : 'Medications valid' };
}

function checkAllergiesCoherence(allergies, meds) {
  if (!Array.isArray(allergies) || !Array.isArray(meds)) return { ok: true, weight: 5, msg: 'No allergies/meds to cross-check' };
  const issues = [];
  for (const a of allergies) {
    const an = normalizeName(a);
    for (const m of meds) {
      const mn = normalizeName(m.name);
      if (an && mn && (an === mn || mn.includes(an) || an.includes(mn))) {
        issues.push(`Allergy conflict: "${a}" vs medication "${m.name}".`);
      }
    }
  }
  return { ok: issues.length === 0, weight: 20, msg: issues.length ? issues.join(' ') : 'No allergy conflicts detected' };
}

function checkVitalsRanges(vitals) {
  if (!vitals || typeof vitals !== 'object') return { ok: true, weight: 5, msg: 'No vitals to check' };
  const issues = [];
  for (const [k, range] of Object.entries(RANGES)) {
    if (vitals[k] == null) continue;
    const v = Number(vitals[k]);
    if (!isFinite(v)) { issues.push(`Vital ${k} is not numeric.`); continue; }
    if (v < range.min || v > range.max) issues.push(`Vital ${k}=${v} outside plausible range [${range.min}, ${range.max}].`);
  }
  return { ok: issues.length === 0, weight: 10, msg: issues.length ? issues.join(' ') : 'Vitals in plausible ranges' };
}

function checkStepsStructure(steps) {
  if (!Array.isArray(steps) || steps.length < 2) return { ok: false, weight: 25, msg: 'Need at least 2 steps with decisions' };
  const issues = [];
  for (const step of steps) {
    if (!step.id || !step.title_en || !step.prompt_en) issues.push(`Step "${step.id || '?'}" missing id/title/prompt`);
    if (!Array.isArray(step.decisions) || step.decisions.length < 2) issues.push(`Step "${step.id}" needs ≥2 decisions`);
    for (const d of step.decisions || []) {
      if (!d.id || !d.text_en || typeof d.score_delta !== 'number') issues.push(`Decision in step "${step.id}" missing id/text/score`);
      if (typeof d.score_delta !== 'number' || d.score_delta < -30 || d.score_delta > 25) {
        issues.push(`Decision "${d.id}" score_delta ${d.score_delta} out of expected range -30..25.`);
      }
    }
  }
  return { ok: issues.length === 0, weight: 25, msg: issues.length ? issues.join(' ') : 'Steps structurally valid' };
}

function checkReferencesEvidence(refs) {
  if (!Array.isArray(refs) || refs.length === 0) return { ok: false, weight: 20, msg: 'No references provided — clinical review required' };
  const issues = [];
  for (const r of refs) {
    if (!r.url || !/^https?:\/\//.test(r.url)) issues.push(`Reference "${r.abbr || ''}" missing valid URL.`);
    if (!r.abbr) issues.push('Reference missing abbreviation.');
    if (!r.title) issues.push('Reference missing title.');
  }
  return { ok: issues.length === 0, weight: 20, msg: issues.length ? issues.join(' ') : `${refs.length} reference(s) verified` };
}

function checkDrugDoseReality(meds, caseContext = {}) {
  if (!Array.isArray(meds)) return { ok: true, weight: 0, msg: 'No medications to check' };
  const issues = [];
  // Lookup known max single doses (very conservative hand-curated)
  const knownMeds = {
    aspirin: { maxSingleMg: 1000 },
    acetaminophen: { maxSingleMgPerKg: 15, maxDailyMgPerKg: 75 },
    epinephrine: { ivBolusMg: 1 },
    norepinephrine: { typicalDoseMcgKgMin: 0.4 },
    albuterol: { nebStandardMg: 5 },
    amiodarone: { ivLoadingMgPerKg: 5 },
    furosemide: { ivStandardMg: 80 },
    vancomycin: { ivStandardMgPerKg: 15 },
    methylprednisolone: { ivStandardMg: 125 },
  };
  for (const m of meds) {
    const key = Object.keys(knownMeds).find((k) => normalizeName(m.name).includes(normalizeName(k)));
    if (!key) continue;
    const doseText = (m.dose || '').toLowerCase();
    // Pull out leading numeric value in mg (very loose)
    const m2 = doseText.match(/(\d+(?:\.\d+)?)\s*mg/);
    if (!m2) continue;
    const val = Number(m2[1]);
    const spec = knownMeds[key];
    if (spec.maxSingleMg && val > spec.maxSingleMg * 1.5) {
      issues.push(`"${m.name}" dose ${val} mg exceeds typical single dose (>1.5x ${spec.maxSingleMg} mg). Verify.`);
    }
  }
  return { ok: issues.length === 0, weight: 10, msg: issues.length ? issues.join(' ') : 'Doses within plausible ranges' };
}

export function validateCase(c) {
  const checks = [
    checkVitalsRanges(c.vitals),
    checkMedicationsReference(c.medications),
    checkAllergiesCoherence(c.allergies, c.medications),
    checkDrugDoseReality(c.medications, { patient: c.patient }),
    checkStepsStructure(c.steps),
    checkReferencesEvidence(c.references),
  ];
  let score = 0, max = 0, passedCount = 0;
  for (const ck of checks) { max += ck.weight; if (ck.ok) { score += ck.weight; passedCount++; } }
  const pct = max ? Math.round((score / max) * 100) : 0;
  const failed = checks.filter((c) => !c.ok);
  // Block publication only if the FAILING checks are safety-critical:
  // - allergy conflict, missing references, structurally broken steps
  const safetyCritical = failed.some((c) => c.weight >= 20);
  return {
    passed: passedCount === checks.length,
    score: pct,
    needsReview: safetyCritical || pct < 80,
    checks: checks.map((c) => ({ name: c.msg.split(' ')[0] || 'check', ok: c.ok, weight: c.weight, msg: c.msg })),
  };
}

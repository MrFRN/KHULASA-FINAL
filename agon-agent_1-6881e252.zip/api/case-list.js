// Case Simulation — list & browse cases with filters (enriched with meta).
import supabase from './db-client.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const q = req.query || {};
    let query = supabase.from('case_scenarios').select('id, slug, title_en, title_ar, description_en, description_ar, specialty, difficulty, patient_age, patient_gender, department, featured').eq('published', true).order('id', { ascending: true });
    if (q.specialty && q.specialty !== 'all') query = query.eq('specialty', q.specialty);
    if (q.difficulty && q.difficulty !== 'all') query = query.eq('difficulty', q.difficulty);
    if (q.featured === '1') query = query.eq('featured', true);
    const { data, error } = await query;
    if (error) throw error;
    // Enrich with meta (status/condition/tags)
    const ids = (data || []).map((c) => c.id);
    let metaMap = new Map();
    if (ids.length) {
      const { data: metas } = await supabase.from('case_scenarios_meta').select('case_id, condition_en, condition_ar, tags, status, completion_count, avg_score').in('case_id', ids);
      metaMap = new Map((metas || []).map((m) => [m.case_id, m]));
    }
    return res.status(200).json({
      cases: (data || []).map((c) => ({ ...c, meta: metaMap.get(c.id) || null })),
    });
  } catch (err) {
    console.error('case-list error:', err);
    return res.status(500).json({ error: err.message });
  }
}

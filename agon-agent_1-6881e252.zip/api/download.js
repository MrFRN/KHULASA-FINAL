import supabase from './db-client.js';
import { cors } from './_auth.js';

// Public: increment download count, log a download event, return the file URL.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { id } = req.body || {};
    if (!id) return res.status(400).json({ error: 'id required' });
    const { data: rec, error } = await supabase
      .from('resources')
      .select('download_count, file_url, file_name, title')
      .eq('id', id)
      .single();
    if (error || !rec) return res.status(404).json({ error: '\u063a\u064a\u0631 \u0645\u0648\u062c\u0648\u062f' });
    const next = (rec.download_count || 0) + 1;
    await supabase.from('resources').update({ download_count: next }).eq('id', id);
    await supabase.from('events').insert({ type: 'download', resource_id: id });
    return res.status(200).json({ url: rec.file_url, file_name: rec.file_name, title: rec.title, download_count: next });
  } catch (err) {
    console.error('download error:', err);
    return res.status(500).json({ error: err.message });
  }
}

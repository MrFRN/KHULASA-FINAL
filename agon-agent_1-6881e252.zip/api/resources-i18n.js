import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

// Sidecar table holding the English (or other) version of a resource's
// translatable fields, so content can be bilingual without ALTERing the main table.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data } = await supabase.from('resources_i18n').select('*').eq('resource_id', id).single();
      return res.status(200).json(data || {});
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (req.method === 'PUT' || req.method === 'POST') {
      const { id, title_en, description_en, category_en } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { data, error } = await supabase
        .from('resources_i18n')
        .upsert({ resource_id: id, title_en: title_en ?? null, description_en: description_en ?? null, category_en: category_en ?? null }, { onConflict: 'resource_id' })
        .select()
        .single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('resources-i18n error:', err);
    return res.status(500).json({ error: err.message });
  }
}

import { cors } from './_auth.js';
import supabase from './db-client.js';
import { CHATGPT_NURSING_PROMPT, wantsSourceMode, preferredOrgs } from './kb/chatgpt-nursing-prompt.mjs';
import { retrieveSources, formatRetrievalBlock } from './kb/source-search.mjs';
import { completeChat, providerStatus, resolveProvider } from './kb/ai-provider.mjs';

export const config = { maxDuration: 60 };

const WINDOW_MS = 60 * 60 * 1000;
const hits = new Map();

function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 40;
}

async function readChatPrefs() {
  try {
    const { data } = await supabase.from('ai_guidelines').select('description').eq('abbr', 'AI_CONFIG').single();
    const parsed = data?.description ? JSON.parse(data.description) : {};
    return {
      enabled: parsed.enabled !== false,
      provider: parsed.provider || '',
      model: parsed.model || '',
    };
  } catch {
    return { enabled: true, provider: '', model: '' };
  }
}

function buildMessages({ question, history, lang, sourceMode, retrievalText, isContinue }) {
  const langLine = lang === 'ar'
    ? 'Respond in natural Arabic. Keep English medical terms in parentheses when useful.'
    : 'Respond in natural professional English.';

  const sys = [
    CHATGPT_NURSING_PROMPT,
    langLine,
    sourceMode
      ? 'SOURCE MODE IS ON for this turn. Retrieved passages follow. Cite only those. If they are thin, say so.'
      : 'SOURCE MODE IS OFF. Answer from your knowledge. Do not invent a search. Do not add a Sources section.',
  ].join('\n\n');

  const msgs = [{ role: 'system', content: sys }];
  const prior = Array.isArray(history) ? history.slice(-20) : [];
  for (const m of prior) {
    if (!m?.content) continue;
    msgs.push({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: String(m.content).slice(0, 6000),
    });
  }

  let user = isContinue
    ? (lang === 'ar' ? 'أكمل من حيث توقفت.' : 'Please continue from where you left off.')
    : question;

  if (sourceMode) {
    user = `${user}\n\n--- Retrieved passages (do not invent others) ---\n${retrievalText || 'None retrieved.'}`;
  }

  const last = msgs[msgs.length - 1];
  if (!(last && last.role === 'user' && last.content === question) || isContinue || sourceMode) {
    msgs.push({ role: 'user', content: user });
  }
  return msgs;
}

function packReply({ answer, sources, mode, durationMs, model, providerId }) {
  return {
    answer,
    reply: answer,
    insufficient: !answer,
    status: answer ? 'ok' : 'empty',
    durationMs,
    mode,
    queries: { primary: '', nursing: '' },
    nursing: [],
    safety: [],
    sources,
    ranAt: new Date().toISOString(),
    model,
    provider: providerId,
  };
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  const prefs = await readChatPrefs();
  const resolved = resolveProvider(prefs.provider, prefs.model);
  const providers = providerStatus();

  if (req.method === 'GET') {
    return res.status(200).json({
      configured: !!resolved.ok,
      enabled: prefs.enabled,
      provider: resolved.ok ? resolved.provider.id : null,
      model: resolved.ok ? resolved.model : null,
      providers,
      needSecret: resolved.ok ? null : (resolved.needSecret || 'OPENAI_API_KEY'),
    });
  }

  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const ip = (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (limited(ip)) return res.status(429).json({ error: 'Rate limit. Try later.' });

    if (prefs.enabled === false) {
      return res.status(403).json({ error: 'The assistant is temporarily disabled.' });
    }

    if (!resolved.ok) {
      return res.status(503).json({
        error: resolved.error,
        needSecret: resolved.needSecret,
        providers,
      });
    }

    const b = req.body || {};
    const question = String(b.question || b.message || '').trim().slice(0, 4000);
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    const isContinue = !!b.continue;
    const history = Array.isArray(b.history)
      ? b.history.slice(-20).map((m) => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: String(m.content || '').slice(0, 6000),
      }))
      : [];

    if (!isContinue && question.length < 1) {
      return res.status(400).json({
        error: lang === 'ar' ? 'اكتب سؤالاً.' : 'Please enter a question.',
      });
    }

    const sourceMode = !!(b.sourceMode || wantsSourceMode(question));
    let articles = [];
    let portals = [];
    let retrievalText = '';
    if (sourceMode) {
      const found = await retrieveSources(question || 'nursing guideline', history, preferredOrgs(question));
      articles = found.articles || [];
      portals = found.portals || [];
      retrievalText = formatRetrievalBlock(articles);
    }

    const sources = [
      ...articles.map((a) => ({
        n: a.n,
        org: a.org,
        title: a.title,
        url: a.url,
        year: a.year,
        journal: a.journal,
        authors: a.authors,
        snippet: (a.abstract || '').slice(0, 280),
        kind: 'article',
      })),
      ...portals.map((p) => ({
        n: 0,
        org: p.org,
        title: p.title,
        url: p.url,
        year: '',
        journal: p.org,
        authors: '',
        snippet: '',
        kind: 'portal',
      })),
    ];

    const messages = buildMessages({
      question: question || 'Continue.',
      history,
      lang,
      sourceMode,
      retrievalText,
      isContinue,
    });

    const started = Date.now();
    const wantStream = b.stream === true || b.stream === 'true';
    const out = await completeChat({
      messages,
      stream: wantStream,
      preferredId: prefs.provider,
      preferredModel: prefs.model,
    });

    if (out.error) {
      return res.status(503).json(out.error);
    }

    if (out.kind === 'json') {
      if (!out.ok) return res.status(502).json({ error: out.error || 'Provider error' });
      return res.status(200).json(packReply({
        answer: out.answer,
        sources: sourceMode ? sources : [],
        mode: sourceMode ? 'source' : 'normal',
        durationMs: Date.now() - started,
        model: out.model,
        providerId: out.providerId,
      }));
    }

    const upstream = out.res;
    if (!upstream.ok) {
      const errText = await upstream.text();
      return res.status(502).json({ error: `Provider error ${upstream.status}`, detail: errText.slice(0, 400) });
    }

    if (wantStream && out.kind === 'openai') {
      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      if (typeof res.flushHeaders === 'function') res.flushHeaders();

      const reader = upstream.body.getReader();
      const decoder = new TextDecoder();
      let buf = '';
      let full = '';
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() || '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const data = trimmed.slice(5).trim();
          if (data === '[DONE]') continue;
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content || '';
            if (delta) {
              full += delta;
              res.write(`data: ${JSON.stringify({ delta })}\n\n`);
            }
          } catch { /* ignore partial */ }
        }
      }
      res.write(`data: ${JSON.stringify({
        done: true,
        ...packReply({
          answer: full,
          sources: sourceMode ? sources : [],
          mode: sourceMode ? 'source' : 'normal',
          durationMs: Date.now() - started,
          model: out.model,
          providerId: out.providerId,
        }),
      })}\n\n`);
      return res.end();
    }

    const raw = await upstream.json();
    const answer = raw.choices?.[0]?.message?.content || '';
    return res.status(200).json(packReply({
      answer,
      sources: sourceMode ? sources : [],
      mode: sourceMode ? 'source' : 'normal',
      durationMs: Date.now() - started,
      model: out.model,
      providerId: out.providerId,
    }));
  } catch (err) {
    console.error('ai-chat', err);
    return res.status(500).json({ error: err.message || 'Chat failed' });
  }
}

import supabase from './db-client.js';

// Verify a Supabase auth token from the Authorization header.
// Returns the user object or null.
export async function getUser(req) {
  const token = (req.headers.authorization || '').replace('Bearer ', '').trim();
  if (!token) return null;
  try {
    const { data, error } = await supabase.auth.getUser(token);
    if (error) return null;
    return data?.user || null;
  } catch {
    return null;
  }
}

export function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

// Harmless default handler so this helper file is safe if routed.
export default function handler(_req, res) {
  res.status(404).json({ error: 'Not found' });
}

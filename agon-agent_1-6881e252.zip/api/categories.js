import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';
import { createUserClient, bearerToken } from './user-client.js';

// Nursing categories (section-aware). Public read, authenticated writes.
export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      // Categories change rarely -> cache longer at the edge
      res.setHeader('Cache-Control', 'public, s-maxage=120, stale-while-revalidate=600');
      const sel = (req.query && req.query.select) || '*';
      let query = supabase.from('nursing_categories').select(sel).order('sort', { ascending: true }).order('name', { ascending: true });
      if (req.query.section) query = query.eq('section', req.query.section);
      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });
    const db = createUserClient(bearerToken(req));

    if (req.method === 'POST') {
      const { name, slug, section, icon, sort } = req.body || {};
      if (!name || !name.trim()) return res.status(400).json({ error: '\u0627\u0644\u0627\u0633\u0645 \u0645\u0637\u0644\u0648\u0628' });
      const row = { name: name.trim(), slug: slug || null, section: section || null, icon: icon || null, sort: sort || 0 };
      const { data, error } = await db.from('nursing_categories').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }
    if (req.method === 'PUT') {
      const { id, name, slug, section, icon, sort } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = {};
      if (name !== undefined) patch.name = name.trim();
      if (slug !== undefined) patch.slug = slug;
      if (section !== undefined) patch.section = section;
      if (icon !== undefined) patch.icon = icon;
      if (sort !== undefined) patch.sort = sort;
      const { data, error } = await db.from('nursing_categories').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await db.from('nursing_categories').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('categories API error:', err);
    return res.status(500).json({ error: err.message });
  }
}

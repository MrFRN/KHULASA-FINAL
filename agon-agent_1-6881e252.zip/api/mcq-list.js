// List MCQ cases (public, only published)
import supabase from './db-client.js';
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};
export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const q = req.query || {};
    const sort = (q.sort || 'newest').toString();
    const page = Math.max(1, Number(q.page) || 1);
    const pageSize = Math.max(1, Math.min(50, Number(q.pageSize) || 24));
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    let query = supabase.from('case_mcq_cases').select('id, slug, title_en, title_ar, specialty, condition_en, condition_ar, difficulty, patient_age, patient_gender, featured, view_count, completion_count, avg_score, published_at').eq('status', 'published').limit(200);
    if (q.specialty && q.specialty !== 'all') query = query.eq('specialty', q.specialty);
    if (q.difficulty && q.difficulty !== 'all') query = query.eq('difficulty', q.difficulty);
    if (q.featured === '1') query = query.eq('featured', true);
    if (q.search) {
      const s = q.search.toLowerCase();
      query = query.or(`title_en.ilike.%${s}%,title_ar.ilike.%${s}%,condition_en.ilike.%${s}%,condition_ar.ilike.%${s}%`);
    }
    const { data, error } = await query;
    if (error) throw error;
    let list = data || [];
    if (sort === 'popular') list.sort((a, b) => (b.completion_count || 0) - (a.completion_count || 0));
    else if (sort === 'featured') list = list.filter((c) => c.featured).concat(list.filter((c) => !c.featured));
    else list.sort((a, b) => (b.id || 0) - (a.id || 0));
    const slice = list.slice(from, to + 1);
    return res.status(200).json({ items: slice, total: list.length, page, pageSize, hasMore: list.length > to + 1 });
  } catch (err) {
    console.error('mcq-list error:', err);
    return res.status(500).json({ error: err.message });
  }
}

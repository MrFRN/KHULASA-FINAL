// Case Simulation — complete a case, save attempt + update stats (XP, level, streak, badges).
import { createClient } from '@supabase/supabase-js';
import supabase from './db-client.js';
import { trackTool } from './ai-track.js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

function getToken(req) {
  return (req.headers?.authorization || '').toString().replace(/^Bearer\s+/i, '').trim();
}

function computeXp(score, timeSeconds, difficulty) {
  const mult = { beginner: 1, intermediate: 1.3, advanced: 1.6, 'critical care': 2 }[difficulty] || 1;
  const timeBonus = Math.max(0, 1 - (timeSeconds || 0) / 1200); // 0..1 if finished in 20 min
  const base = Math.max(0, Number(score || 0));
  return Math.round((base * 10 + Math.round(timeBonus * 50)) * mult);
}

function computeBadges(report) {
  const badges = [];
  if ((report?.score || 0) >= 90) badges.push({ id: 'excellence', label_en: 'Clinical Excellence', label_ar: 'التميز السريري', icon: '🏆' });
  if ((report?.safety || 0) >= 95) badges.push({ id: 'safety', label_en: 'Patient Safety Champion', label_ar: 'بطل سلامة المريض', icon: '🛡️' });
  if ((report?.prioritization || 0) >= 90) badges.push({ id: 'priority', label_en: 'Master Prioritizer', label_ar: 'سيد الأولويات', icon: '🎯' });
  if (report?.noSafetyFlags) badges.push({ id: 'zero-error', label_en: 'Zero Errors', label_ar: 'صفر أخطاء', icon: '✨' });
  return badges;
}

export default async function handler(req, res) {
  Object.entries(corsHeaders).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const token = getToken(req);
    const b = req.body || {};
    const lang = b.lang === 'ar' ? 'ar' : 'en';
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();

    if (!b.caseId) return res.status(400).json({ error: lang === 'ar' ? 'حدد الحالة.' : 'Specify a case.' });
    const { data: c, error: cErr } = await supabase.from('case_scenarios').select('id, slug, difficulty').eq('id', b.caseId).maybeSingle();
    if (cErr || !c) return res.status(404).json({ error: lang === 'ar' ? 'الحالة غير موجودة.' : 'Case not found.' });

    const score = Math.max(0, Math.min(100, Number(b.score || 0)));
    const xp = computeXp(score, b.timeSeconds || 0, c.difficulty);
    const report = b.report || {};
    const badges = computeBadges(report);

    // Save attempt if user is logged in
    let userId = null;
    if (token) {
      const { data: ud } = await supabase.auth.getUser(token);
      userId = ud?.user?.id || null;
    }

    let attemptId = null;
    let stats = null;
    if (userId) {
      // Use user-scoped client for RLS
      const userClient = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
        global: { headers: { Authorization: `Bearer ${token}` } },
      });
      const { data: attempt, error: aErr } = await userClient.from('case_attempts').insert({
        user_id: userId,
        case_id: c.id,
        case_slug: c.slug,
        started_at: b.startedAt || new Date(Date.now() - (b.timeSeconds || 0) * 1000).toISOString(),
        completed_at: new Date().toISOString(),
        score,
        xp_earned: xp,
        time_seconds: b.timeSeconds || 0,
        decisions: b.decisions || [],
        report,
        badges,
      }).select('id').single();
      if (aErr) console.error('attempt insert failed:', aErr.message);
      attemptId = attempt?.id || null;

      // Update stats
      const { data: existing } = await userClient.from('case_user_stats').select('*').eq('user_id', userId).maybeSingle();
      const now = new Date();
      const last = existing?.last_active_at ? new Date(existing.last_active_at) : null;
      const sameDay = last && last.toDateString() === now.toDateString();
      const yesterday = last && (now - last) < 48 * 3600 * 1000 && last.toDateString() !== now.toDateString();
      const newStreak = sameDay ? (existing?.streak_days || 0) : (yesterday ? (existing?.streak_days || 0) + 1 : 1);
      const completedCases = Array.isArray(existing?.completed_cases) ? existing.completed_cases : [];
      if (!completedCases.includes(c.slug)) completedCases.push(c.slug);
      const allBadges = Array.isArray(existing?.badges) ? existing.badges : [];
      const merged = [...allBadges];
      for (const nb of badges) if (!merged.find((b) => b.id === nb.id)) merged.push(nb);
      const totalXp = (existing?.total_xp || 0) + xp;
      const level = Math.floor(totalXp / 500) + 1;
      const update = {
        user_id: userId,
        total_xp: totalXp,
        level,
        streak_days: newStreak,
        last_active_at: now.toISOString(),
        badges: merged,
        completed_cases: completedCases,
        updated_at: now.toISOString(),
      };
      if (existing) {
        await userClient.from('case_user_stats').update(update).eq('user_id', userId);
      } else {
        await userClient.from('case_user_stats').insert(update);
      }
      stats = update;
    }

    await trackTool('case-complete', ip, userId, { case: c.slug, score, xp });

    // Update case meta stats (completion_count + rolling avg_score)
    try {
      const { data: meta } = await supabase.from('case_scenarios_meta').select('completion_count, avg_score').eq('case_id', c.id).maybeSingle();
      const prevCount = meta?.completion_count || 0;
      const prevAvg = meta?.avg_score || 0;
      const newCount = prevCount + 1;
      const newAvg = Math.round((prevAvg * prevCount + score) / newCount);
      await supabase.from('case_scenarios_meta').update({
        completion_count: newCount,
        avg_score: newAvg,
      }).eq('case_id', c.id);
    } catch { /* ignore */ }

    // Recommend related cases + resources
    let related = [];
    let resources = [];
    try {
      const caseRow = await supabase.from('case_scenarios').select('specialty').eq('id', c.id).maybeSingle();
      const sp = caseRow.data?.specialty;
      const rel = await fetch(`/api/case-related?specialty=${sp || ''}&excludeId=${c.id}${userId ? `&userId=${userId}` : ''}&limit=6`).then((r) => r.json()).catch(() => ({}));
      related = rel.related || [];
      resources = rel.resources || [];
    } catch { /* ignore */ }

    return res.status(200).json({
      score,
      xp,
      badges,
      level: stats?.level || Math.floor(xp / 500) + 1,
      totalXp: stats?.total_xp || xp,
      streakDays: stats?.streak_days || 1,
      attemptId,
      saved: !!userId,
      related,
      resources,
      disclaimer: lang === 'ar'
        ? 'هذا تقييم تعليمي. النتائج لا تعكس أداءً سريريًا حقيقيًا.'
        : 'This is an educational assessment. Outcomes do not reflect real clinical performance.',
    });
  } catch (err) {
    console.error('case-complete error:', err);
    return res.status(500).json({ error: err.message });
  }
}

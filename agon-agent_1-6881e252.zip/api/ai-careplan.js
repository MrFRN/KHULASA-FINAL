// AI Care Plan Generator — uses the same engine to produce a structured nursing care plan.
import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';
import { carePlanTool } from './kb/engine.mjs';
import { trackTool } from './ai-track.js';

const hits = new Map();
function limited(ip, limit) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > limit;
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const cfg = (await supabase.from('ai_dictionary').select('description').eq('abbr', 'AI_CONFIG').single()).data?.description || '{}';
    const c = (() => { try { return JSON.parse(cfg); } catch { return {}; } })();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    if (c.enabled === false) return res.status(403).json({ error: 'AI features disabled.' });
    if (limited(ip, c.rate_limit_per_hour || 30)) return res.status(429).json({ error: 'Rate limit exceeded.' });
    const b = req.body || {};
    const lang = (b.lang === 'ar' || (req.query && req.query.lang === 'ar')) ? 'ar' : 'en';
    const user = await getUser(req);
    const out = carePlanTool({ ...b, lang });
    if (out.error) return res.status(400).json({ error: lang === 'ar' ? 'أدخل شكوى/تشخيص/عمر/جنس.' : 'Enter chief complaint/diagnosis/age/gender.' });
    await trackTool('careplan', ip, user?.id || null, { ok: true });
    return res.status(200).json({
      disclaimer: lang === 'ar' ? 'لأغراض تعليمية فقط.' : 'For educational purposes only.',
      lang,
      carePlan: out.carePlan,
    });
  } catch (err) {
    console.error('ai-careplan error:', err);
    return res.status(500).json({ error: err.message });
  }
}

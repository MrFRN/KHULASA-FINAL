// Tiny shared helper to record an events row for an AI tool usage.
import supabase from './db-client.js';

export async function trackTool(tool, ip, userId, meta = {}) {
  try {
    await supabase.from('events').insert({
      type: 'ai_tool',
      ip,
      user_id: userId || null,
      meta: { tool, ...meta },
      path: 'ai-assistant',
      created_at: new Date().toISOString(),
    });
  } catch (e) {
    // never fail the request because of analytics
  }
}

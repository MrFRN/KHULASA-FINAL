// Recommend related cases by specialty and (optional) user's weak skills.
import supabase from './db-client.js';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

export default async function handler(req, res) {
  Object.entries(cors).forEach(([k, v]) => res.setHeader(k, v));
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const q = req.query || {};
    const specialty = q.specialty || null;
    const excludeId = Number(q.excludeId) || 0;
    const userId = q.userId || null;
    const limit = Math.min(20, Math.max(1, Number(q.limit) || 6));

    // 1) Same specialty, published, exclude self
    let related = [];
    if (specialty) {
      const { data } = await supabase.from('case_scenarios').select('id, slug, title_en, title_ar, specialty, difficulty').eq('specialty', specialty).eq('published', true).limit(50);
      related = (data || []).filter((c) => c.id !== excludeId).slice(0, limit);
    }
    if (related.length < limit) {
      const { data } = await supabase.from('case_scenarios').select('id, slug, title_en, title_ar, specialty, difficulty').eq('published', true).neq('specialty', specialty || '').limit(50);
      const more = (data || []).filter((c) => c.id !== excludeId && !related.find((r) => r.id === c.id));
      related = related.concat(more.slice(0, limit - related.length));
    }

    // 2) "Resources" — link to existing app pages
    const resources = [
      { type: 'tool', key: 'calculator', label_en: 'Nursing Calculator', label_ar: 'حاسبات التمريض', icon: '🧮', url: '/ai-assistant/calculator' },
      { type: 'tool', key: 'care-plan', label_en: 'AI Care Plan Generator', label_ar: 'مولِّد خطة الرعاية', icon: '📋', url: '/ai-assistant/care-plan' },
      { type: 'page', key: 'library', label_en: 'PDF Library', label_ar: 'المكتبة', icon: '📚', url: '/study' },
      { type: 'page', key: 'books', label_en: 'Books', label_ar: 'الكتب', icon: '📖', url: '/books' },
      { type: 'page', key: 'interview', label_en: 'Interview Questions', label_ar: 'أسئلة المقابلات', icon: '💬', url: '/interview' },
    ];

    return res.status(200).json({ related, resources });
  } catch (err) {
    console.error('case-related error:', err);
    return res.status(500).json({ error: err.message });
  }
}

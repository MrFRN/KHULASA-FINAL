import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const FIELDS = [
  'title', 'description', 'category', 'subcategory', 'subject', 'academic_year',
  'tags', 'file_name', 'file_path', 'file_url', 'file_size', 'file_type',
  'cover_image_url', 'cover_path', 'status', 'featured', 'popular',
  'download_count', 'scheduled_at',
];

function pick(body) {
  const out = {};
  for (const k of FIELDS) {
    if (body[k] !== undefined) out[k] = body[k];
  }
  return out;
}

function sanitize(s) {
  return String(s).replace(/[,()%]/g, ' ').trim();
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const q = req.query || {};
      const view = q.view === 'admin' ? 'admin' : 'public';

      // Single record
      if (q.id) {
        const { data, error } = await supabase.from('files').select('*').eq('id', q.id).single();
        if (error || !data) return res.status(404).json({ error: 'File not found' });
        if (view === 'public') {
          const visible = data.status === 'published' ||
            (data.status === 'scheduled' && data.scheduled_at && new Date(data.scheduled_at) <= new Date());
          if (!visible) return res.status(404).json({ error: 'File not found' });
        } else {
          const user = await getUser(req);
          if (!user) return res.status(401).json({ error: 'Unauthorized' });
        }
        return res.status(200).json(data);
      }

      let query = supabase.from('files').select('*');

      if (view === 'public') {
        const nowIso = new Date().toISOString();
        query = query.or(`status.eq.published,and(status.eq.scheduled,scheduled_at.lte.${nowIso})`);
      } else {
        const user = await getUser(req);
        if (!user) return res.status(401).json({ error: 'Unauthorized' });
        if (q.status) query = query.eq('status', q.status);
      }

      if (q.category) query = query.eq('category', q.category);
      if (q.subcategory) query = query.eq('subcategory', q.subcategory);
      if (q.subject) query = query.eq('subject', q.subject);
      if (q.year) query = query.eq('academic_year', q.year);
      if (q.featured === 'true') query = query.eq('featured', true);
      if (q.popular === 'true') query = query.eq('popular', true);
      if (q.search) {
        const s = sanitize(q.search);
        if (s) query = query.or(`title.ilike.%${s}%,description.ilike.%${s}%,subject.ilike.%${s}%`);
      }

      const allowedSort = ['created_at', 'updated_at', 'title', 'file_size', 'download_count'];
      const sort = allowedSort.includes(q.sort) ? q.sort : 'created_at';
      const ascending = q.order === 'asc';
      query = query.order(sort, { ascending });

      const { data, error } = await query;
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'POST') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      const body = pick(req.body || {});
      if (!body.title) return res.status(400).json({ error: 'Title is required' });
      if (!body.file_url || !body.file_path) return res.status(400).json({ error: 'File is required' });
      body.user_id = user.id;
      body.updated_at = new Date().toISOString();
      if (body.download_count === undefined) body.download_count = 0;
      const { data, error } = await supabase.from('files').insert(body).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const body = pick(req.body || {});
      body.updated_at = new Date().toISOString();
      const { data, error } = await supabase.from('files').update(body).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const user = await getUser(req);
      if (!user) return res.status(401).json({ error: 'Unauthorized' });
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id is required' });
      const { data: rec } = await supabase.from('files').select('file_path, cover_path').eq('id', id).single();
      if (rec) {
        if (rec.file_path) await supabase.storage.from('files').remove([rec.file_path]).catch(() => {});
        if (rec.cover_path) await supabase.storage.from('covers').remove([rec.cover_path]).catch(() => {});
      }
      const { error } = await supabase.from('files').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('files API error:', err);
    return res.status(500).json({ error: err.message });
  }
}

import supabase from './db-client.js';
import { getUser, cors } from './_auth.js';

const QUOTA = 15 * 1024 * 1024 * 1024; // 15 GB

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    res.setHeader('Cache-Control', 'private, no-store');
    const user = await getUser(req);
    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    const { data: resources } = await supabase
      .from('resources')
      .select('id, title, section, status, file_size, download_count, cover_image_url, created_at');
    const list = resources || [];

    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const { data: events } = await supabase
      .from('events')
      .select('type, created_at')
      .gte('created_at', since);
    const ev = events || [];

    let used = 0, published = 0, drafts = 0, scheduled = 0, downloads = 0;
    const bySection = { study: 0, books: 0, interview: 0 };
    for (const r of list) {
      used += Number(r.file_size || 0);
      downloads += Number(r.download_count || 0);
      if (r.status === 'published') published += 1;
      else if (r.status === 'draft') drafts += 1;
      else if (r.status === 'scheduled') scheduled += 1;
      if (bySection[r.section] !== undefined) bySection[r.section] += 1;
    }

    // 14-day time series
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const key = d.toISOString().slice(0, 10);
      days.push({ key, label: d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'numeric' }), visits: 0, downloads: 0 });
    }
    const map = Object.fromEntries(days.map((d) => [d.key, d]));
    for (const e of ev) {
      const key = (e.created_at || '').slice(0, 10);
      if (map[key]) {
        if (e.type === 'visit') map[key].visits += 1;
        else if (e.type === 'download') map[key].downloads += 1;
      }
    }

    const visitors = ev.filter((e) => e.type === 'visit').length;
    const topDownloaded = [...list].sort((a, b) => (b.download_count || 0) - (a.download_count || 0)).slice(0, 5);
    const recent = [...list].sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at)).slice(0, 6);

    return res.status(200).json({
      total: list.length, published, drafts, scheduled, downloads,
      used, quota: QUOTA, bySection, visitors,
      series: days, topDownloaded, recent,
    });
  } catch (err) {
    console.error('analytics error:', err);
    return res.status(500).json({ error: err.message });
  }
}

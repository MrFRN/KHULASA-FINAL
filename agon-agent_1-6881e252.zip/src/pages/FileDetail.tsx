export { default } from './ResourceDetail';

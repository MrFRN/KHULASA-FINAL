import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Upload, Search, Eye, Pencil, Trash2, Star, TrendingUp, Download, FileStack, RefreshCw, Loader2 } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import Modal from '../../components/Modal';
import Spinner from '../../components/Spinner';
import StatusBadge from '../../components/StatusBadge';
import FileTypeChip from '../../components/FileTypeChip';
import ProgressBar from '../../components/ProgressBar';
import PdfViewer from '../../components/PdfViewer';
import FileMetaForm from '../../components/FileMetaForm';
import type { MetaForm } from '../../components/FileMetaForm';
import { useToast } from '../../components/Toast';
import { fetchAdminResources, fetchCategories, updateResource, deleteResource, uploadToStorage, uploadResourceFile, createChunks, deleteChunks, isMultipart } from '../../lib/api';
import { formatBytes, formatDate } from '../../lib/format';
import { isAllowed, extOf, MAX_FILE_SIZE, CHUNK_SIZE, ACCEPT_ATTR } from '../../lib/filetypes';
import { SECTIONS } from '../../lib/constants';
import type { Resource, NursingCategory } from '../../types';

function toLocalInput(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso); const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}

export default function ManageResources() {
  const { toast } = useToast();
  const [items, setItems] = useState<Resource[]>([]);
  const [categories, setCategories] = useState<NursingCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [sectionFilter, setSectionFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sort, setSort] = useState('newest');
  const [editRec, setEditRec] = useState<Resource | null>(null);
  const [editForm, setEditForm] = useState<MetaForm | null>(null);
  const [saving, setSaving] = useState(false);
  const [replacing, setReplacing] = useState<{ id: number; progress: number } | null>(null);
  const [deleteRec, setDeleteRec] = useState<Resource | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [preview, setPreview] = useState<Resource | null>(null);
  const replaceInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setError('');
    try {
      const [r, c] = await Promise.all([fetchAdminResources(), fetchCategories()]);
      setItems(r); setCategories(c);
    } catch (e) { setError((e as Error).message); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    let r = items;
    if (search) { const q = search.toLowerCase(); r = r.filter((x) => [x.title, x.description, x.subject, x.author].filter(Boolean).join(' ').toLowerCase().includes(q)); }
    if (sectionFilter) r = r.filter((x) => x.section === sectionFilter);
    if (statusFilter) r = r.filter((x) => x.status === statusFilter);
    r = [...r].sort((a, b) => {
      switch (sort) {
        case 'oldest': return +new Date(a.created_at) - +new Date(b.created_at);
        case 'downloads': return b.download_count - a.download_count;
        case 'title': return a.title.localeCompare(b.title, 'ar');
        default: return +new Date(b.created_at) - +new Date(a.created_at);
      }
    });
    return r;
  }, [items, search, sectionFilter, statusFilter, sort]);

  const openEdit = (rec: Resource) => {
    setEditRec(rec);
    setEditForm({
      title: rec.title, description: rec.description || '', section: rec.section,
      category: rec.category || '', year: rec.year || '', subject: rec.subject || '',
      author: rec.author || '', edition: rec.edition || '', tags: (rec.tags || []).join(', '),
      featured: rec.featured, popular: rec.popular, status: rec.status, scheduled_at: toLocalInput(rec.scheduled_at),
    });
  };

  const saveEdit = async () => {
    if (!editRec || !editForm) return;
    if (!editForm.title.trim()) { toast('العنوان مطلوب', 'error'); return; }
    setSaving(true);
    try {
      await updateResource({
        id: editRec.id, title: editForm.title.trim(), description: editForm.description || null,
        section: editForm.section, category: editForm.category || null, year: editForm.year || null,
        subject: editForm.subject || null, author: editForm.author || null, edition: editForm.edition || null,
        tags: editForm.tags.split(',').map((t) => t.trim()).filter(Boolean),
        featured: editForm.featured, popular: editForm.popular, status: editForm.status,
        scheduled_at: editForm.status === 'scheduled' && editForm.scheduled_at ? new Date(editForm.scheduled_at).toISOString() : null,
      });
      toast('تم حفظ التغييرات', 'success');
      setEditRec(null); setEditForm(null); load();
    } catch (e) { toast((e as Error).message, 'error'); } finally { setSaving(false); }
  };

  const onReplace = async (rec: Resource, file: File) => {
    if (!isAllowed(file.name)) { toast('نوع غير مدعوم', 'error'); return; }
    if (file.size > MAX_FILE_SIZE) { toast(`يتجاوز ${formatBytes(MAX_FILE_SIZE)}`, 'error'); return; }
    setReplacing({ id: rec.id, progress: 0 });
    try {
      const ftype = file.type || extOf(file.name);
      if (file.size <= CHUNK_SIZE && !isMultipart(rec)) {
        // Small file replacing a small file: reuse the same object path so the URL stays the same.
        await uploadToStorage('files', rec.file_path, file, file.type, (p) => setReplacing({ id: rec.id, progress: p }), true);
        await updateResource({ id: rec.id, file_size: file.size, file_type: ftype, file_name: file.name });
        toast('تم استبدال الملف — الرابط لم يتغير', 'success');
      } else {
        // Large file (or replacing a multipart file): upload fresh (single or chunked).
        const res = await uploadResourceFile(file, (p) => setReplacing({ id: rec.id, progress: p }));
        await updateResource({ id: rec.id, file_url: res.file_url || '', file_path: res.file_path, file_size: res.file_size, file_type: ftype, file_name: file.name });
        if (res.multi && res.chunks) await createChunks(rec.id, res.chunks);
        else await deleteChunks(rec.id);
        toast('تم استبدال الملف', 'success');
      }
      if (editRec && editRec.id === rec.id) setEditRec({ ...editRec, file_size: file.size, file_type: ftype, file_name: file.name });
      load();
    } catch (e) { toast((e as Error).message, 'error'); } finally { setReplacing(null); }
  };

  const toggleFlag = async (rec: Resource, key: 'featured' | 'popular') => {
    const next = !rec[key];
    setItems((prev) => prev.map((x) => (x.id === rec.id ? { ...x, [key]: next } : x)));
    try { await updateResource({ id: rec.id, [key]: next } as Partial<Resource> & { id: number }); }
    catch (e) { toast((e as Error).message, 'error'); load(); }
  };

  const confirmDelete = async () => {
    if (!deleteRec) return;
    setDeleting(true);
    try { await deleteResource(deleteRec.id); toast('تم الحذف', 'success'); setDeleteRec(null); load(); }
    catch (e) { toast((e as Error).message, 'error'); } finally { setDeleting(false); }
  };

  const sel = 'rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-700 outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-200';

  return (
    <AdminShell title="إدارة الملفات">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-500 dark:text-slate-400">{items.length} ملف في المكتبة</p>
        <Link to="/admin/upload" className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-bold text-white"><Upload className="h-4.5 w-4.5" /> رفع ملف</Link>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex min-w-[200px] flex-1 items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 dark:border-white/10 dark:bg-white/5">
          <Search className="h-4 w-4 text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث…" className="w-full bg-transparent text-sm outline-none dark:text-white" />
        </div>
        <select value={sectionFilter} onChange={(e) => setSectionFilter(e.target.value)} className={sel}>
          <option value="">كل الأقسام</option>
          {Object.values(SECTIONS).map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
        </select>
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className={sel}>
          <option value="">كل الحالات</option>
          <option value="published">منشور</option>
          <option value="draft">مسودة</option>
          <option value="scheduled">مجدول</option>
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)} className={sel}>
          <option value="newest">الأحدث</option>
          <option value="oldest">الأقدم</option>
          <option value="downloads">الأكثر تحميلًا</option>
          <option value="title">الاسم</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner label="جارٍ التحميل…" /></div>
      ) : error ? (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/20 dark:bg-red-500/10">{error}</div>
      ) : filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 py-20 text-center text-slate-500 dark:border-white/10">
          <FileStack className="h-10 w-10 text-slate-300" />
          <p className="font-semibold text-slate-700 dark:text-slate-200">{items.length === 0 ? 'لا توجد ملفات بعد' : 'لا توجد نتائج'}</p>
          {items.length === 0 && <Link to="/admin/upload" className="text-sm text-primary underline">ارفع أول ملف</Link>}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((f) => (
            <div key={f.id} className="flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5 sm:p-4">
              <div className="flex h-16 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-100 dark:bg-white/10">
                {f.cover_image_url ? <img src={f.cover_image_url} alt="" className="h-full w-full object-cover" /> : <FileStack className="h-5 w-5 text-slate-300" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <FileTypeChip name={f.file_type || f.file_name} />
                  <StatusBadge status={f.status} />
                  {f.featured && <Star className="h-3.5 w-3.5 fill-accent text-accent" />}
                  {f.popular && <TrendingUp className="h-3.5 w-3.5 text-slate-400" />}
                </div>
                <p className="mt-1 truncate font-semibold text-slate-900 dark:text-white">{f.title}</p>
                <p className="truncate text-xs text-slate-400">{[SECTIONS[f.section]?.label, f.subject, f.author, f.year].filter(Boolean).join(' · ')}</p>
              </div>
              <div className="hidden shrink-0 text-left text-xs text-slate-400 sm:block">
                <p>{formatBytes(f.file_size)}</p>
                <p className="mt-1 inline-flex items-center gap-1"><Download className="h-3 w-3" /> {f.download_count}</p>
                <p className="mt-1">{formatDate(f.created_at)}</p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button onClick={() => toggleFlag(f, 'featured')} title="تمييز" className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-accent dark:hover:bg-white/10"><Star className={`h-4 w-4 ${f.featured ? 'fill-accent text-accent' : ''}`} /></button>
                <button onClick={() => setPreview(f)} title="معاينة" className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-white/10"><Eye className="h-4 w-4" /></button>
                <button onClick={() => openEdit(f)} title="تعديل" className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-white/10"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => setDeleteRec(f)} title="حذف" className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit modal */}
      <Modal open={!!editRec} onClose={() => { if (!saving) { setEditRec(null); setEditForm(null); } }} title="تعديل الملف" wide>
        {editRec && editForm && (
          <div className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-white/10 dark:bg-white/5">
              <div className="min-w-0">
                <p className="text-xs font-semibold uppercase text-slate-400">الملف الحالي</p>
                <p className="mt-0.5 truncate text-sm font-semibold text-slate-800 dark:text-slate-100">{editRec.file_name || editRec.file_path}</p>
                <p className="text-xs text-slate-400">{formatBytes(editRec.file_size)}</p>
              </div>
              <div>
                <button onClick={() => replaceInput.current?.click()} disabled={!!replacing} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                  {replacing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />} استبدال الملف
                </button>
                <input ref={replaceInput} type="file" accept={ACCEPT_ATTR} className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (file && editRec) onReplace(editRec, file); e.target.value = ''; }} />
              </div>
            </div>
            {replacing && replacing.id === editRec.id && <div><div className="mb-1 flex justify-between text-xs text-slate-500"><span>جارٍ الاستبدال…</span><span>{replacing.progress}%</span></div><ProgressBar value={replacing.progress} /></div>}
            <FileMetaForm value={editForm} onChange={setEditForm} categories={categories} idPrefix={`edit-${editRec.id}`} />
            <div className="flex justify-end gap-3 border-t border-slate-100 pt-4 dark:border-white/10">
              <button onClick={() => { setEditRec(null); setEditForm(null); }} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10">إلغاء</button>
              <button onClick={saveEdit} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">{saving && <Loader2 className="h-4 w-4 animate-spin" />} حفظ</button>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={!!preview} onClose={() => setPreview(null)} title={preview?.title} wide>
        {preview && <PdfViewer url={preview.file_url} fileType={preview.file_type || preview.file_name} className="h-[70vh]" />}
      </Modal>

      <Modal open={!!deleteRec} onClose={() => { if (!deleting) setDeleteRec(null); }} title="حذف الملف">
        {deleteRec && (
          <div>
            <p className="text-sm text-slate-600 dark:text-slate-300">هل تريد حذف <span className="font-bold text-slate-900 dark:text-white">«{deleteRec.title}»</span> نهائيًا؟ لا يمكن التراجع.</p>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setDeleteRec(null)} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10">إلغاء</button>
              <button onClick={confirmDelete} disabled={deleting} className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-4 py-2 text-sm font-bold text-white hover:bg-red-700 disabled:opacity-60">{deleting && <Loader2 className="h-4 w-4 animate-spin" />} حذف نهائي</button>
            </div>
          </div>
        )}
      </Modal>
    </AdminShell>
  );
}

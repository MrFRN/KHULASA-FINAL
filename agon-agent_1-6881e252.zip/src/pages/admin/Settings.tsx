import { useEffect, useRef, useState } from 'react';
import { Loader2, Save, Image as ImageIcon, Upload, Trash2 } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import { useToast } from '../../components/Toast';
import { useSettings } from '../../contexts/SettingsContext';
import { updateSettings, uploadToStorage } from '../../lib/api';
import { DEFAULT_SETTINGS } from '../../lib/constants';
import type { SiteSettings } from '../../types';

const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';
const label = 'mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200';
const uid = () => (crypto.randomUUID && crypto.randomUUID()) || Math.random().toString(36).slice(2);

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
      <h3 className="mb-4 font-bold text-slate-900 dark:text-white">{title}</h3>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

export default function SettingsPage() {
  const { toast } = useToast();
  const { raw, refresh } = useSettings();
  const [form, setForm] = useState<SiteSettings>(raw);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const logoInput = useRef<HTMLInputElement>(null);
  const bannerInput = useRef<HTMLInputElement>(null);

  useEffect(() => { setForm(raw); }, [raw]);
  const set = (patch: Partial<SiteSettings>) => setForm((f) => ({ ...f, ...patch }));

  const uploadImage = async (file: File, kind: 'logo' | 'banner') => {
    const setBusy = kind === 'logo' ? setUploadingLogo : setUploadingBanner;
    setBusy(true);
    try {
      const path = `${kind}-${uid()}.${file.name.split('.').pop() || 'png'}`;
      const { publicUrl } = await uploadToStorage('media', path, file, file.type, () => {}, false);
      if (kind === 'logo') set({ logoUrl: publicUrl }); else set({ bannerUrl: publicUrl });
      toast('تم رفع الصورة', 'success');
    } catch (e) { toast((e as Error).message, 'error'); } finally { setBusy(false); }
  };

  const save = async () => {
    setSaving(true);
    try {
      await updateSettings(form as unknown as Record<string, string>);
      toast('تم حفظ الإعدادات', 'success');
      refresh();
    } catch (e) { toast((e as Error).message, 'error'); } finally { setSaving(false); }
  };

  return (
    <AdminShell title="الإعدادات">
      <div className="mb-6 flex items-center justify-between gap-3">
        <p className="text-sm text-slate-500 dark:text-slate-400">تحكّم كامل في محتوى الموقع دون لمس الكود.</p>
        <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-60">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} حفظ التغييرات</button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="الهوية والعلامة التجارية">
          <div><label className={label}>اسم الموقع</label><input className={input} value={form.siteName} onChange={(e) => set({ siteName: e.target.value })} /></div>
          <div><label className={label}>الشعار النصي (Tagline)</label><input className={input} value={form.tagline} onChange={(e) => set({ tagline: e.target.value })} /></div>
          <div>
            <label className={label}>شعار الموقع (Logo)</label>
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-white/10 dark:bg-white/5">{form.logoUrl ? <img src={form.logoUrl} alt="logo" className="h-full w-full object-cover" /> : <ImageIcon className="h-6 w-6 text-slate-300" />}</div>
              <button onClick={() => logoInput.current?.click()} disabled={uploadingLogo} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">{uploadingLogo ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} رفع</button>
              {form.logoUrl && <button onClick={() => set({ logoUrl: '' })} className="rounded-lg p-2 text-slate-400 hover:text-red-500"><Trash2 className="h-4 w-4" /></button>}
              <input ref={logoInput} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadImage(f, 'logo'); e.target.value = ''; }} />
            </div>
          </div>
          <div>
            <label className={label}>بانر الصفحة الرئيسية</label>
            <div className="flex items-center gap-3">
              <div className="flex h-14 w-24 items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-white/10 dark:bg-white/5">{form.bannerUrl ? <img src={form.bannerUrl} alt="banner" className="h-full w-full object-cover" /> : <ImageIcon className="h-6 w-6 text-slate-300" />}</div>
              <button onClick={() => bannerInput.current?.click()} disabled={uploadingBanner} className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-60 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">{uploadingBanner ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} رفع</button>
              {form.bannerUrl && <button onClick={() => set({ bannerUrl: '' })} className="rounded-lg p-2 text-slate-400 hover:text-red-500"><Trash2 className="h-4 w-4" /></button>}
              <input ref={bannerInput} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) uploadImage(f, 'banner'); e.target.value = ''; }} />
            </div>
          </div>
        </Card>

        <Card title="نصوص الصفحة الرئيسية (عربي)">
          <div><label className={label}>العنوان الرئيسي</label><input className={input} value={form.heroTitle} onChange={(e) => set({ heroTitle: e.target.value })} /></div>
          <div><label className={label}>الوصف الفرعي</label><textarea className={`${input} min-h-20 resize-y`} value={form.heroSubtitle} onChange={(e) => set({ heroSubtitle: e.target.value })} /></div>
          <div><label className={label}>نص زر الدعوة</label><input className={input} value={form.heroCta} onChange={(e) => set({ heroCta: e.target.value })} /></div>
          <div><label className={label}>نبذة عن الموقع</label><textarea className={`${input} min-h-20 resize-y`} value={form.aboutText} onChange={(e) => set({ aboutText: e.target.value })} /></div>
        </Card>

        <Card title="Homepage copy (English)">
          <div><label className={label}>Site name</label><input className={input} value={form.siteNameEn || ''} onChange={(e) => set({ siteNameEn: e.target.value })} /></div>
          <div><label className={label}>Tagline</label><input className={input} value={form.taglineEn || ''} onChange={(e) => set({ taglineEn: e.target.value })} /></div>
          <div><label className={label}>Hero title</label><input className={input} value={form.heroTitleEn || ''} onChange={(e) => set({ heroTitleEn: e.target.value })} /></div>
          <div><label className={label}>Hero subtitle</label><textarea className={`${input} min-h-20 resize-y`} value={form.heroSubtitleEn || ''} onChange={(e) => set({ heroSubtitleEn: e.target.value })} /></div>
          <div><label className={label}>CTA</label><input className={input} value={form.heroCtaEn || ''} onChange={(e) => set({ heroCtaEn: e.target.value })} /></div>
          <div><label className={label}>About</label><textarea className={`${input} min-h-20 resize-y`} value={form.aboutTextEn || ''} onChange={(e) => set({ aboutTextEn: e.target.value })} /></div>
          <div><label className={label}>Footer</label><textarea className={`${input} min-h-20 resize-y`} value={form.footerTextEn || ''} onChange={(e) => set({ footerTextEn: e.target.value })} /></div>
        </Card>

        <Card title="روابط التواصل">
          <div><label className={label}>رابط تيليجرام</label><input dir="ltr" className={input} value={form.telegram} onChange={(e) => set({ telegram: e.target.value })} placeholder="https://t.me/..." /></div>
          <div><label className={label}>رابط فيسبوك</label><input dir="ltr" className={input} value={form.facebook} onChange={(e) => set({ facebook: e.target.value })} placeholder="https://facebook.com/..." /></div>
          <div><label className={label}>البريد الإلكتروني</label><input dir="ltr" className={input} value={form.email} onChange={(e) => set({ email: e.target.value })} placeholder="info@example.com" /></div>
        </Card>

        <Card title="الفوتر">
          <div><label className={label}>نص الفوتر</label><textarea className={`${input} min-h-24 resize-y`} value={form.footerText} onChange={(e) => set({ footerText: e.target.value })} /></div>
          <button onClick={() => setForm(DEFAULT_SETTINGS)} className="text-sm font-semibold text-slate-500 hover:text-primary dark:text-slate-400">استعادة القيم الافتراضية</button>
        </Card>
      </div>

      <div className="mt-6 flex justify-end">
        <button onClick={save} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-6 py-3 text-sm font-bold text-white disabled:opacity-60">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} حفظ التغييرات</button>
      </div>
    </AdminShell>
  );
}

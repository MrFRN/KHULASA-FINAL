import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { UploadCloud, Eye, Trash2, Image as ImageIcon, CheckCircle2, AlertTriangle, Loader2, ArrowRight } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import FileMetaForm, { emptyMeta } from '../../components/FileMetaForm';
import type { MetaForm } from '../../components/FileMetaForm';
import ProgressBar from '../../components/ProgressBar';
import FileTypeChip from '../../components/FileTypeChip';
import Modal from '../../components/Modal';
import PdfViewer from '../../components/PdfViewer';
import { useToast } from '../../components/Toast';
import { uploadToStorage, uploadResourceFile, createResource, createChunks, fetchAdminResources, fetchCategories } from '../../lib/api';
import type { Chunk } from '../../lib/api';
import { generatePdfThumbnail } from '../../lib/pdf';
import { ACCEPT_ATTR, MAX_FILE_SIZE, isAllowed, extOf, isPdfType } from '../../lib/filetypes';
import { formatBytes } from '../../lib/format';
import type { NursingCategory, Section } from '../../types';

type ItemStatus = 'uploading' | 'ready' | 'error' | 'duplicate' | 'saving' | 'done';
interface UploadItem {
  key: string; file: File; progress: number; status: ItemStatus; error?: string;
  filePath?: string; fileUrl?: string; multi?: boolean; chunks?: Chunk[];
  coverUrl?: string | null; coverPath?: string | null; coverBusy?: boolean;
  form: MetaForm;
}
const uid = () => (crypto.randomUUID && crypto.randomUUID()) || Math.random().toString(36).slice(2);

export default function UploadPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<UploadItem[]>([]);
  const [categories, setCategories] = useState<NursingCategory[]>([]);
  const [defaultSection, setDefaultSection] = useState<Section>('study');
  const [dragOver, setDragOver] = useState(false);
  const [existing, setExisting] = useState<Set<string>>(new Set());
  const [preview, setPreview] = useState<{ url: string; type: string; revoke: boolean } | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchCategories().then(setCategories).catch(() => {});
    fetchAdminResources().then((r) => setExisting(new Set(r.map((x) => `${x.file_name}|${x.file_size}`)))).catch(() => {});
  }, []);

  const patch = useCallback((key: string, p: Partial<UploadItem>) => {
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...p } : it)));
  }, []);
  const patchForm = useCallback((key: string, form: MetaForm) => {
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, form } : it)));
  }, []);

  const startUpload = useCallback(async (item: UploadItem) => {
    try {
      const res = await uploadResourceFile(item.file, (pct) => patch(item.key, { progress: pct }));
      patch(item.key, { status: 'ready', filePath: res.file_path, fileUrl: res.file_url, multi: res.multi, chunks: res.chunks, progress: 100 });
      if (isPdfType(item.file.type || item.file.name) && item.file.size <= 60 * 1024 * 1024) {
        patch(item.key, { coverBusy: true });
        const thumb = await generatePdfThumbnail(item.file);
        if (thumb) {
          const coverPath = `${uid()}.jpg`;
          try {
            const c = await uploadToStorage('covers', coverPath, thumb, 'image/jpeg', () => {}, false);
            patch(item.key, { coverUrl: c.publicUrl, coverPath, coverBusy: false });
          } catch { patch(item.key, { coverBusy: false }); }
        } else patch(item.key, { coverBusy: false });
      }
    } catch (e) {
      patch(item.key, { status: 'error', error: (e as Error).message });
    }
  }, [patch]);

  const addFiles = useCallback((fileList: FileList | File[]) => {
    const next: UploadItem[] = [];
    for (const file of Array.from(fileList)) {
      if (!isAllowed(file.name)) { toast(`"${file.name}" — نوع غير مدعوم`, 'error'); continue; }
      if (file.size > MAX_FILE_SIZE) { toast(`"${file.name}" يتجاوز ${formatBytes(MAX_FILE_SIZE)}`, 'error'); continue; }
      const isDup = existing.has(`${file.name}|${file.size}`);
      next.push({
        key: uid(), file, progress: 0,
        status: isDup ? 'duplicate' : 'uploading',
        error: isDup ? 'ملف بنفس الاسم والحجم موجود بالفعل.' : undefined,
        form: { ...emptyMeta(defaultSection), title: file.name.replace(/\.[^.]+$/, '') },
      });
    }
    if (!next.length) return;
    setItems((prev) => [...next, ...prev]);
    next.forEach((it) => { if (it.status === 'uploading') startUpload(it); });
  }, [existing, startUpload, toast, defaultSection]);

  const removeItem = (key: string) => setItems((prev) => prev.filter((it) => it.key !== key));

  const replaceCover = async (item: UploadItem, file: File) => {
    patch(item.key, { coverBusy: true });
    try {
      const coverPath = `${uid()}.${extOf(file.name) || 'jpg'}`;
      const c = await uploadToStorage('covers', coverPath, file, file.type, () => {}, false);
      patch(item.key, { coverUrl: c.publicUrl, coverPath, coverBusy: false });
      toast('تم تحديث صورة الغلاف', 'success');
    } catch (e) { patch(item.key, { coverBusy: false }); toast((e as Error).message, 'error'); }
  };

  const publishItem = async (item: UploadItem) => {
    const f = item.form;
    if (!f.title.trim()) { toast('أدخل عنوانًا', 'error'); return; }
    if (f.status === 'scheduled') {
      if (!f.scheduled_at) { toast('اختر تاريخ النشر', 'error'); return; }
      if (new Date(f.scheduled_at) <= new Date()) { toast('الجدولة يجب أن تكون في المستقبل', 'error'); return; }
    }
    if (!item.filePath) { toast('الملف لا يزال يُرفع', 'error'); return; }
    patch(item.key, { status: 'saving' });
    try {
      const created = await createResource({
        title: f.title.trim(), description: f.description || null, section: f.section,
        category: f.category || null, year: f.year || null, subject: f.subject || null,
        author: f.author || null, edition: f.edition || null,
        tags: f.tags.split(',').map((t) => t.trim()).filter(Boolean),
        file_name: item.file.name, file_path: item.filePath, file_url: item.fileUrl || '',
        file_size: item.file.size, file_type: item.file.type || extOf(item.file.name),
        cover_image_url: item.coverUrl || null, cover_path: item.coverPath || null,
        status: f.status, featured: f.featured, popular: f.popular,
        scheduled_at: f.status === 'scheduled' ? new Date(f.scheduled_at).toISOString() : null,
      });
      if (item.multi && item.chunks && item.chunks.length) await createChunks(created.id, item.chunks);
      patch(item.key, { status: 'done' });
      toast(`تم ${f.status === 'draft' ? 'الحفظ كمسودة' : f.status === 'scheduled' ? 'جدولة الملف' : 'نشر الملف'}`, 'success');
    } catch (e) {
      patch(item.key, { status: 'ready', error: (e as Error).message });
      toast((e as Error).message, 'error');
    }
  };

  const readyCount = items.filter((i) => i.status === 'ready').length;
  const publishAll = async () => { for (const it of items.filter((i) => i.status === 'ready' && i.form.title.trim())) await publishItem(it); };

  const openPreview = (item: UploadItem) => setPreview({ url: item.fileUrl || URL.createObjectURL(item.file), type: item.file.type || item.file.name, revoke: !item.fileUrl });
  const closePreview = () => { if (preview?.revoke) URL.revokeObjectURL(preview.url); setPreview(null); };

  return (
    <AdminShell title="رفع ملفات">
      <Link to="/admin" className="mb-6 inline-flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-primary dark:text-slate-400">العودة للوحة <ArrowRight className="h-4 w-4" /></Link>
      <p className="mb-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs leading-6 text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-100">
        إذا ظهر خطأ RLS عند أول رفع: افتح Supabase → SQL Editor ونفّذ ملف <code className="font-bold">scripts/fix-rls.sql</code> مرة واحدة، ثم أعد المحاولة وأنت مسجّل كأدمن.
      </p>

      <div className="mb-4 flex items-center gap-3">
        <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">القسم الافتراضي:</span>
        <select value={defaultSection} onChange={(e) => setDefaultSection(e.target.value as Section)} className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white">
          <option value="study">ملفات دراسية</option>
          <option value="books">كتب التمريض</option>
          <option value="interview">أسئلة الانترفيو</option>
        </select>
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files); }}
        onClick={() => fileInput.current?.click()}
        className={`flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-14 text-center transition ${dragOver ? 'border-primary bg-primary/5' : 'border-slate-300 bg-white hover:border-primary dark:border-white/15 dark:bg-white/5'}`}
      >
        <span className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-white"><UploadCloud className="h-7 w-7" /></span>
        <p className="text-base font-bold text-slate-900 dark:text-white">اسحب وأفلت الملفات هنا</p>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">أو اضغط للاختيار — يدعم رفع عدة ملفات</p>
        <p className="mt-3 text-xs text-slate-400">PDF, DOCX, PPTX, XLSX, ZIP, RAR, صور · حتى {formatBytes(MAX_FILE_SIZE)} — يتم تقسيم الملفات الكبيرة تلقائيًا</p>
        <input ref={fileInput} type="file" multiple accept={ACCEPT_ATTR} className="hidden" onChange={(e) => { if (e.target.files) addFiles(e.target.files); e.target.value = ''; }} />
      </div>

      {items.length > 0 && (
        <div className="mt-6 flex items-center justify-between">
          <p className="text-sm text-slate-500 dark:text-slate-400">{items.length} ملف في القائمة</p>
          <button onClick={publishAll} disabled={readyCount === 0} className="rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-50">نشر الكل ({readyCount})</button>
        </div>
      )}

      <div className="mt-4 space-y-4">
        {items.map((item) => (
          <div key={item.key} className="animate-fade-up rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex min-w-0 items-center gap-3">
                <FileTypeChip name={item.file.type || item.file.name} />
                <div className="min-w-0"><p className="truncate font-semibold text-slate-900 dark:text-white">{item.file.name}</p><p className="text-xs text-slate-400">{formatBytes(item.file.size)}</p></div>
              </div>
              <div className="flex items-center gap-1.5">
                <button onClick={() => openPreview(item)} className="rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-white/10"><Eye className="h-4.5 w-4.5" /></button>
                <button onClick={() => removeItem(item.key)} className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10"><Trash2 className="h-4.5 w-4.5" /></button>
              </div>
            </div>

            {item.status === 'uploading' && <div className="mt-4"><div className="mb-1.5 flex justify-between text-xs text-slate-500"><span>جارٍ الرفع…</span><span>{item.progress}%</span></div><ProgressBar value={item.progress} /></div>}
            {item.status === 'duplicate' && <div className="mt-4 flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-700 dark:bg-amber-500/10 dark:text-amber-300"><AlertTriangle className="h-4 w-4" /> {item.error}</div>}
            {item.status === 'error' && <div className="mt-4 flex items-center gap-2 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-500/10 dark:text-red-300"><AlertTriangle className="h-4 w-4" /> {item.error}</div>}
            {item.status === 'done' && <div className="mt-4 flex items-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"><CheckCircle2 className="h-4 w-4" /> تمت الإضافة إلى المكتبة.</div>}

            {(item.status === 'ready' || item.status === 'saving') && (
              <div className="mt-5 grid gap-6 lg:grid-cols-[190px_1fr]">
                <div>
                  <p className="mb-2 text-sm font-semibold text-slate-700 dark:text-slate-200">الغلاف</p>
                  <div className="relative flex aspect-[3/4] items-center justify-center overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-white/10 dark:bg-white/5">
                    {item.coverBusy ? <Loader2 className="h-5 w-5 animate-spin text-slate-400" /> : item.coverUrl ? <img src={item.coverUrl} alt="" className="h-full w-full object-cover" /> : <ImageIcon className="h-8 w-8 text-slate-300" />}
                  </div>
                  <label className="mt-2 block">
                    <span className="block cursor-pointer rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-center text-xs font-semibold text-slate-600 hover:bg-slate-50 dark:border-white/10 dark:bg-white/5 dark:text-slate-300">{item.coverUrl ? 'تغيير الغلاف' : 'إضافة غلاف'}</span>
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) replaceCover(item, f); e.target.value = ''; }} />
                  </label>
                </div>
                <div>
                  <FileMetaForm value={item.form} onChange={(v) => patchForm(item.key, v)} categories={categories} idPrefix={item.key} />
                  <div className="mt-5 flex items-center gap-3">
                    <button onClick={() => publishItem(item)} disabled={item.status === 'saving'} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60">
                      {item.status === 'saving' && <Loader2 className="h-4 w-4 animate-spin" />}
                      {item.form.status === 'draft' ? 'حفظ كمسودة' : item.form.status === 'scheduled' ? 'جدولة' : 'نشر'}
                    </button>
                    <button onClick={() => removeItem(item.key)} className="text-sm font-semibold text-slate-500 hover:text-slate-800 dark:text-slate-400">حذف</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <Modal open={!!preview} onClose={closePreview} title="معاينة" wide>
        {preview && <PdfViewer url={preview.url} fileType={preview.type} className="h-[70vh]" />}
      </Modal>
    </AdminShell>
  );
}

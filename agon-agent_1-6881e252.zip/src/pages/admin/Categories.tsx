import { useEffect, useState } from 'react';
import { Plus, Folder, Pencil, Trash2, Loader2, FolderTree } from 'lucide-react';
import AdminShell from '../../components/AdminShell';
import Modal from '../../components/Modal';
import Spinner from '../../components/Spinner';
import Icon, { ICON_NAMES } from '../../components/Icon';
import { useToast } from '../../components/Toast';
import { fetchCategories, createCategory, updateCategory, deleteCategory } from '../../lib/api';
import { slugify } from '../../lib/constants';
import { SECTIONS } from '../../lib/constants';
import type { NursingCategory, Section } from '../../types';

const SECTION_OPTS: { value: Section; label: string }[] = [
  { value: 'study', label: 'ملفات دراسية' },
  { value: 'books', label: 'كتب التمريض' },
  { value: 'interview', label: 'أسئلة الانترفيو' },
];
const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';

export default function CategoriesPage() {
  const { toast } = useToast();
  const [cats, setCats] = useState<NursingCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [section, setSection] = useState<Section>('study');
  const [icon, setIcon] = useState('FileText');
  const [adding, setAdding] = useState(false);
  const [editRec, setEditRec] = useState<NursingCategory | null>(null);
  const [editName, setEditName] = useState('');
  const [editIcon, setEditIcon] = useState('FileText');
  const [saving, setSaving] = useState(false);
  const [deleteRec, setDeleteRec] = useState<NursingCategory | null>(null);

  const load = () => { fetchCategories().then(setCats).catch((e) => toast(e.message, 'error')).finally(() => setLoading(false)); };
  useEffect(load, []); // eslint-disable-line react-hooks/exhaustive-deps

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) { toast('أدخل الاسم', 'error'); return; }
    setAdding(true);
    try {
      await createCategory({ name: name.trim(), slug: slugify(name) || `cat-${Date.now()}`, section, icon });
      toast('تمت الإضافة', 'success'); setName(''); load();
    } catch (err) { toast((err as Error).message, 'error'); } finally { setAdding(false); }
  };

  const saveEdit = async () => {
    if (!editRec || !editName.trim()) return;
    setSaving(true);
    try { await updateCategory({ id: editRec.id, name: editName.trim(), icon: editIcon }); toast('تم التعديل', 'success'); setEditRec(null); load(); }
    catch (err) { toast((err as Error).message, 'error'); } finally { setSaving(false); }
  };

  const remove = async () => {
    if (!deleteRec) return;
    try { await deleteCategory(deleteRec.id); toast('تم الحذف', 'success'); setDeleteRec(null); load(); }
    catch (err) { toast((err as Error).message, 'error'); }
  };

  return (
    <AdminShell title="التصنيفات">
      <p className="mb-6 text-sm text-slate-500 dark:text-slate-400">نظّم المحتوى داخل كل قسم. تظهر هذه التصنيفات للزوار وفي نموذج الرفع.</p>
      <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
        <form onSubmit={add} className="h-fit rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
          <h2 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><Plus className="h-4.5 w-4.5" /> إضافة تصنيف</h2>
          <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">الاسم</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: ICU" className={input} />
          <label className="mb-1 mt-4 block text-sm font-semibold text-slate-700 dark:text-slate-200">القسم</label>
          <select value={section} onChange={(e) => setSection(e.target.value as Section)} className={input}>{SECTION_OPTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</select>
          <label className="mb-1 mt-4 block text-sm font-semibold text-slate-700 dark:text-slate-200">الأيقونة</label>
          <div className="flex items-center gap-2">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Icon name={icon} className="h-5 w-5" /></span>
            <select value={icon} onChange={(e) => setIcon(e.target.value)} className={input}>{ICON_NAMES.map((n) => <option key={n} value={n}>{n}</option>)}</select>
          </div>
          <button type="submit" disabled={adding} className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-bold text-white disabled:opacity-60">{adding && <Loader2 className="h-4 w-4 animate-spin" />} إضافة</button>
        </form>

        <div className="space-y-6">
          {loading ? <div className="flex justify-center py-16"><Spinner label="جارٍ التحميل…" /></div> : (
            SECTION_OPTS.map((s) => {
              const list = cats.filter((c) => c.section === s.value);
              return (
                <div key={s.value} className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
                  <h3 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><Icon name={SECTIONS[s.value].icon} className="h-5 w-5 text-primary" /> {s.label} <span className="text-sm font-normal text-slate-400">({list.length})</span></h3>
                  {list.length === 0 ? <p className="flex items-center gap-2 text-sm text-slate-400"><FolderTree className="h-4 w-4" /> لا توجد تصنيفات</p> : (
                    <div className="grid gap-2 sm:grid-cols-2">
                      {list.map((c) => (
                        <div key={c.id} className="flex items-center justify-between rounded-xl border border-slate-100 px-3 py-2 dark:border-white/10">
                          <span className="flex items-center gap-2 text-sm font-semibold text-slate-700 dark:text-slate-200"><Icon name={c.icon || 'Folder'} className="h-4 w-4 text-slate-400" /> {c.name}</span>
                          <div className="flex items-center gap-1">
                            <button onClick={() => { setEditRec(c); setEditName(c.name); setEditIcon(c.icon || 'FileText'); }} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-primary dark:hover:bg-white/10"><Pencil className="h-3.5 w-3.5" /></button>
                            <button onClick={() => setDeleteRec(c)} className="rounded-lg p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-500 dark:hover:bg-red-500/10"><Trash2 className="h-3.5 w-3.5" /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      <Modal open={!!editRec} onClose={() => setEditRec(null)} title="تعديل التصنيف">
        <label className="mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200">الاسم</label>
        <input value={editName} onChange={(e) => setEditName(e.target.value)} className={input} />
        <label className="mb-1 mt-4 block text-sm font-semibold text-slate-700 dark:text-slate-200">الأيقونة</label>
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary"><Icon name={editIcon} className="h-5 w-5" /></span>
          <select value={editIcon} onChange={(e) => setEditIcon(e.target.value)} className={input}>{ICON_NAMES.map((n) => <option key={n} value={n}>{n}</option>)}</select>
        </div>
        <div className="mt-5 flex justify-end gap-3">
          <button onClick={() => setEditRec(null)} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10">إلغاء</button>
          <button onClick={saveEdit} disabled={saving} className="inline-flex items-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2 text-sm font-bold text-white disabled:opacity-60">{saving && <Loader2 className="h-4 w-4 animate-spin" />} حفظ</button>
        </div>
      </Modal>

      <Modal open={!!deleteRec} onClose={() => setDeleteRec(null)} title="حذف التصنيف">
        {deleteRec && (
          <div>
            <p className="text-sm text-slate-600 dark:text-slate-300">حذف <span className="font-bold text-slate-900 dark:text-white">«{deleteRec.name}»</span>؟ الملفات تبقى كما هي.</p>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setDeleteRec(null)} className="rounded-lg px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/10">إلغاء</button>
              <button onClick={remove} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-bold text-white hover:bg-red-700">حذف</button>
            </div>
          </div>
        )}
      </Modal>
    </AdminShell>
  );
}

import AITool from '../components/AITool';
import TOOLS from './tools';

// Care Plan is the long-form NANDA-I page; the rest of the tools use the
// shared AITool component.
import CarePlanFull from './CarePlanFull';

export const CarePlanPage = () => <CarePlanFull />;
export const CalculatorPage = () => <AITool config={TOOLS['calculator']} />;
export const CaseLegacyPage = () => <AITool config={TOOLS['case']} />;
import CaseSimulation from './CaseSimulation';
export const CasePage = () => <CaseSimulation />;

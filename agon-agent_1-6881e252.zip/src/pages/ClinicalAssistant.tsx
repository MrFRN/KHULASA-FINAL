import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, BrainCircuit, FileUp, History as HistoryIcon, Loader2, PenLine, Save, Search, ShieldCheck, Sparkles } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import SymptomPicker from '../components/SymptomPicker';
import ReportView from '../components/ReportView';
import { useToast } from '../components/Toast';
import { useAuth } from '../contexts/AuthContext';
import { analyzeCase, getAiHistory, getAiAnalysis, parseCaseText, AiReport, ParsedCase } from '../lib/api';

const input = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white';
const label = 'mb-1 block text-sm font-semibold text-slate-700 dark:text-slate-200';

const VITALS = [
  { k: 'temp', ar: 'Temperature', unit: '°C', ph: '37.0' },
  { k: 'sbp', ar: 'Systolic BP', unit: 'mmHg', ph: '120' },
  { k: 'dbp', ar: 'Diastolic BP', unit: 'mmHg', ph: '80' },
  { k: 'hr', ar: 'Heart Rate', unit: 'bpm', ph: '80' },
  { k: 'rr', ar: 'Respiratory Rate', unit: '/min', ph: '16' },
  { k: 'spo2', ar: 'Oxygen Saturation', unit: '%', ph: '98' },
  { k: 'glucose', ar: 'Blood Glucose', unit: 'mg/dL', ph: '100' },
];
const LABS = [
  { k: 'wbc', ar: 'WBC', unit: '10³/µL' }, { k: 'hgb', ar: 'Hemoglobin', unit: 'g/dL' },
  { k: 'plt', ar: 'Platelets', unit: '10³/µL' }, { k: 'crp', ar: 'CRP', unit: 'mg/L' },
  { k: 'esr', ar: 'ESR', unit: 'mm/h' }, { k: 'troponin', ar: 'Troponin', unit: 'ng/mL' },
  { k: 'lactate', ar: 'Lactate', unit: 'mmol/L' }, { k: 'd_dimer', ar: 'D-Dimer', unit: 'µg/mL' },
  { k: 'hba1c', ar: 'HbA1c', unit: '%' }, { k: 'glucose', ar: 'Fasting Glucose', unit: 'mg/dL' },
  { k: 'creatinine', ar: 'Creatinine', unit: 'mg/dL' }, { k: 'sodium', ar: 'Sodium', unit: 'mmol/L' },
  { k: 'potassium', ar: 'Potassium', unit: 'mmol/L' }, { k: 'inr', ar: 'INR', unit: '' },
  { k: 'amylase', ar: 'Amylase', unit: 'U/L' }, { k: 'lipase', ar: 'Lipase', unit: 'U/L' },
  { k: 'uric_acid', ar: 'Uric Acid', unit: 'mg/dL' }, { k: 'bilirubin', ar: 'Bilirubin', unit: 'mg/dL' },
  { k: 'alt', ar: 'ALT', unit: 'U/L' }, { k: 'ast', ar: 'AST', unit: 'U/L' },
];
const IMAGING = ['Chest X-ray', 'CT', 'MRI', 'Ultrasound', 'ECG', 'Echo', 'Other'];
const HISTORY = ['Diabetes', 'Hypertension', 'Heart disease', 'Asthma/COPD', 'Kidney disease', 'Liver disease', 'Cancer', 'Previous surgery', 'Immunocompromised'];

function Collapsible({ title, icon: Icon, children, defaultOpen = false }: { title: string; icon: any; children: React.ReactNode; defaultOpen?: boolean }) {
  const [o, setO] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-slate-200 bg-white/60 p-4 dark:border-white/10 dark:bg-white/5">
      <button type="button" onClick={() => setO(!o)} className="flex w-full items-center justify-between text-sm font-bold text-slate-800 dark:text-slate-100">
        <span className="flex items-center gap-2"><Icon className="h-4 w-4 text-primary" /> {title}</span>
        <span className="text-slate-400">{o ? '−' : '+'}</span>
      </button>
      {o && <div className="mt-3 space-y-3">{children}</div>}
    </div>
  );
}

export default function ClinicalAssistant() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [form, setForm] = useState<any>({ gender: '', smoking: '', symptoms: [], labs: {}, imaging: [], history: [] });
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<AiReport | null>(null);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [histList, setHistList] = useState<any[]>([]);
  const [histLoading, setHistLoading] = useState(false);
  const [lang, setLang] = useState<'en' | 'ar'>('en');
  const isAr = lang === 'ar';
  const [entryMode, setEntryMode] = useState<'form' | 'write' | 'upload'>('write');
  const [caseDraft, setCaseDraft] = useState('');
  const [parsed, setParsed] = useState<ParsedCase | null>(null);
  const [extracting, setExtracting] = useState(false);
  const [confirmedReady, setConfirmedReady] = useState(false);

  const set = (patch: any) => setForm((f: any) => ({ ...f, ...patch }));

  const applyParsed = (p: ParsedCase) => {
    const f = p.fields || {};
    const v = (k: string, fallback: any = '') => (f[k] && f[k].status !== 'missing' ? f[k].value : fallback);
    setForm((prev: any) => ({
      ...prev,
      age: v('age', prev.age),
      ageMonths: v('ageMonths', prev.ageMonths),
      gender: v('gender', prev.gender),
      weight: v('weight', prev.weight),
      height: v('height', prev.height),
      pregnancy: !!v('pregnancy', prev.pregnancy),
      gestationalAge: v('gestationalAge', prev.gestationalAge),
      breastfeeding: !!v('breastfeeding', prev.breastfeeding),
      chiefComplaint: v('chiefComplaint', prev.chiefComplaint),
      presentIllness: v('presentIllness', prev.presentIllness),
      history: Array.isArray(v('history', prev.history)) ? v('history', prev.history) : prev.history,
      surgicalHistory: v('surgicalHistory', prev.surgicalHistory),
      allergies: v('allergies', prev.allergies),
      medications: v('medications', prev.medications),
      physicalExam: v('physicalExam', prev.physicalExam),
      vitals: { ...(prev.vitals || {}), ...(v('vitals', {}) || {}) },
      labs: { ...(prev.labs || {}), ...(v('labs', {}) || {}) },
      imaging: Array.isArray(v('imaging', prev.imaging)) ? v('imaging', prev.imaging) : prev.imaging,
      imagingNote: v('imagingNote', prev.imagingNote),
      symptoms: Array.isArray(v('symptoms', prev.symptoms)) ? v('symptoms', prev.symptoms) : prev.symptoms,
      smoking: v('smoking', prev.smoking),
    }));
    setParsed(p);
    setConfirmedReady(false);
    setReport(null);
  };

  const extractFromText = async (text: string) => {
    if (!text.trim()) {
      toast(isAr ? 'اكتب الحالة أو الصقها أولاً' : 'Write or paste the case first', 'error');
      return;
    }
    setExtracting(true);
    try {
      const p = await parseCaseText({ text, lang });
      if (!p.ok && p.error) toast(p.error, 'error');
      applyParsed(p);
      toast(isAr ? 'تم استخراج البيانات — راجعها قبل التحليل' : 'Extracted. Review before analysis.', 'success');
    } catch (e: any) {
      toast(e.message || (isAr ? 'تعذّر الاستخراج' : 'Extraction failed'), 'error');
    } finally { setExtracting(false); }
  };

  const extractFromFile = async (file: File) => {
    setExtracting(true);
    try {
      if (file.type.startsWith('text/') || /\.txt$/i.test(file.name)) {
        const text = await file.text();
        await extractFromText(text);
        return;
      }
      const b64 = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(String(r.result).split(',')[1] || '');
        r.onerror = () => reject(new Error('read failed'));
        r.readAsDataURL(file);
      });
      const p = await parseCaseText({ fileBase64: b64, fileName: file.name, contentType: file.type, lang });
      if (p.needsText || (!p.ok && p.error)) {
        toast(p.error || (isAr ? 'تعذّر قراءة الملف — الصق النص' : 'Could not read file — paste the text'), 'error');
      }
      applyParsed(p);
    } catch (e: any) {
      toast(e.message || (isAr ? 'تعذّر رفع الملف' : 'Upload failed'), 'error');
    } finally { setExtracting(false); }
  };

  const analyze = async (opts?: { confirmed?: boolean }) => {
    const okConfirm = opts?.confirmed || confirmedReady || entryMode === 'form';
    if ((entryMode === 'write' || entryMode === 'upload') && !okConfirm) {
      toast(isAr ? 'راجع البيانات المستخرجة ثم اضغط «تأكيد الحالة وبدء التحليل»' : 'Review the extracted case, then click Confirm Case & Start Analysis.', 'error');
      return;
    }
    if (!form.age || !form.gender || !form.chiefComplaint?.trim()) {
      toast(isAr ? 'الرجاء إدخال العمر والجنس والشكوى الرئيسية على الأقل' : 'Please provide age, gender and chief complaint.', 'error');
      return;
    }
    setLoading(true);
    try {
      const payload = {
        age: Number(form.age), gender: form.gender, height: form.height ? Number(form.height) : undefined,
        weight: form.weight ? Number(form.weight) : undefined, chiefComplaint: form.chiefComplaint, duration: form.duration,
        presentIllness: form.presentIllness, history: form.history, medications: form.medications, allergies: form.allergies,
        familyHistory: form.familyHistory, surgicalHistory: form.surgicalHistory, physicalExam: form.physicalExam,
        smoking: form.smoking, pregnancy: !!form.pregnancy,
        gestationalAge: form.gestationalAge ? Number(form.gestationalAge) : undefined,
        ageMonths: form.ageMonths ? Number(form.ageMonths) : undefined,
        breastfeeding: !!form.breastfeeding,
        vitals: form.vitals || {}, symptoms: form.symptoms, labs: form.labs, imaging: form.imaging, imagingNote: form.imagingNote,
        sourceNarrative: caseDraft || parsed?.sourceText || '',
        lang,
      };
      const res = await analyzeCase(payload);
      setReport(res.report);
      setRemaining(res.remaining);
      toast(isAr ? 'تم تحليل الحالة' : 'Case analyzed', 'success');
      if (user && res.savedId) toast(isAr ? 'تم حفظ التحليل في سجلّك' : 'Saved to your history', 'success');
    } catch (e: any) {
      toast(e.message || (isAr ? 'تعذّر التحليل' : 'Analysis failed'), 'error');
    } finally { setLoading(false); }
  };

  const loadHistory = async () => {
    if (!user) { toast(isAr ? 'سجّل الدخول لعرض سجل التحليلات' : 'Log in to view your analysis history', 'error'); return; }
    setShowHistory(true); setHistLoading(true);
    try { setHistList(await getAiHistory()); } catch (e: any) { toast(e.message, 'error'); }
    finally { setHistLoading(false); }
  };
  const openSaved = async (id: number) => {
    try {
      const a = await getAiAnalysis(id);
      if (a?.report) { setReport(a.report); setShowHistory(false); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    } catch (e: any) { toast(e.message, 'error'); }
  };

  const saveCurrent = async () => {
    if (!report) return;
    if (!user) { toast(isAr ? 'سجّل الدخول لحفظ التحليل' : 'Log in to save this analysis', 'error'); return; }
    toast(isAr ? 'يتم حفظ التحليل تلقائياً عند الضغط على «تحليل الحالة»' : 'Analysis is saved automatically when you click Analyze (for logged-in users)', 'success');
  };

  const vitalsArr = useMemo(() => VITALS, []);

  return (
    <div className="min-h-screen bg-[#f7f7f5] dark:bg-navy">
      <Navbar />
      <div className="mx-auto max-w-6xl px-5 py-12 md:py-16">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">{isAr ? 'تحليل حالة' : 'Case analysis'}</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-slate-900 dark:text-white">{isAr ? 'اكتب أو أضف حالتك' : 'Write or add your case'}</h1>
            <p className="mt-2 max-w-xl text-sm leading-7 text-slate-500">
              {isAr
                ? 'تعليمي فقط. تشخيص عامل واحد من النص الذي تقدّمه — دون اختلاق بيانات.'
                : 'Educational only. One working diagnosis from the case you provide — nothing is invented.'}
            </p>
          </div>
          <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-white p-1 text-xs dark:border-white/10 dark:bg-white/5">
            <button onClick={() => setLang('en')} className={`rounded-full px-3 py-1 ${!isAr ? 'bg-slate-900 text-white' : 'text-slate-500'}`}>EN</button>
            <button onClick={() => setLang('ar')} className={`rounded-full px-3 py-1 ${isAr ? 'bg-slate-900 text-white' : 'text-slate-500'}`}>ع</button>
          </div>
        </div>

        <div className="mb-8 grid gap-4 md:grid-cols-3">
          <button type="button" onClick={() => setEntryMode('write')} className={`rounded-2xl border bg-white p-5 text-start dark:bg-white/5 ${entryMode === 'write' ? 'border-slate-900 dark:border-white' : 'border-slate-200 dark:border-white/10'}`}>
            <div className="flex items-center gap-2 font-semibold text-slate-900 dark:text-white"><PenLine className="h-4 w-4" /> {isAr ? 'اكتب حالتي' : 'Write My Case'}</div>
            <p className="mt-2 text-sm leading-6 text-slate-500">{isAr ? 'الصق القصة السريرية كما هي. لا حاجة لكل الحقول.' : 'Paste the narrative. You do not need every field.'}</p>
          </button>
          <button type="button" onClick={() => setEntryMode('upload')} className={`rounded-2xl border bg-white p-5 text-start dark:bg-white/5 ${entryMode === 'upload' ? 'border-slate-900 dark:border-white' : 'border-slate-200 dark:border-white/10'}`}>
            <div className="flex items-center gap-2 font-semibold text-slate-900 dark:text-white"><FileUp className="h-4 w-4" /> {isAr ? 'أضف حالتي' : 'Add My Case'}</div>
            <p className="mt-2 text-sm leading-6 text-slate-500">{isAr ? 'PDF أو DOCX أو صورة أو نص. نستخرج المكتوب فقط.' : 'PDF, DOCX, image, or text. Only what is written is used.'}</p>
          </button>
          <button type="button" onClick={() => setEntryMode('form')} className={`rounded-2xl border bg-white p-5 text-start dark:bg-white/5 ${entryMode === 'form' ? 'border-slate-900 dark:border-white' : 'border-slate-200 dark:border-white/10'}`}>
            <div className="flex items-center gap-2 font-semibold text-slate-900 dark:text-white"><Activity className="h-4 w-4" /> {isAr ? 'نموذج منظم' : 'Structured form'}</div>
            <p className="mt-2 text-sm leading-6 text-slate-500">{isAr ? 'أدخل الحقول يدوياً إن فضّلت ذلك.' : 'Fill fields manually if you prefer.'}</p>
          </button>
        </div>

        {(entryMode === 'write' || entryMode === 'upload') && (
          <div className="mb-6 space-y-4 rounded-3xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
            {entryMode === 'write' && (
              <>
                <h2 className="font-extrabold text-slate-900 dark:text-white">{isAr ? 'اكتب أو الصق الحالة كاملة' : 'Write or paste the complete case'}</h2>
                <textarea
                  className={`${input} min-h-52 resize-y font-medium leading-7`}
                  value={caseDraft}
                  onChange={(e) => { setCaseDraft(e.target.value); setConfirmedReady(false); }}
                  placeholder={isAr ? 'مثال: ذكر عمره 58 سنة حُجز بضيق نفس منذ يومين...' : 'Example: 58-year-old male admitted with...'}
                />
                <button type="button" disabled={extracting} onClick={() => extractFromText(caseDraft)} className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white disabled:opacity-60 dark:bg-white dark:text-slate-900">
                  {extracting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  {isAr ? 'استخرج المعلومات' : 'Extract information'}
                </button>
              </>
            )}
            {entryMode === 'upload' && (
              <>
                <h2 className="font-extrabold text-slate-900 dark:text-white">{isAr ? 'أضف ملف الحالة' : 'Add an existing case file'}</h2>
                <label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-300 px-6 py-10 text-center dark:border-white/15">
                  <FileUp className="mb-2 h-8 w-8 text-primary" />
                  <span className="text-sm font-bold">{isAr ? 'PDF / DOC / DOCX / صورة / TXT' : 'PDF / DOC / DOCX / image / TXT'}</span>
                  <span className="mt-1 text-xs text-slate-400">{isAr ? 'الصور الممسوحة تحتاج لصق النص — لا نختلق قراءة.' : 'Scanned images need pasted text — we never invent a reading.'}</span>
                  <input type="file" accept=".pdf,.doc,.docx,.txt,image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) extractFromFile(f); e.target.value = ''; }} />
                </label>
                <p className="text-xs text-slate-400">{isAr ? 'أو الصق النص هنا إن تعذّر قراءة الملف:' : 'Or paste the text here if the file cannot be read:'}</p>
                <textarea className={`${input} min-h-28 resize-y`} value={caseDraft} onChange={(e) => setCaseDraft(e.target.value)} />
                <button type="button" disabled={extracting} onClick={() => extractFromText(caseDraft)} className="text-sm font-bold text-primary">{isAr ? 'استخرج من النص الملصوق' : 'Extract from pasted text'}</button>
              </>
            )}

            {parsed && (
              <div className="space-y-4 border-t border-slate-100 pt-4 dark:border-white/10">
                <h3 className="font-extrabold">{isAr ? 'ملخص مستخرج — راجع قبل التحليل' : 'Extracted summary — review before analysis'}</h3>
                <p className="text-xs text-slate-500">{isAr ? 'مصدر بيانات المريض هو نصّك فقط. المصادر الخارجية للمعرفة السريرية لاحقاً.' : 'The written/uploaded case is the only source of patient data. External sources are used later for clinical knowledge only.'}</p>
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="rounded-xl border border-emerald-200 bg-emerald-50/80 p-3 dark:border-emerald-500/20 dark:bg-emerald-500/10">
                    <div className="mb-2 text-xs font-extrabold text-emerald-700 dark:text-emerald-300">✓ {isAr ? 'مؤكّد' : 'Confirmed'} ({parsed.confirmed.length})</div>
                    <ul className="space-y-1 text-xs">{parsed.confirmed.map((c) => <li key={c.key}><b>{c.label}:</b> {c.value}</li>)}</ul>
                  </div>
                  <div className="rounded-xl border border-amber-200 bg-amber-50/80 p-3 dark:border-amber-500/20 dark:bg-amber-500/10">
                    <div className="mb-2 text-xs font-extrabold text-amber-800 dark:text-amber-200">{isAr ? 'ناقص' : 'Missing'} ({parsed.missing.length})</div>
                    <ul className="space-y-1 text-xs">{parsed.missing.length ? parsed.missing.map((c) => <li key={c.key}>{c.label}</li>) : <li>—</li>}</ul>
                  </div>
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/5">
                    <div className="mb-2 text-xs font-extrabold text-slate-600 dark:text-slate-300">{isAr ? 'غير واضح' : 'Unclear'} ({parsed.unclear.length})</div>
                    <ul className="space-y-1 text-xs">{parsed.unclear.length ? parsed.unclear.map((c) => <li key={c.key}><b>{c.label}:</b> {c.value || '—'}</li>) : <li>—</li>}</ul>
                  </div>
                </div>
                <p className="text-xs text-slate-400">{isAr ? 'عدّل أي حقل في النموذج بالأسفل ثم أكّد.' : 'Edit any field in the form below, then confirm.'}</p>
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => { setConfirmedReady(true); void analyze({ confirmed: true }); }}
                  className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-3 text-sm font-extrabold text-white shadow-lg disabled:opacity-60"
                >
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />} {isAr ? 'تأكيد الحالة وبدء التحليل' : 'Confirm Case & Start Analysis'}
                </button>
                {confirmedReady && (
                  <p className="text-xs font-bold text-emerald-600">{isAr ? 'مؤكَّد. اضغط «تحليل الحالة» للمتابعة.' : 'Confirmed. Click Analyze Case to continue.'}</p>
                )}
              </div>
            )}
          </div>
        )}

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Form */}
          <div className="space-y-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
              <h2 className="mb-4 flex items-center gap-2 font-bold text-slate-900 dark:text-white"><Activity className="h-5 w-5 text-primary" /> {isAr ? 'بيانات المريض (قابلة للتعديل)' : 'Patient data (editable)'}</h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                <div className="col-span-1"><label className={label}>{isAr ? 'العمر (سنوات) *' : 'Age (years) *'}</label><input type="number" className={input} value={form.age || ''} onChange={(e) => set({ age: e.target.value })} placeholder={isAr ? 'بالسنوات' : 'years'} /></div>
                {(Number(form.age) < 2 || form.age === '0' || form.age === 0) && (
                  <div className="col-span-1"><label className={label}>{isAr ? 'العمر بالأشهر (رضيع)' : 'Age in months (infant)'}</label><input type="number" className={input} value={form.ageMonths || ''} onChange={(e) => set({ ageMonths: e.target.value })} placeholder={isAr ? 'مثال: 8' : 'e.g. 8'} /></div>
                )}
                <div className="col-span-1"><label className={label}>{isAr ? 'الجنس *' : 'Sex *'}</label><select className={input} value={form.gender} onChange={(e) => set({ gender: e.target.value })}><option value="">—</option><option value="male">{isAr ? 'ذكر' : 'Male'}</option><option value="female">{isAr ? 'أنثى' : 'Female'}</option><option value="other">{isAr ? 'آخر' : 'Other'}</option></select></div>
                <div className="col-span-1"><label className={label}>{isAr ? 'الحمل' : 'Pregnancy'}</label><select className={input} value={form.pregnancy ? 'yes' : 'no'} onChange={(e) => set({ pregnancy: e.target.value === 'yes' })}><option value="no">{isAr ? 'لا' : 'No'}</option><option value="yes">{isAr ? 'نعم' : 'Yes'}</option></select></div>
                {form.pregnancy && <div><label className={label}>{isAr ? 'عمر الحمل (أسابيع)' : 'Gestational age (weeks)'}</label><input type="number" className={input} value={form.gestationalAge || ''} onChange={(e) => set({ gestationalAge: e.target.value })} /></div>}
                <div><label className={label}>{isAr ? 'الرضاعة' : 'Breastfeeding'}</label><select className={input} value={form.breastfeeding ? 'yes' : 'no'} onChange={(e) => set({ breastfeeding: e.target.value === 'yes' })}><option value="no">{isAr ? 'لا' : 'No'}</option><option value="yes">{isAr ? 'نعم' : 'Yes'}</option></select></div>
                <div><label className={label}>{isAr ? 'الطول (سم)' : 'Height (cm)'}</label><input type="number" className={input} value={form.height || ''} onChange={(e) => set({ height: e.target.value })} /></div>
                <div><label className={label}>{isAr ? 'الوزن (كجم) *' : 'Weight (kg) *'}</label><input type="number" className={input} value={form.weight || ''} onChange={(e) => set({ weight: e.target.value })} /></div>
                <div><label className={label}>{isAr ? 'التدخين' : 'Smoking'}</label><select className={input} value={form.smoking} onChange={(e) => set({ smoking: e.target.value })}><option value="">—</option><option value="never">{isAr ? 'أبداً' : 'Never'}</option><option value="current">{isAr ? 'حالي' : 'Current'}</option><option value="former">{isAr ? 'سابق' : 'Former'}</option></select></div>
              </div>
              <div className="mt-3"><label className={label}>{isAr ? 'الشكوى الرئيسية *' : 'Chief Complaint *'}</label><input className={input} value={form.chiefComplaint || ''} onChange={(e) => set({ chiefComplaint: e.target.value })} placeholder={isAr ? 'مثال: ألم صدر وحمى' : 'e.g. chest pain and fever'} /></div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div><label className={label}>{isAr ? 'مدة الأعراض' : 'Duration of Symptoms'}</label><input className={input} value={form.duration || ''} onChange={(e) => set({ duration: e.target.value })} placeholder={isAr ? 'مثال: 3 أيام' : 'e.g. 3 days'} /></div>
                <div><label className={label}>{isAr ? 'تاريخ المرض الحالي' : 'History of present illness'}</label><input className={input} value={form.presentIllness || ''} onChange={(e) => set({ presentIllness: e.target.value })} /></div>
              </div>
              <div className="mt-3"><label className={label}>{isAr ? 'الفحص السريري / التقييم الجسدي' : 'Physical assessment'}</label><textarea className={`${input} min-h-20 resize-y`} value={form.physicalExam || ''} onChange={(e) => set({ physicalExam: e.target.value })} placeholder={isAr ? 'مثال: خراخر قاعدية يمنى، وذمة كاحل' : 'e.g. right basal crackles, ankle edema'} /></div>
            </div>

            <Collapsible title="Vital Signs" icon={Activity} defaultOpen>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {vitalsArr.map((v) => (
                  <div key={v.k}><label className={label}>{v.ar} ({v.unit})</label><input type="number" step="0.1" className={input} placeholder={v.ph} value={form.vitals?.[v.k] || ''} onChange={(e) => set({ vitals: { ...(form.vitals || {}), [v.k]: e.target.value } })} /></div>
                ))}
                <div><label className={label}>{isAr ? 'درجة الألم 0–10' : 'Pain score 0–10'}</label><input type="number" min={0} max={10} className={input} value={form.vitals?.pain || ''} onChange={(e) => set({ vitals: { ...(form.vitals || {}), pain: e.target.value } })} /></div>
                <div><label className={label}>{isAr ? 'مستوى الوعي' : 'Level of consciousness'}</label><input className={input} value={form.vitals?.loc || ''} onChange={(e) => set({ vitals: { ...(form.vitals || {}), loc: e.target.value } })} placeholder={isAr ? 'صاحٍ / مشوش / غير مستجيب' : 'alert / confused / unresponsive'} /></div>
              </div>
            </Collapsible>

            <Collapsible title="Symptoms" icon={Sparkles} defaultOpen>
              <SymptomPicker value={form.symptoms || []} onChange={(v) => set({ symptoms: v })} />
            </Collapsible>

            <Collapsible title="Laboratory Results (optional)" icon={FlaskIcon}>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {LABS.map((l) => (
                  <div key={l.k}><label className={label}>{l.ar} {l.unit && `(${l.unit})`}</label><input type="number" step="0.01" className={input} value={form.labs?.[l.k]?.value || ''} onChange={(e) => set({ labs: { ...(form.labs || {}), [l.k]: { value: e.target.value, unit: l.unit } } })} /></div>
                ))}
              </div>
            </Collapsible>

            <Collapsible title="Imaging (optional)" icon={ScanIcon}>
              <div className="flex flex-wrap gap-2">
                {IMAGING.map((im) => {
                  const on = (form.imaging || []).includes(im);
                  return <button key={im} type="button" onClick={() => set({ imaging: on ? form.imaging.filter((x: string) => x !== im) : [...(form.imaging || []), im] })} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${on ? 'bg-primary text-white' : 'border border-slate-300 dark:border-white/10'}`}>{im}</button>;
                })}
              </div>
              <div className="mt-2"><label className={label}>Findings description</label><input className={input} value={form.imagingNote || ''} onChange={(e) => set({ imagingNote: e.target.value })} placeholder="e.g. left pleural effusion" /></div>
            </Collapsible>

            <Collapsible title="Medical & Family History" icon={HistoryIcon}>
              <label className={label}>Past medical history</label>
              <div className="flex flex-wrap gap-2">
                {HISTORY.map((h) => {
                  const on = (form.history || []).includes(h);
                  return <button key={h} type="button" onClick={() => set({ history: on ? form.history.filter((x: string) => x !== h) : [...(form.history || []), h] })} className={`rounded-full px-3 py-1.5 text-xs font-semibold transition ${on ? 'bg-secondary text-white' : 'border border-slate-300 dark:border-white/10'}`}>{h}</button>;
                })}
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <div><label className={label}>{isAr ? 'التاريخ الجراحي' : 'Surgical history'}</label><textarea className={`${input} min-h-16 resize-y`} value={form.surgicalHistory || ''} onChange={(e) => set({ surgicalHistory: e.target.value })} /></div>
                <div><label className={label}>{isAr ? 'الأدوية الحالية' : 'Current Medications'}</label><textarea className={`${input} min-h-16 resize-y`} value={form.medications || ''} onChange={(e) => set({ medications: e.target.value })} /></div>
                <div><label className={label}>{isAr ? 'الحساسية الدوائية' : 'Drug Allergies'}</label><textarea className={`${input} min-h-16 resize-y`} value={form.allergies || ''} onChange={(e) => set({ allergies: e.target.value })} /></div>
                <div><label className={label}>{isAr ? 'التاريخ العائلي' : 'Family History'}</label><input className={input} value={form.familyHistory || ''} onChange={(e) => set({ familyHistory: e.target.value })} /></div>
              </div>
            </Collapsible>

            <div className="flex flex-wrap items-center gap-3">
              <button onClick={analyze} disabled={loading} className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-l from-primary to-primary-600 px-6 py-3 text-sm font-bold text-white shadow-lg shadow-primary/30 disabled:opacity-60">
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <BrainCircuit className="h-4 w-4" />} Analyze Case
              </button>
              {remaining != null && <span className="text-xs text-slate-400">{isAr ? `الطلبات المتبقية هذا الساعة: ${remaining}` : `Requests left this hour: ${remaining}`}</span>}
              <button onClick={loadHistory} className="inline-flex items-center gap-1 rounded-xl border border-slate-300 px-4 py-3 text-sm font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><HistoryIcon className="h-4 w-4" /> {isAr ? 'سجل التحليلات' : 'History'}</button>
              {report && user && <button onClick={saveCurrent} className="inline-flex items-center gap-1 rounded-xl border border-primary px-4 py-3 text-sm font-semibold text-primary hover:bg-primary/10"><Save className="h-4 w-4" /> {isAr ? 'حفظ' : 'Save'}</button>}
            </div>
          </div>

          {/* Results */}
          <div className="lg:sticky lg:top-4 lg:self-start">
            {report ? (
              <ReportView report={report} lang={lang} />
            ) : (
              <div className="flex min-h-[400px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 p-10 text-center dark:border-white/10">
                <BrainCircuit className="h-14 w-14 text-slate-300 dark:text-slate-600" />
                <p className="mt-3 text-sm text-slate-400">{isAr ? 'أدخل الملف السريري الكامل ثم اضغط «تحليل الحالة» للحصول على تشخيص عامل واحد وخطة تمريض مبنية على الأدلة.' : 'Enter the full clinical profile, then click Analyze Case for one working diagnosis and an evidence-based nursing plan.'}</p>
                <p className="mt-1 text-xs text-slate-300">{isAr ? 'سيتم حفظ التحليل تلقائياً في سجلك إن كنت مسجّلاً للدخول.' : 'Analyses are saved to your history automatically if you are logged in.'}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* History modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowHistory(false)}>
          <div className="max-h-[80vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-5 dark:bg-navy-800" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between"><h3 className="font-bold text-slate-900 dark:text-white">{isAr ? 'سجل التحليلات' : 'Analysis History'}</h3><button onClick={() => setShowHistory(false)} className="text-slate-400 hover:text-slate-600">✕</button></div>
            {histLoading ? <p className="text-sm text-slate-400">{isAr ? 'جارٍ التحميل…' : 'Loading…'}</p> : histList.length === 0 ? <p className="text-sm text-slate-400">{isAr ? 'لا توجد تحليلات محفوظة بعد.' : 'No saved analyses yet.'}</p> : (
              <ul className="space-y-2">
                {histList.map((h) => (
                  <li key={h.id}><button onClick={() => openSaved(h.id)} className="flex w-full items-center justify-between rounded-xl border border-slate-200 p-3 text-right text-sm hover:border-primary dark:border-white/10"><span><span className="font-semibold text-slate-800 dark:text-slate-100">{h.title}</span><br /><span className="text-xs text-slate-400">{h.top_diagnosis} · {new Date(h.created_at).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</span></span><Search className="h-4 w-4 text-primary" /></button></li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

function FlaskIcon({ className }: { className?: string }) { return <span className={className}><FlaskConicalInline /></span>; }
function FlaskConicalInline() { return <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-primary"><path d="M9 3h6M10 3v6.5L4.5 19a1.5 1.5 0 0 0 1.3 2.2h13.4A1.5 1.5 0 0 0 19.5 19L14 9.5V3" /></svg>; }
function ScanIcon({ className }: { className?: string }) { return <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-primary"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2" /></svg>; }

import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle,
  BookOpen,
  Check,
  ClipboardList,
  Copy,
  Download,
  Edit3,
  Eye,
  EyeOff,
  Globe,
  Heart,
  Link as LinkIcon,
  Loader2,
  Lock,
  Printer,
  RefreshCw,
  Save,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useToast } from '../components/Toast';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import supabase from '../lib/supabase';

type Lang = 'en' | 'ar';

const i18n = {
  pageTitle: { en: 'AI Care Plan Generator', ar: 'مولِّد خطط الرعاية بالذكاء الاصطناعي' },
  pageSubtitle: {
    en: 'Generate a professional nursing care plan with current NANDA-I terminology, evidence-based interventions, and trusted references.',
    ar: 'ولّد خطة رعاية تمريضية احترافية بمصطلحات NANDA-I الحديثة وتدخلات قائمة على الأدلة ومراجع موثوقة.',
  },
  caseForm: { en: 'Patient Case', ar: 'حالة المريض' },
  langToggle: { en: 'العربية', ar: 'English' },
  clear: { en: 'Clear Form', ar: 'مسح النموذج' },
  generate: { en: 'Generate Nursing Care Plan', ar: 'إنشاء خطة الرعاية التمريضية' },
  generating: { en: 'Generating care plan…', ar: 'جاري إنشاء خطة الرعاية…' },
  editCase: { en: 'Edit Case', ar: 'تعديل الحالة' },
  regenerate: { en: 'Regenerate', ar: 'إعادة التوليد' },
  save: { en: 'Save to My Care Plans', ar: 'حفظ في خطط الرعاية' },
  saved: { en: 'Saved', ar: 'تم الحفظ' },
  copy: { en: 'Copy', ar: 'نسخ' },
  copied: { en: 'Copied!', ar: 'تم النسخ!' },
  pdf: { en: 'Download PDF', ar: 'تنزيل PDF' },
  print: { en: 'Print', ar: 'طباعة' },
  share: { en: 'Share', ar: 'مشاركة' },
  shared: { en: 'Link copied!', ar: 'تم نسخ الرابط!' },
  editPlan: { en: 'Edit Plan', ar: 'تعديل الخطة' },
  exitEdit: { en: 'Done Editing', ar: 'تم التعديل' },
  editPlanHint: {
    en: 'You can edit goals, interventions, or evaluations. Changes are saved locally.',
    ar: 'يمكنك تعديل الأهداف والتدخلات والتقييم. تُحفظ التغييرات محليًا.',
  },
  history: { en: 'My Care Plans', ar: 'خطط الرعاية' },
  noHistory: { en: 'No saved care plans yet.', ar: 'لا توجد خطط محفوظة بعد.' },
  load: { en: 'Open', ar: 'فتح' },
  delete: { en: 'Delete', ar: 'حذف' },
  references: { en: 'Trusted References', ar: 'المراجع الموثوقة' },
  priorityRationale: { en: 'Priority Rationale', ar: 'سبب الأولوية' },
  fieldAge: { en: 'Age', ar: 'العمر' },
  fieldGender: { en: 'Gender', ar: 'الجنس' },
  fieldDx: { en: 'Medical Diagnosis', ar: 'التشخيص الطبي' },
  fieldComplaint: { en: 'Chief Complaint', ar: 'الشكوى الرئيسية' },
  fieldHPI: { en: 'Present Illness', ar: 'المرض الحالي' },
  fieldHistory: { en: 'Medical/Surgical History', ar: 'التاريخ الطبي/الجراحي' },
  fieldVitals: { en: 'Vital Signs', ar: 'العلامات الحيوية' },
  fieldVitalsHint: { en: 'HR, RR, BP, SpO2, Temp', ar: 'نبض، تنفس، ضغط، تشبع، حرارة' },
  fieldExam: { en: 'Physical Assessment', ar: 'التقييم الجسدي' },
  fieldSymptoms: { en: 'Symptoms', ar: 'الأعراض' },
  fieldLabs: { en: 'Laboratory and Imaging Results', ar: 'نتائج المختبر والأشعة' },
  fieldMeds: { en: 'Medications', ar: 'الأدوية' },
  fieldAllergies: { en: 'Allergies', ar: 'الحساسية' },
  fieldNursing: { en: 'Nursing Assessment Findings', ar: 'نتائج تقييم التمريض' },
  fieldPaste: { en: 'Complete Case (paste here)', ar: 'الحالة كاملة (الصق هنا)' },
  fieldProcedures: { en: 'Procedures / Devices', ar: 'الإجراءات / الأجهزة' },
  colDiagnosis: { en: 'Nursing Diagnosis (NANDA-I)', ar: 'تشخيص تمريضي (NANDA-I)' },
  colGoal: { en: 'Nursing Goal', ar: 'الهدف التمريضي' },
  colInterventions: { en: 'Nursing Interventions', ar: 'التدخلات التمريضية' },
  colEvaluation: { en: 'Evaluation', ar: 'التقييم' },
  met: { en: 'Goal Met', ar: 'تحقق' },
  partial: { en: 'Partially Met', ar: 'تحقق جزئيًا' },
  not: { en: 'Not Met', ar: 'لم يتحقق' },
  evidence: { en: 'Matched from case', ar: 'مطابقة من الحالة' },
  noResults: { en: 'Provide a diagnosis or paste a case to generate a plan.', ar: 'أدخل تشخيصًا أو الصق حالة لإنشاء خطة.' },
  loginToSave: { en: 'Sign in to save this care plan to your account.', ar: 'سجّل الدخول لحفظ خطة الرعاية في حسابك.' },
  disclaimer: {
    en: 'AI-generated nursing care plans are for educational and clinical-support purposes only. Always verify diagnoses and interventions using current NANDA-I terminology, clinical guidelines, institutional policies, and professional nursing judgment.',
    ar: 'خطط الرعاية المولدة بالذكاء الاصطناعي لأغراض تعليمية ودعم سريري فقط. تحقق دائمًا من التشخيصات والتدخلات باستخدام مصطلحات NANDA-I الحالية والإرشادات السريرية وسياسات المؤسسة والحكم التمريضي المهني.',
  },
};

const labels = {
  title: { en: 'AI Care Plan Generator', ar: 'مولِّد خطط الرعاية' },
  age: { en: 'Age', ar: 'العمر' },
  gender: { en: 'Gender', ar: 'الجنس' },
  male: { en: 'Male', ar: 'ذكر' },
  female: { en: 'Female', ar: 'أنثى' },
  dx: { en: 'Medical Diagnosis', ar: 'التشخيص الطبي' },
  cc: { en: 'Chief Complaint', ar: 'الشكوى الرئيسية' },
  hpi: { en: 'Present Illness', ar: 'المرض الحالي' },
  history: { en: 'Medical / Surgical History', ar: 'التاريخ الطبي / الجراحي' },
  vitals: { en: 'Vital Signs', ar: 'العلامات الحيوية' },
  exam: { en: 'Physical Assessment', ar: 'الفحص السريري' },
  symptoms: { en: 'Symptoms', ar: 'الأعراض' },
  labs: { en: 'Lab & Imaging', ar: 'المختبر والأشعة' },
  meds: { en: 'Medications', ar: 'الأدوية' },
  allergies: { en: 'Allergies', ar: 'الحساسية' },
  nursing: { en: 'Nursing Assessment', ar: 'تقييم التمريض' },
  paste: { en: 'Complete Case (paste)', ar: 'الحالة كاملة' },
  procedures: { en: 'Procedures / Devices', ar: 'الإجراءات / الأجهزة' },
};

type FormState = {
  age: string;
  gender: string;
  diagnosis: string;
  complaint: string;
  presentIllness: string;
  history: string;
  vitals: string;
  exam: string;
  symptoms: string;
  labs: string;
  meds: string;
  allergies: string;
  nursing: string;
  procedures: string;
  casePaste: string;
};

const EMPTY_FORM: FormState = {
  age: '', gender: '', diagnosis: '', complaint: '', presentIllness: '',
  history: '', vitals: '', exam: '', symptoms: '', labs: '', meds: '',
  allergies: '', nursing: '', procedures: '', casePaste: '',
};

interface SavedPlan { id: number; title: string; lang: Lang; created_at: string; }

export default function CarePlanFull() {
  const [lang, setLang] = useState<Lang>(() => (localStorage.getItem('cp-lang') as Lang) || 'en');
  const [form, setForm] = useState<FormState>(() => {
    try { const s = localStorage.getItem('cp-form'); return s ? JSON.parse(s) : EMPTY_FORM; } catch { return EMPTY_FORM; }
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [history, setHistory] = useState<SavedPlan[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [editingPlan, setEditingPlan] = useState(false);
  const [showReferences, setShowReferences] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [savedPlanId, setSavedPlanId] = useState<number | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const { dark } = useTheme();
  const printRef = useRef<HTMLDivElement>(null);
  const isAr = lang === 'ar';

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    try { localStorage.setItem('cp-lang', lang); } catch { /* ignore */ }
  }, [lang]);

  useEffect(() => {
    try { localStorage.setItem('cp-form', JSON.stringify(form)); } catch { /* ignore */ }
  }, [form]);

  useEffect(() => {
    if (user) refreshHistory();
  }, [user]);

  const set = (k: keyof FormState) => (e: any) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const clearForm = () => {
    setForm(EMPTY_FORM);
    setResult(null);
    setSavedPlanId(null);
    try { localStorage.removeItem('cp-form'); } catch { /* ignore */ }
  };

  const refreshHistory = async () => {
    if (!user) return;
    setHistoryLoading(true);
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      const res = await fetch('/api/ai-careplan-history', { headers: { Authorization: `Bearer ${token}` } });
      const list = await res.json();
      setHistory(Array.isArray(list) ? list : []);
    } catch { /* ignore */ }
    setHistoryLoading(false);
  };

  const submit = async (e?: any) => {
    if (e) e.preventDefault();
    if (!form.diagnosis && !form.casePaste) {
      toast(isAr ? 'الرجاء إدخال تشخيص أو لصق الحالة.' : 'Please provide a diagnosis or paste the case.', 'error');
      return;
    }
    setLoading(true);
    setSavedPlanId(null);
    try {
      const payload = {
        lang,
        age: form.age,
        gender: form.gender,
        diagnosis: form.diagnosis,
        complaint: form.complaint,
        presentIllness: form.presentIllness,
        history: form.history,
        vitals: form.vitals,
        assessment: form.exam,
        symptoms: form.symptoms.split(/[,\n]/).map((x) => x.trim()).filter(Boolean),
        labs: form.labs,
        meds: form.meds,
        allergies: form.allergies,
        nursing: form.nursing,
        procedures: form.procedures.split(/[,\n]/).map((x) => x.trim()).filter(Boolean),
        casePaste: [form.casePaste, form.complaint, form.presentIllness, form.history, form.vitals, form.exam, form.labs, form.meds, form.nursing].filter(Boolean).join('\n'),
      };
      const res = await fetch('/api/ai-careplan-full', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Request failed');
      setResult(data);
      toast(isAr ? 'تم إنشاء الخطة' : 'Care plan generated', 'success');
    } catch (err: any) {
      toast(err.message || 'Failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const copyPlan = () => {
    if (!result) return;
    const text = formatPlanText(result, form);
    navigator.clipboard.writeText(text).then(() => toast(isAr ? i18n.copied.ar : i18n.copied.en, 'success'));
  };

  const shareLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => toast(isAr ? i18n.shared.ar : i18n.shared.en, 'success'));
  };

  const downloadPdf = () => {
    if (!printRef.current) return;
    const w = window.open('', '_blank', 'width=900,height=800');
    if (!w) return;
    const css = `
      body { font-family: ${isAr ? "'Cairo','Segoe UI',sans-serif" : "'Inter',sans-serif"}; padding: 32px; color: #111; direction: ${isAr ? 'rtl' : 'ltr'}; }
      h1, h2, h3 { color: #0c4a6e; }
      table { width: 100%; border-collapse: collapse; margin-top: 12px; }
      th, td { border: 1px solid #94a3b8; padding: 10px; vertical-align: top; text-align: ${isAr ? 'right' : 'left'}; }
      th { background: #f1f5f9; }
      .refs a { color: #1d4ed8; text-decoration: none; }
      .disclaimer { background: #fef3c7; border: 1px solid #fcd34d; padding: 12px; border-radius: 8px; margin-top: 24px; }
      @media print { .no-print { display: none; } }
    `;
    const inner = printRef.current.innerHTML;
    w.document.write(`<!doctype html><html><head><meta charset="utf-8"/><title>${isAr ? 'خطة الرعاية' : 'Care Plan'}</title><style>${css}</style></head><body>${inner}</body></html>`);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); }, 300);
  };

  const savePlan = async () => {
    if (!user) {
      toast(isAr ? i18n.loginToSave.ar : i18n.loginToSave.en, 'error');
      return;
    }
    if (!result) return;
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      const res = await fetch('/api/ai-careplan-history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          title: form.diagnosis ? `${form.diagnosis} – ${form.age || '—'}y, ${form.gender || '—'}` : (isAr ? 'خطة رعاية' : 'Care Plan'),
          caseData: form,
          plan: result.plan,
          lang,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Save failed');
      setSavedPlanId(data.id);
      toast(isAr ? i18n.saved.ar : i18n.saved.en, 'success');
      refreshHistory();
    } catch (err: any) {
      toast(err.message || 'Failed to save', 'error');
    }
  };

  const loadPlan = async (id: number) => {
    if (!user) return;
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      const res = await fetch(`/api/ai-careplan-history?id=${id}`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Load failed');
      setForm(data.case_data || EMPTY_FORM);
      setResult({ plan: data.plan, disclaimer: result?.disclaimer, lang: data.lang });
      setLang(data.lang || 'en');
      setSavedPlanId(data.id);
      toast(isAr ? 'تم التحميل' : 'Loaded', 'success');
    } catch (err: any) {
      toast(err.message || 'Failed to load', 'error');
    }
  };

  const deletePlan = async (id: number) => {
    if (!user) return;
    try {
      const { data: sess } = await supabase.auth.getSession();
      const token = sess.session?.access_token;
      const res = await fetch(`/api/ai-careplan-history?id=${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) throw new Error('Delete failed');
      setHistory((h) => h.filter((p) => p.id !== id));
      if (savedPlanId === id) setSavedPlanId(null);
      toast(isAr ? 'تم الحذف' : 'Deleted', 'success');
    } catch (err: any) {
      toast(err.message || 'Failed to delete', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-white">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-slate-200/70 py-12 dark:border-white/10">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -left-20 top-0 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute -right-20 top-20 h-72 w-72 rounded-full bg-cyan-400/20 blur-3xl" />
        </div>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                <Sparkles className="h-3.5 w-3.5" /> {isAr ? 'ميزة جديدة' : 'New Feature'}
              </div>
              <h1 className="text-3xl font-extrabold sm:text-4xl">
                {isAr ? i18n.pageTitle.ar : i18n.pageTitle.en}
              </h1>
              <p className="mt-3 text-base text-slate-600 dark:text-slate-300 sm:text-lg">
                {isAr ? i18n.pageSubtitle.ar : i18n.pageSubtitle.en}
              </p>
            </motion.div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowHistory((v) => !v)}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white/70 px-4 py-2 text-sm font-semibold text-slate-700 backdrop-blur transition hover:border-primary hover:text-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
              >
                <BookOpen className="h-4 w-4" /> {isAr ? i18n.history.ar : i18n.history.en}
              </button>
              <button
                onClick={() => setLang((l) => (l === 'en' ? 'ar' : 'en'))}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white/70 px-4 py-2 text-sm font-semibold text-slate-700 backdrop-blur transition hover:border-primary hover:text-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-200"
              >
                <Globe className="h-4 w-4" /> {isAr ? i18n.langToggle.ar : i18n.langToggle.en}
              </button>
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-amber-300/40 bg-amber-50/70 p-4 text-sm text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
            <div className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <p>{isAr ? i18n.disclaimer.ar : i18n.disclaimer.en}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main grid */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid gap-6 lg:grid-cols-12">
          {/* Form */}
          <section className="lg:col-span-7">
            <form onSubmit={submit} className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
              <h2 className="mb-4 inline-flex items-center gap-2 text-lg font-bold">
                <ClipboardList className="h-5 w-5 text-primary" />
                {isAr ? i18n.caseForm.ar : i18n.caseForm.en}
              </h2>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label={labels.age[lang]}><input value={form.age} onChange={set('age')} type="number" min={0} max={130} className="input" /></Field>
                <Field label={labels.gender[lang]}>
                  <select value={form.gender} onChange={set('gender')} className="input">
                    <option value="">—</option>
                    <option value="male">{labels.male[lang]}</option>
                    <option value="female">{labels.female[lang]}</option>
                  </select>
                </Field>
                <Field label={labels.dx[lang]} className="sm:col-span-2"><input value={form.diagnosis} onChange={set('diagnosis')} className="input" placeholder={isAr ? 'مثال: التهاب رئوي مكتسب من المجتمع' : 'e.g., Community-Acquired Pneumonia'} /></Field>
                <Field label={labels.cc[lang]} className="sm:col-span-2"><input value={form.complaint} onChange={set('complaint')} className="input" /></Field>
                <Field label={labels.hpi[lang]} className="sm:col-span-2"><textarea value={form.presentIllness} onChange={set('presentIllness')} rows={2} className="input" /></Field>
                <Field label={labels.history[lang]} className="sm:col-span-2"><textarea value={form.history} onChange={set('history')} rows={2} className="input" /></Field>
                <Field label={labels.vitals[lang]} className="sm:col-span-2"><input value={form.vitals} onChange={set('vitals')} className="input" placeholder="BP 130/80, HR 102, RR 22, SpO2 95%, T 38.5°C" /></Field>
                <Field label={labels.exam[lang]} className="sm:col-span-2"><textarea value={form.exam} onChange={set('exam')} rows={3} className="input" /></Field>
                <Field label={labels.symptoms[lang]} className="sm:col-span-2"><textarea value={form.symptoms} onChange={set('symptoms')} rows={2} className="input" placeholder={isAr ? 'مفصولة بفواصل' : 'comma-separated'} /></Field>
                <Field label={labels.labs[lang]} className="sm:col-span-2"><textarea value={form.labs} onChange={set('labs')} rows={2} className="input" /></Field>
                <Field label={labels.meds[lang]} className="sm:col-span-2"><textarea value={form.meds} onChange={set('meds')} rows={2} className="input" /></Field>
                <Field label={labels.allergies[lang]} className="sm:col-span-2"><input value={form.allergies} onChange={set('allergies')} className="input" /></Field>
                <Field label={labels.nursing[lang]} className="sm:col-span-2"><textarea value={form.nursing} onChange={set('nursing')} rows={3} className="input" /></Field>
                <Field label={labels.procedures[lang]} className="sm:col-span-2"><input value={form.procedures} onChange={set('procedures')} className="input" placeholder="Foley catheter, IV line, NG tube…" /></Field>
                <Field label={labels.paste[lang]} className="sm:col-span-2"><textarea value={form.casePaste} onChange={set('casePaste')} rows={5} className="input" placeholder={isAr ? 'الصق الحالة الكاملة هنا (اختياري)' : 'Paste the full case here (optional)'} /></Field>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button type="button" onClick={clearForm} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-rose-500 hover:text-rose-500 dark:border-white/10 dark:text-slate-200">
                  <Trash2 className="h-4 w-4" /> {isAr ? i18n.clear.ar : i18n.clear.en}
                </button>
                <button type="submit" disabled={loading} className="ml-auto inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary to-primary-600 px-6 py-2.5 text-sm font-bold text-white shadow-lg shadow-primary/30 transition hover:opacity-90 disabled:opacity-60">
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                  {loading ? (isAr ? i18n.generating.ar : i18n.generating.en) : (isAr ? i18n.generate.ar : i18n.generate.en)}
                </button>
              </div>
            </form>
          </section>

          {/* Side panel */}
          <aside className="space-y-6 lg:col-span-5">
            <div className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
              <h3 className="mb-2 inline-flex items-center gap-2 text-base font-bold">
                <Sparkles className="h-4 w-4 text-primary" /> {isAr ? 'كيف يعمل' : 'How it works'}
              </h3>
              <ol className="ms-4 list-decimal space-y-1 text-sm text-slate-600 dark:text-slate-300">
                <li>{isAr ? 'املأ بيانات المريض أو الصق الحالة كاملة.' : 'Fill the patient data or paste the case.'}</li>
                <li>{isAr ? 'نحلل فقط المعلومات المُقدَّمة دون اختلاق بيانات.' : 'We analyze only what you provide — nothing is invented.'}</li>
                <li>{isAr ? 'تُرتَّب التشخيصات حسب الأولوية (ABC + Maslow).' : 'Diagnoses are ranked by ABC + Maslow priority.'}</li>
                <li>{isAr ? 'روابط حقيقية لـ NANDA-I وNICE وWHO وCDC وغيرها.' : 'Real links to NANDA-I, NICE, WHO, CDC and more.'}</li>
              </ol>
            </div>

            <AnimatePresence>
              {showHistory && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5">
                  <h3 className="mb-3 inline-flex items-center gap-2 text-base font-bold">
                    <BookOpen className="h-4 w-4 text-primary" /> {isAr ? i18n.history.ar : i18n.history.en}
                  </h3>
                  {!user ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400">{isAr ? i18n.loginToSave.ar : i18n.loginToSave.en}</p>
                  ) : historyLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  ) : history.length === 0 ? (
                    <p className="text-sm text-slate-500 dark:text-slate-400">{isAr ? i18n.noHistory.ar : i18n.noHistory.en}</p>
                  ) : (
                    <ul className="space-y-2">
                      {history.map((h) => (
                        <li key={h.id} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
                          <div className="min-w-0">
                            <div className="truncate font-semibold">{h.title}</div>
                            <div className="text-xs text-slate-400">{new Date(h.created_at).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</div>
                          </div>
                          <div className="flex shrink-0 gap-1">
                            <button onClick={() => loadPlan(h.id)} className="rounded-lg border border-primary/30 bg-primary/5 px-2 py-1 text-xs font-semibold text-primary hover:bg-primary/10">{isAr ? i18n.load.ar : i18n.load.en}</button>
                            <button onClick={() => deletePlan(h.id)} className="rounded-lg border border-rose-300/40 bg-rose-50/50 px-2 py-1 text-xs font-semibold text-rose-500 hover:bg-rose-100 dark:bg-rose-500/10"><Trash2 className="h-3.5 w-3.5" /></button>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </aside>
        </div>

        {/* Result */}
        <AnimatePresence>
          {result && (
            <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-8">
              <div className="mb-4 flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-extrabold">{isAr ? 'خطة الرعاية المُنشأة' : 'Generated Nursing Care Plan'}</h2>
                <div className="ms-auto flex flex-wrap items-center gap-2">
                  <button onClick={() => setEditingPlan((v) => !v)} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    {editingPlan ? <Check className="h-3.5 w-3.5" /> : <Edit3 className="h-3.5 w-3.5" />}
                    {editingPlan ? (isAr ? i18n.exitEdit.ar : i18n.exitEdit.en) : (isAr ? i18n.editPlan.ar : i18n.editPlan.en)}
                  </button>
                  <button onClick={() => setShowReferences((v) => !v)} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    {showReferences ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    {isAr ? i18n.references.ar : i18n.references.en}
                  </button>
                  <button onClick={copyPlan} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    <Copy className="h-3.5 w-3.5" /> {isAr ? i18n.copy.ar : i18n.copy.en}
                  </button>
                  <button onClick={downloadPdf} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    <Download className="h-3.5 w-3.5" /> {isAr ? i18n.pdf.ar : i18n.pdf.en}
                  </button>
                  <button onClick={() => window.print()} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    <Printer className="h-3.5 w-3.5" /> {isAr ? i18n.print.ar : i18n.print.en}
                  </button>
                  <button onClick={shareLink} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    <LinkIcon className="h-3.5 w-3.5" /> {isAr ? i18n.share.ar : i18n.share.en}
                  </button>
                  <button onClick={submit} className="inline-flex items-center gap-1 rounded-lg border border-primary/30 bg-primary/5 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/10">
                    <RefreshCw className="h-3.5 w-3.5" /> {isAr ? i18n.regenerate.ar : i18n.regenerate.en}
                  </button>
                  <button onClick={() => { setResult(null); setSavedPlanId(null); }} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:border-primary hover:text-primary dark:border-white/10">
                    <Edit3 className="h-3.5 w-3.5" /> {isAr ? i18n.editCase.ar : i18n.editCase.en}
                  </button>
                  <button onClick={savePlan} disabled={!!savedPlanId} className="inline-flex items-center gap-1 rounded-lg bg-gradient-to-r from-primary to-primary-600 px-3 py-1.5 text-xs font-bold text-white shadow disabled:opacity-60">
                    {savedPlanId ? <Check className="h-3.5 w-3.5" /> : (user ? <Save className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />)}
                    {savedPlanId ? (isAr ? i18n.saved.ar : i18n.saved.en) : (isAr ? i18n.save.ar : i18n.save.en)}
                  </button>
                </div>
              </div>

              {editingPlan && (
                <p className="mb-3 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">{isAr ? i18n.editPlanHint.ar : i18n.editPlanHint.en}</p>
              )}

              {result.plan?.priority_rationale && (
                <div className="mb-4 rounded-2xl border border-primary/30 bg-primary/5 p-4 text-sm dark:border-primary/40 dark:bg-primary/10">
                  <strong className="me-2 inline-flex items-center gap-1"><Heart className="h-4 w-4 text-primary" />{isAr ? i18n.priorityRationale.ar : i18n.priorityRationale.en}:</strong>
                  {result.plan.priority_rationale}
                </div>
              )}

              <div ref={printRef} className="rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-xl backdrop-blur dark:border-white/10 dark:bg-white/5 sm:p-6 print:border-0 print:bg-white print:p-0 print:shadow-none">
                <div className="mb-4 hidden print:block">
                  <h1 className="text-2xl font-extrabold text-slate-900">{isAr ? 'خطة الرعاية التمريضية' : 'Nursing Care Plan'}</h1>
                  <p className="text-xs text-slate-500">{new Date().toLocaleString(isAr ? 'ar-EG' : 'en-US')}</p>
                </div>

                <CarePlanTable plan={result.plan} lang={lang} editing={editingPlan} onUpdate={(p) => setResult((r: any) => ({ ...r, plan: p }))} showRefs={showReferences} />
              </div>
            </motion.section>
          )}
        </AnimatePresence>

        {!result && (
          <div className="mt-8 rounded-3xl border border-dashed border-slate-300 bg-white/50 p-10 text-center text-sm text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
            {isAr ? i18n.noResults.ar : i18n.noResults.en}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

function Field({ label, className = '', children }: { label: string; className?: string; children: React.ReactNode }) {
  return (
    <label className={`flex flex-col gap-1 text-sm ${className}`}>
      <span className="font-semibold text-slate-700 dark:text-slate-300">{label}</span>
      {children}
    </label>
  );
}

function CarePlanTable({ plan, lang, editing, onUpdate, showRefs }: { plan: any; lang: Lang; editing: boolean; onUpdate: (p: any) => void; showRefs: boolean; }) {
  const isAr = lang === 'ar';
  if (!plan || !plan.diagnoses?.length) {
    return <p className="p-6 text-sm text-slate-500">{isAr ? 'لا توجد خطة.' : 'No care plan.'}</p>;
  }
  const updateDiag = (idx: number, key: string, value: any) => {
    const next = { ...plan, diagnoses: plan.diagnoses.map((d: any, i: number) => (i === idx ? { ...d, [key]: value } : d)) };
    onUpdate(next);
  };
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-white/10">
      {/* Desktop / tablet table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-700 dark:bg-white/5 dark:text-slate-200">
            <tr>
              <th className="px-3 py-3 text-start font-bold">{isAr ? i18n.colDiagnosis.ar : i18n.colDiagnosis.en}</th>
              <th className="px-3 py-3 text-start font-bold">{isAr ? i18n.colGoal.ar : i18n.colGoal.en}</th>
              <th className="px-3 py-3 text-start font-bold">{isAr ? i18n.colInterventions.ar : i18n.colInterventions.en}</th>
              <th className="px-3 py-3 text-start font-bold">{isAr ? i18n.colEvaluation.ar : i18n.colEvaluation.en}</th>
            </tr>
          </thead>
          <tbody>
            {plan.diagnoses.map((d: any, idx: number) => (
              <tr key={d.key || idx} className="align-top border-t border-slate-200 dark:border-white/10">
                <DiagnosisCell d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'diagnosis_text', v)} />
                <GoalsCell d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'goals_en', v)} />
                <InterventionsCell d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'interventions_en', v)} />
                <EvaluationCell d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'eval_options', v)} />
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="space-y-4 md:hidden">
        {plan.diagnoses.map((d: any, idx: number) => (
          <div key={d.key || idx} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
            <DiagnosisBlock d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'diagnosis_text', v)} />
            <div className="mt-3">
              <BlockTitle>{isAr ? i18n.colGoal.ar : i18n.colGoal.en}</BlockTitle>
              <GoalsBlock d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'goals_en', v)} />
            </div>
            <div className="mt-3">
              <BlockTitle>{isAr ? i18n.colInterventions.ar : i18n.colInterventions.en}</BlockTitle>
              <InterventionsBlock d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'interventions_en', v)} />
            </div>
            <div className="mt-3">
              <BlockTitle>{isAr ? i18n.colEvaluation.ar : i18n.colEvaluation.en}</BlockTitle>
              <EvaluationBlock d={d} lang={lang} editing={editing} onUpdate={(v) => updateDiag(idx, 'eval_options', v)} />
            </div>
          </div>
        ))}
      </div>

      {showRefs && (
        <div className="mt-6 space-y-4 border-t border-slate-200 px-1 pt-4 dark:border-white/10">
          <h3 className="inline-flex items-center gap-2 font-bold"><BookOpen className="h-4 w-4 text-primary" />{isAr ? i18n.references.ar : i18n.references.en}</h3>
          {plan.diagnoses.map((d: any, idx: number) => (
            <div key={`refs-${d.key || idx}`} className="rounded-xl border border-slate-200 bg-slate-50/60 p-3 text-xs dark:border-white/10 dark:bg-white/5">
              <div className="font-bold">{isAr ? d.nanda_ar : d.nanda_en}</div>
              <ul className="mt-2 flex flex-wrap gap-2">
                {(isAr ? (d.refs_ar || d.refs_en || []) : (d.refs_en || d.refs_ar || [])).map((r: any, j: number) => (
                  <li key={j}>
                    <a href={r.url} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/5 px-2 py-0.5 font-semibold text-primary hover:bg-primary/10">
                      {r.abbr} ↗
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}

      <p className="mt-6 rounded-xl border border-amber-300/40 bg-amber-50 p-3 text-xs text-amber-900 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-100">
        {isAr ? i18n.disclaimer.ar : i18n.disclaimer.en}
      </p>
    </div>
  );
}

function BlockTitle({ children }: { children: React.ReactNode }) {
  return <div className="mb-1 text-xs font-bold uppercase tracking-wide text-primary">{children}</div>;
}

function DiagnosisCell({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string) => void; }) {
  const isAr = lang === 'ar';
  const text = d.diagnosis_text || formatDiagnosisText(d, lang);
  if (!editing) return <td className="px-3 py-3 text-start text-sm leading-relaxed">{text}</td>;
  return <td className="px-3 py-3 text-start"><textarea defaultValue={text} onBlur={(e) => onUpdate(e.target.value)} className="textarea w-full" rows={3} /></td>;
}

function DiagnosisBlock({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string) => void; }) {
  const isAr = lang === 'ar';
  const text = d.diagnosis_text || formatDiagnosisText(d, lang);
  if (!editing) return <div className="text-sm leading-relaxed">{text}</div>;
  return <textarea defaultValue={text} onBlur={(e) => onUpdate(e.target.value)} className="textarea w-full" rows={3} />;
}

function GoalsCell({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string[]) => void; }) {
  const isAr = lang === 'ar';
  const list: string[] = d.goals_en || (isAr ? d.goals_ar : d.goals_en) || [];
  if (!editing) return <td className="px-3 py-3 text-start text-sm leading-relaxed"><ul className="list-disc ps-4">{list.map((g, j) => <li key={j}>{g}</li>)}</ul></td>;
  return <td className="px-3 py-3 text-start"><GoalsEditor list={list} onUpdate={onUpdate} /></td>;
}

function GoalsBlock({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string[]) => void; }) {
  const isAr = lang === 'ar';
  const list: string[] = d.goals_en || (isAr ? d.goals_ar : d.goals_en) || [];
  if (!editing) return <ul className="list-disc ps-4 text-sm leading-relaxed">{list.map((g, j) => <li key={j}>{g}</li>)}</ul>;
  return <GoalsEditor list={list} onUpdate={onUpdate} />;
}

function GoalsEditor({ list, onUpdate }: { list: string[]; onUpdate: (v: string[]) => void; }) {
  const [val, setVal] = useState(list.join('\n'));
  useEffect(() => { setVal(list.join('\n')); }, [list]);
  return <textarea value={val} onChange={(e) => setVal(e.target.value)} onBlur={() => onUpdate(val.split('\n').map((x) => x.trim()).filter(Boolean))} className="textarea w-full" rows={3} />;
}

function InterventionsCell({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string[]) => void; }) {
  const list: string[] = d.interventions_en || [];
  if (!editing) return <td className="px-3 py-3 text-start text-sm leading-relaxed"><ol className="list-decimal ps-4">{list.map((x, j) => <li key={j}>{x}</li>)}</ol></td>;
  return <td className="px-3 py-3 text-start"><IntEditor list={list} onUpdate={onUpdate} /></td>;
}

function InterventionsBlock({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: string[]) => void; }) {
  const list: string[] = d.interventions_en || [];
  if (!editing) return <ol className="list-decimal ps-4 text-sm leading-relaxed">{list.map((x, j) => <li key={j}>{x}</li>)}</ol>;
  return <IntEditor list={list} onUpdate={onUpdate} />;
}

function IntEditor({ list, onUpdate }: { list: string[]; onUpdate: (v: string[]) => void; }) {
  const [val, setVal] = useState(list.join('\n'));
  useEffect(() => { setVal(list.join('\n')); }, [list]);
  return <textarea value={val} onChange={(e) => setVal(e.target.value)} onBlur={() => onUpdate(val.split('\n').map((x) => x.trim()).filter(Boolean))} className="textarea w-full" rows={6} />;
}

function EvaluationCell({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: any) => void; }) {
  const isAr = lang === 'ar';
  const opts = d.eval_options || [];
  if (!editing) return (
    <td className="px-3 py-3 text-start text-sm leading-relaxed">
      <ul className="space-y-1.5">
        {opts.map((o: any, j: number) => (
          <li key={j} className="rounded-lg border border-slate-200 p-2 dark:border-white/10">
            <span className={`me-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${o.tag === 'met' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300' : o.tag === 'partial' ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300' : 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'}`}>
              {tagLabel(o.tag, lang)}
            </span>
            {isAr ? o.ar : o.en}
          </li>
        ))}
      </ul>
    </td>
  );
  return <td className="px-3 py-3 text-start"><textarea defaultValue={opts.map((o: any) => `[${o.tag}] ${isAr ? o.ar : o.en}`).join('\n')} onBlur={(e) => onUpdate(parseEvalText(e.target.value))} className="textarea w-full" rows={5} /></td>;
}

function EvaluationBlock({ d, lang, editing, onUpdate }: { d: any; lang: Lang; editing: boolean; onUpdate: (v: any) => void; }) {
  const isAr = lang === 'ar';
  const opts = d.eval_options || [];
  if (!editing) return (
    <ul className="space-y-1.5 text-sm leading-relaxed">
      {opts.map((o: any, j: number) => (
        <li key={j} className="rounded-lg border border-slate-200 p-2 dark:border-white/10">
          <span className={`me-2 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${o.tag === 'met' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300' : o.tag === 'partial' ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300' : 'bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300'}`}>
            {tagLabel(o.tag, lang)}
          </span>
          {isAr ? o.ar : o.en}
        </li>
      ))}
    </ul>
  );
  return <textarea defaultValue={opts.map((o: any) => `[${o.tag}] ${isAr ? o.ar : o.en}`).join('\n')} onBlur={(e) => onUpdate(parseEvalText(e.target.value))} className="textarea w-full" rows={5} />;
}

function parseEvalText(s: string) {
  return s.split('\n').map((line) => line.trim()).filter(Boolean).map((line) => {
    const m = line.match(/^\[(met|partial|not)\]\s*(.*)$/i);
    if (m) return { tag: m[1].toLowerCase(), en: m[2], ar: m[2] };
    return { tag: 'met', en: line, ar: line };
  });
}

function tagLabel(tag: string, lang: Lang) {
  if (tag === 'met') return lang === 'ar' ? i18n.met.ar : i18n.met.en;
  if (tag === 'partial') return lang === 'ar' ? i18n.partial.ar : i18n.partial.en;
  return lang === 'ar' ? i18n.not.ar : i18n.not.en;
}

function formatDiagnosisText(d: any, lang: Lang): string {
  const isAr = lang === 'ar';
  const dx = isAr ? (d.nanda_ar || d.nanda_en) : (d.nanda_en || d.nanda_ar);
  const rf = isAr ? (d.related_factor_ar || d.related_factor_en) : (d.related_factor_en || d.related_factor_ar);
  const isRisk = d.key?.startsWith?.('risk_') || (dx || '').toLowerCase().startsWith('risk') || (d.key || '').startsWith('risk_');
  if (isRisk) {
    if (!rf) return `${dx}.`;
    return `${dx} related to ${rf}.`;
  }
  const ae = d.ae_en_ar && isAr ? d.ae_en_ar : (d.ae || []);
  const aeText = Array.isArray(ae) && ae.length ? ae.join(', ') : (isAr ? (d.ae_ar_default || '—') : '—');
  if (!rf) return `${dx} as evidenced by ${aeText}.`;
  return `${dx} related to ${rf} as evidenced by ${aeText}.`;
}

function formatPlanText(r: any, form: FormState): string {
  const lang: Lang = r.lang || 'en';
  const isAr = lang === 'ar';
  const L = (e: string, a: string) => (isAr ? a : e);
  let out = '';
  out += `${L('NURSING CARE PLAN', 'خطة الرعاية التمريضية')}\n`;
  out += `Date: ${new Date().toLocaleString(isAr ? 'ar-EG' : 'en-US')}\n`;
  if (form.diagnosis) out += `\n${L('Diagnosis', 'التشخيص')}: ${form.diagnosis}`;
  if (form.age || form.gender) out += `\n${L('Patient', 'المريض')}: ${form.age || '—'} y, ${form.gender || '—'}\n`;
  if (r.plan?.priority_rationale) out += `\n${L('Priority', 'الأولوية')}: ${r.plan.priority_rationale}\n`;
  out += '\n';
  r.plan.diagnoses.forEach((d: any, idx: number) => {
    out += `${idx + 1}. ${formatDiagnosisText(d, lang)}\n`;
    const goals = (d.goals_en || d.goals_ar || []).join(' | ');
    if (goals) out += `   ${L('Goal', 'الهدف')}: ${goals}\n`;
    const ints = (d.interventions_en || []).join(' | ');
    if (ints) out += `   ${L('Interventions', 'التدخلات')}: ${ints}\n`;
    const evals = (d.eval_options || []).map((e: any) => `[${e.tag}] ${isAr ? e.ar : e.en}`).join(' | ');
    if (evals) out += `   ${L('Evaluation', 'التقييم')}: ${evals}\n`;
    const refs = (d.refs_en || []).map((r2: any) => `${r2.abbr} (${r2.url})`).join(', ');
    if (refs) out += `   ${L('References', 'المراجع')}: ${refs}\n`;
    out += '\n';
  });
  out += `\n${r.disclaimer || ''}\n`;
  return out;
}

import Browse from '../components/Browse';
export default function Books() { return <Browse section="books" />; }

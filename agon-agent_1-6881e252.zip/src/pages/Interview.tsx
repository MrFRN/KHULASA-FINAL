import Browse from '../components/Browse';
export default function Interview() { return <Browse section="interview" />; }

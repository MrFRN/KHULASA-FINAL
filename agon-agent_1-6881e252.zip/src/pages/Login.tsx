import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Cross, Loader2, ArrowRight } from 'lucide-react';
import supabase from '../lib/supabase';
import { signInWithGoogle } from '../lib/googleAuth';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { useLang } from '../contexts/LanguageContext';
import LanguageToggle from '../components/LanguageToggle';

export default function Login() {
  const { user, loading: authLoading } = useAuth();
  const { settings } = useSettings();
  const { t } = useLang();
  const navigate = useNavigate();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => { if (!authLoading && user) navigate('/admin', { replace: true }); }, [user, authLoading, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setNotice('');
    if (!email || !password) { setError(t('enterBoth')); return; }
    if (password.length < 6) { setError(t('passMin')); return; }
    setBusy(true);
    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (!data.session) { setNotice(t('accountCreated')); setIsSignUp(false); }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-50 px-5 py-12 dark:bg-navy">
      <div className="absolute -top-24 right-0 h-96 w-96 rounded-full bg-primary/20 blur-3xl animate-blob" />
      <div className="absolute -bottom-24 left-0 h-96 w-96 rounded-full bg-secondary/20 blur-3xl animate-blob" style={{ animationDelay: '4s' }} />
      <div className="relative w-full max-w-sm">
        <div className="mb-8 text-center">
          <Link to="/" className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-white shadow-lg shadow-primary/30"><Cross className="h-7 w-7" /></Link>
          <div className="mb-4 flex justify-center"><LanguageToggle /></div>
          <h1 className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white">{isSignUp ? t('signupTitle') : t('loginTitle')}</h1>
          <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">{settings.siteName}</p>
        </div>

        <div className="glass-strong rounded-2xl p-6 shadow-xl">
          {error && <div className="mb-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 dark:bg-red-500/10 dark:text-red-300">{error}</div>}
          {notice && <div className="mb-4 rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">{notice}</div>}
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-slate-700 dark:text-slate-200">{t('email')}</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" dir="ltr" className="w-full rounded-lg border border-slate-300 bg-white/80 px-3 py-2.5 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-semibold text-slate-700 dark:text-slate-200">{t('password')}</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" dir="ltr" className="w-full rounded-lg border border-slate-300 bg-white/80 px-3 py-2.5 text-sm outline-none focus:border-primary dark:border-white/10 dark:bg-white/5 dark:text-white" />
            </div>
            <button type="submit" disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-l from-primary to-primary-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-primary/30 transition hover:opacity-90 disabled:opacity-60">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} {isSignUp ? t('createAccount') : t('signIn')}
            </button>
          </form>
          <div className="my-4 flex items-center gap-3 text-xs text-slate-400"><span className="h-px flex-1 bg-slate-200 dark:bg-white/10" /> {t('or')} <span className="h-px flex-1 bg-slate-200 dark:bg-white/10" /></div>
          <button onClick={() => signInWithGoogle(settings.siteName)} className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white/80 px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:bg-white dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
            <GoogleIcon /> {t('google')}
          </button>
          <p className="mt-5 text-center text-sm text-slate-500 dark:text-slate-400">
            {isSignUp ? t('haveAccount') : t('noAccount')}{' '}
            <button onClick={() => { setIsSignUp(!isSignUp); setError(''); setNotice(''); }} className="font-bold text-primary underline">{isSignUp ? t('signIn') : t('createAccount')}</button>
          </p>
        </div>

        <div className="mt-5 rounded-xl border border-slate-200 bg-white/60 px-4 py-3 text-center text-xs text-slate-500 dark:border-white/10 dark:bg-white/5 dark:text-slate-400">
          {t('demoAccount')} <span dir="ltr" className="font-semibold text-slate-700 dark:text-slate-200">demo@example.com</span> / <span dir="ltr" className="font-semibold text-slate-700 dark:text-slate-200">password123</span>
        </div>
        <Link to="/" className="mt-5 flex items-center justify-center gap-1 text-sm text-slate-500 hover:text-primary dark:text-slate-400">{t('backToSite')} <ArrowRight className="h-4 w-4" /></Link>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.1a6.6 6.6 0 0 1 0-4.2V7.06H2.18a11 11 0 0 0 0 9.88l3.66-2.84z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84C6.71 7.31 9.14 5.38 12 5.38z" />
    </svg>
  );
}

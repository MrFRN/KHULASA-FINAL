import Browse from '../components/Browse';
export default function Study() { return <Browse section="study" />; }

import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, ArrowLeft, Calculator, ClipboardList } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import { useLang } from '../contexts/LanguageContext';

export default function AIAssistant() {
  const { t, isAr } = useLang();
  const Arrow = isAr ? ArrowLeft : ArrowRight;
  const TOOLS = [
    {
      key: 'care-plan',
      icon: ClipboardList,
      title: t('carePlanTitle'),
      desc: t('carePlanDesc'),
      to: '/ai-assistant/care-plan',
    },
    {
      key: 'calculator',
      icon: Calculator,
      title: t('calcTitle'),
      desc: t('calcDesc'),
      to: '/ai-assistant/calculator',
    },
  ];

  return (
    <div className="min-h-screen bg-[#f7f7f5] text-slate-800 dark:bg-navy dark:text-slate-100">
      <Navbar />

      <main className="mx-auto max-w-5xl px-5 py-16 md:py-24">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">{t('toolsEyebrow')}</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight text-slate-900 dark:text-white md:text-4xl">
          {t('toolsTitle')}
        </h1>
        <p className="mt-4 max-w-xl text-base leading-7 text-slate-500 dark:text-slate-400">
          {t('toolsLead')}
        </p>
        <p className="mt-4 inline-flex items-center gap-2 text-sm text-slate-500">
          <AlertTriangle className="h-3.5 w-3.5" />
          {t('toolsDisclaimer')}
        </p>

        <div className="mt-14 space-y-6">
          {TOOLS.map((tool) => (
            <Link
              key={tool.key}
              to={tool.to}
              className="group block rounded-2xl border border-slate-200/80 bg-white px-6 py-7 transition hover:border-slate-300 dark:border-white/10 dark:bg-white/5"
            >
              <div className="flex items-start gap-4">
                <span className="mt-0.5 grid h-10 w-10 place-items-center rounded-xl bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-200">
                  <tool.icon className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <h2 className="text-lg font-semibold text-slate-900 dark:text-white">{tool.title}</h2>
                  <p className="mt-1 text-sm leading-6 text-slate-500">{tool.desc}</p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm text-slate-700 group-hover:gap-2 dark:text-slate-200">
                    {t('open')} <Arrow className="h-3.5 w-3.5" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  );
}

import type { Resource, NursingCategory } from '../types';
import type { Lang } from '../i18n/strings';
import { SECTIONS } from './constants';
import { STRINGS } from '../i18n/strings';

export function resourceTitle(r: Resource, lang: Lang) {
  if (lang === 'en' && r.en?.title_en) return r.en.title_en;
  return r.title;
}

export function resourceDescription(r: Resource, lang: Lang) {
  if (lang === 'en' && r.en?.description_en) return r.en.description_en;
  return r.description;
}

export function categoryName(c: NursingCategory, lang: Lang) {
  if (lang === 'en' && c.en?.name_en) return c.en.name_en;
  return c.name;
}

export function sectionCopy(key: keyof typeof SECTIONS, lang: Lang) {
  const meta = SECTIONS[key];
  if (key === 'study') return { ...meta, label: STRINGS[lang].studyLabel, desc: STRINGS[lang].studyDesc };
  if (key === 'books') return { ...meta, label: STRINGS[lang].booksLabel, desc: STRINGS[lang].booksDesc };
  return { ...meta, label: STRINGS[lang].interviewLabel, desc: STRINGS[lang].interviewDesc };
}

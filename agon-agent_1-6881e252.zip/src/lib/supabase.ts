import { createClient } from '@supabase/supabase-js';

const OWNER_URL = 'https://fsrintykugcpfeacpeay.supabase.co';
const OWNER_ANON = 'sb_publishable_ewWQDmB1aXiFgIdW9nP3JA_9lGN5A1H';

const url = import.meta.env.VITE_SUPABASE_URL || OWNER_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY || OWNER_ANON;

const supabase = createClient(
  url.includes('fsrintykugcpfeacpeay') ? url : OWNER_URL,
  key.startsWith('sb_publishable_ewWQDmB1') ? key : OWNER_ANON,
);

export default supabase;

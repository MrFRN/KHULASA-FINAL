import supabase from './supabase';
import type { Resource, NursingCategory, Analytics, PublicStats } from '../types';
import { CHUNK_SIZE, extOf } from './filetypes';

async function authHeaders(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function handle(res: Response) {
  if (!res.ok) {
    let msg = 'حدث خطأ ما';
    try { msg = (await res.json()).error || msg; } catch { /* ignore */ }
    throw new Error(msg);
  }
  return res.json();
}

export async function apiGet<T>(path: string, auth = false): Promise<T> {
  const headers = auth ? await authHeaders() : {};
  const res = await fetch(path, { headers });
  return handle(res);
}

export async function apiSend<T>(path: string, method: string, body: unknown, auth = true): Promise<T> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (auth) Object.assign(headers, await authHeaders());
  const res = await fetch(path, { method, headers, body: JSON.stringify(body) });
  return handle(res);
}

// ---- Resources ----
export function fetchResources(params: Record<string, string> = {}): Promise<Resource[]> {
  const qs = new URLSearchParams({ view: 'public', ...params }).toString();
  return apiGet<Resource[]>(`/api/resources?${qs}`);
}
export function fetchAdminResources(params: Record<string, string> = {}): Promise<Resource[]> {
  const qs = new URLSearchParams({ view: 'admin', ...params }).toString();
  return apiGet<Resource[]>(`/api/resources?${qs}`, true);
}
export function fetchResource(id: string | number): Promise<Resource> {
  return apiGet<Resource>(`/api/resources?view=public&id=${id}`);
}
export function createResource(body: Partial<Resource>): Promise<Resource> {
  return apiSend<Resource>('/api/resources', 'POST', body);
}
export function updateResource(body: Partial<Resource> & { id: number }): Promise<Resource> {
  return apiSend<Resource>('/api/resources', 'PUT', body);
}
export function deleteResource(id: number): Promise<{ ok: boolean }> {
  return apiSend('/api/resources', 'DELETE', { id });
}

// ---- Categories ----
export function fetchCategories(section?: string): Promise<NursingCategory[]> {
  const qs = section ? `?section=${section}` : '';
  return apiGet<NursingCategory[]>(`/api/categories${qs}`);
}
export function createCategory(body: Partial<NursingCategory>): Promise<NursingCategory> {
  return apiSend<NursingCategory>('/api/categories', 'POST', body);
}
export function updateCategory(body: Partial<NursingCategory> & { id: number }): Promise<NursingCategory> {
  return apiSend<NursingCategory>('/api/categories', 'PUT', body);
}
export function deleteCategory(id: number): Promise<{ ok: boolean }> {
  return apiSend('/api/categories', 'DELETE', { id });
}

// ---- Settings ----
export interface SettingsResponse {
  data: Record<string, string>;
  data_en: Record<string, string>;
}
export function fetchSettings(): Promise<SettingsResponse> {
  return apiGet<SettingsResponse>('/api/settings');
}
export function updateSettings(data: Record<string, string>): Promise<SettingsResponse> {
  return apiSend('/api/settings', 'PUT', { data });
}

// ---------------- AI Clinical Assistant ----------------
export interface AiReport {
  disclaimer: string;
  generatedAt: string;
  primaryDiagnosis?: {
    id: string; name: string; name_en: string; confidence: number;
    support: string[]; keyFindings: string[]; missingInformation: string[];
  };
  profileAnalysis?: {
    ageGroup: string; ageNote: string; sexNote: string; weightNote: string;
    pregnancyNote?: string; bmi?: number | null; vitalNotes: string[]; labNotes: string[];
  };
  clinicalSummary?: string[];
  evidencePipeline?: {
    findingsCollected: number;
    sourcesRetrieved: number;
    check: { passed: boolean; grade: string; summary: string; sourcesUsed: number; findingsUsed: number; groundedClaims: { org: string; url: string; claim: string }[] };
    retrieved: { org: string; title: string; url: string; score: number; liveOk: boolean | null }[];
  };
  webResearch?: {
    ranAt?: string;
    durationMs?: number;
    provider?: string;
    queries?: { primary: string; nursing: string; emergency: string };
    articles?: { source: string; title: string; url: string; year?: string; journal?: string; authors?: string }[];
    portals?: { org: string; title: string; url: string }[];
    error?: string;
  };
  differentials: {
    id: string; name: string; name_en: string; confidence: number; score: number; maxScore: number;
    matchedSymptoms: string[]; matchedRisk: string[]; matchedVitals: string[]; matchedLabs: string[];
    reasoning: string;
  }[];
  sections: {
    investigations: string[];
    treatment: {
      initial: string[]; firstLine: string[]; alternative: string[]; contraindications: string[];
      monitoring: string[]; followUp: string[]; admission: string[]; icu: string[];
    };
    nursing: {
      assessment: string[]; nanda: string[]; nic: string[]; goals: string[]; education: string[]; discharge: string[]; evaluation: string[];
      priorities?: { rank: number; diagnosis: string; rationale: string }[];
    };
    drugs: {
      generic: string; trade: string; adultDose: string; pedDose: string; route: string;
      frequency: string; contraindications: string; sideEffects: string; interactions: string; nursing: string;
    }[];
    redFlags: string[];
    references: { abbr: string; url: string; note: string }[];
  };
  relatedPdfs: { id: number; title: string; url: string; cover?: string | null }[];
}

export interface AiSettings {
  enabled: boolean;
  disclaimer: string;
  rate_limit_per_hour?: number;
  max_history?: number;
  require_login_for_history?: boolean;
  provider?: string;
  model?: string;
}

export function getAiSettings(): Promise<AiSettings> {
  return apiGet<AiSettings>('/api/ai-settings');
}
export function getAiAdminSettings(): Promise<AiSettings> {
  return apiGet<AiSettings>('/api/ai-settings', true);
}
export function analyzeCase(caseData: unknown): Promise<{ report: AiReport; savedId: number | null; remaining: number; disclaimer: string }> {
  return apiSend('/api/ai-analyze', 'POST', { ...(caseData as any), lang: (caseData as any)?.lang || 'en' }, false);
}

export interface ParsedCaseField { status: 'confirmed' | 'missing' | 'unclear'; value: any; source?: string; note?: string }
export interface ParsedCase {
  ok: boolean;
  error?: string;
  needsText?: boolean;
  sourceText?: string;
  fileMeta?: { name: string; kind: string; unreadable: boolean; note?: string };
  fields: Record<string, ParsedCaseField>;
  confirmed: { key: string; label: string; value: string }[];
  missing: { key: string; label: string }[];
  unclear: { key: string; label: string; value?: string }[];
  counts?: { confirmed: number; missing: number; unclear: number };
}

export function parseCaseText(body: { text?: string; fileBase64?: string; fileName?: string; contentType?: string; lang?: string }): Promise<ParsedCase> {
  return apiSend('/api/ai-parse-case', 'POST', body, false);
}

export interface ChatSource {
  n: number; org: string; title: string; url: string; year?: string; journal?: string; authors?: string; snippet?: string; kind: 'article' | 'portal';
}
export interface ChatReply {
  answer: string;
  insufficient: boolean;
  status: 'ok' | 'limited' | 'empty';
  durationMs: number;
  queries: { primary: string; nursing: string };
  nursing: string[];
  safety: string[];
  sources: ChatSource[];
  ranAt: string;
  mode?: 'normal' | 'source';
  model?: string;
}
export function askNursingChat(body: { question: string; history?: { role: string; content: string }[]; lang?: string; stream?: boolean; continue?: boolean }): Promise<ChatReply> {
  return apiSend('/api/ai-chat', 'POST', body, false);
}
export function getAiHistory(q?: string): Promise<{ id: number; title: string; top_diagnosis: string; created_at: string }[]> {
  return apiGet(`/api/ai-history${q ? `?q=${encodeURIComponent(q)}` : ''}`, true);
}
export function getAiAnalysis(id: number): Promise<any> {
  return apiGet(`/api/ai-history?id=${id}`, true);
}
export function updateAiSettings(config: { enabled: boolean; disclaimer: string; rate_limit_per_hour?: number; max_history?: number; require_login_for_history?: boolean; provider?: string; model?: string }): Promise<any> {
  return apiSend('/api/ai-settings', 'PUT', config, true);
}
export function getAiAnalytics(): Promise<any> {
  return apiGet('/api/ai-analytics', true);
}
export function getAiGuidelines(): Promise<any[]> {
  return apiGet('/api/ai-guidelines');
}
export function updateGuideline(id: number, patch: { enabled?: boolean; url?: string; description?: string }): Promise<any> {
  return apiSend('/api/ai-guidelines', 'PUT', { id, ...patch }, true);
}

// ---- Analytics ----
export function trackEvent(type: string, path?: string, resource_id?: number): void {
  fetch('/api/track', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type, path, resource_id }),
  }).catch(() => {});
}
export function trackDownload(id: number): Promise<{ url: string; file_name: string; title: string }> {
  return apiSend('/api/download', 'POST', { id }, false);
}
export function fetchPublicStats(): Promise<PublicStats> {
  return apiGet<any>('/api/public-stats').then((d) => ({
    files: d.resources ?? 0,
    sources: d.categories ?? 0,
    visitors: d.visitors ?? 0,
    views: d.visitors ?? 0,
    downloads: d.downloads ?? 0,
    books: d.books ?? 0,
    categories: d.categories ?? 0,
    resources: d.resources ?? 0,
  }));
}
export function fetchAnalytics(): Promise<Analytics> {
  return apiGet<Analytics>('/api/analytics', true);
}

// ---- Upload (signed URL + XHR progress) ----
interface SignResp { signedUrl: string; token: string; path: string; publicUrl: string; }
async function signUpload(bucket: string, path: string, upsert: boolean): Promise<SignResp> {
  return apiSend<SignResp>('/api/sign-upload', 'POST', { bucket, path, upsert });
}
function putToSignedUrl(signedUrl: string, file: File | Blob, contentType: string, upsert: boolean, onProgress: (pct: number) => void, accessToken?: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('PUT', signedUrl);
    xhr.setRequestHeader('x-upsert', String(upsert));
    xhr.setRequestHeader('cache-control', 'max-age=3600');
    xhr.setRequestHeader('content-type', contentType || 'application/octet-stream');
    xhr.setRequestHeader('apikey', import.meta.env.VITE_SUPABASE_ANON_KEY);
    if (accessToken) xhr.setRequestHeader('Authorization', `Bearer ${accessToken}`);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();
      let detail = '';
      try { detail = JSON.parse(xhr.responseText)?.message || xhr.responseText; } catch { detail = xhr.responseText; }
      reject(new Error(detail || `فشل الرفع (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error('خطأ في الشبكة أثناء الرفع'));
    xhr.send(file);
  });
}

async function uploadDirect(
  bucket: string, path: string, file: File | Blob, contentType: string,
  upsert: boolean, onProgress: (pct: number) => void, accessToken: string
): Promise<{ publicUrl: string; path: string }> {
  const base = (import.meta.env.VITE_SUPABASE_URL || 'https://fsrintykugcpfeacpeay.supabase.co').replace(/\/$/, '');
  const url = `${base}/storage/v1/object/${bucket}/${path}`;
  await putToSignedUrl(url, file, contentType, upsert, onProgress, accessToken);
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return { publicUrl: data.publicUrl, path };
}

export async function uploadToStorage(
  bucket: string, path: string, file: File | Blob, contentType: string,
  onProgress: (pct: number) => void, upsert = false
): Promise<{ publicUrl: string; path: string }> {
  const { data: sessionData } = await supabase.auth.getSession();
  const accessToken = sessionData.session?.access_token;
  try {
    const sign = await signUpload(bucket, path, upsert);
    await putToSignedUrl(sign.signedUrl, file, contentType, upsert, onProgress, accessToken);
    return { publicUrl: sign.publicUrl, path: sign.path };
  } catch {
    if (!accessToken) throw new Error('سجّل الدخول كأدمن ثم أعد المحاولة');
    return uploadDirect(bucket, path, file, contentType, upsert, onProgress, accessToken);
  }
}

// ---- Chunked (multipart) uploads for large files ----
export interface Chunk { idx: number; url: string; path: string; size: number; }
export interface UploadResult {
  multi: boolean;
  file_url: string;   // '' when multipart
  file_path: string;  // single: object path | multi: folder prefix
  file_size: number;
  chunks?: Chunk[];
}

const uid = () => (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : Math.random().toString(36).slice(2);

// Uploads a file: a single object when small, or several <45MB parts when large.
export async function uploadResourceFile(
  file: File,
  onProgress: (pct: number) => void
): Promise<UploadResult> {
  const ext = extOf(file.name) || 'bin';
  const ct = file.type || 'application/octet-stream';

  if (file.size <= CHUNK_SIZE) {
    const path = `${uid()}.${ext}`;
    const { publicUrl } = await uploadToStorage('files', path, file, ct, onProgress, false);
    return { multi: false, file_url: publicUrl, file_path: path, file_size: file.size };
  }

  const prefix = uid();
  const partCount = Math.ceil(file.size / CHUNK_SIZE);
  const chunks: Chunk[] = [];
  let uploaded = 0;
  for (let i = 0; i < partCount; i++) {
    const start = i * CHUNK_SIZE;
    const blob = file.slice(start, Math.min(file.size, start + CHUNK_SIZE));
    const path = `${prefix}/part-${String(i).padStart(3, '0')}.${ext}`;
    const base = uploaded;
    const { publicUrl } = await uploadToStorage('files', path, blob, ct, (p) => {
      onProgress(Math.min(99, Math.round(((base + (blob.size * p) / 100) / file.size) * 100)));
    }, false);
    chunks.push({ idx: i, url: publicUrl, path, size: blob.size });
    uploaded += blob.size;
  }
  onProgress(100);
  return { multi: true, file_url: '', file_path: prefix, file_size: file.size, chunks };
}

export function fetchChunks(resourceId: number): Promise<Chunk[]> {
  return apiGet<Chunk[]>(`/api/chunks?resource_id=${resourceId}`);
}
export function createChunks(resource_id: number, chunks: Chunk[]) {
  return apiSend('/api/chunks', 'POST', { resource_id, chunks });
}
export function deleteChunks(resource_id: number) {
  return apiSend('/api/chunks', 'DELETE', { resource_id });
}

// Fetches all parts and concatenates them into a single Blob (for preview/download).
export async function assembleChunks(
  chunks: Chunk[],
  fileType: string | null,
  onProgress?: (pct: number) => void
): Promise<Blob> {
  const ordered = [...chunks].sort((a, b) => a.idx - b.idx);
  const buffers: ArrayBuffer[] = [];
  for (let i = 0; i < ordered.length; i++) {
    const res = await fetch(ordered[i].url);
    if (!res.ok) throw new Error('تعذّر تحميل أحد أجزاء الملف');
    buffers.push(await res.arrayBuffer());
    onProgress?.(Math.round(((i + 1) / ordered.length) * 100));
  }
  return new Blob(buffers, { type: fileType || 'application/octet-stream' });
}

export function isMultipart(r: { file_url: string | null }): boolean {
  return !r.file_url;
}

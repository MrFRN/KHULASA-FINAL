export const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500 MB (large files are auto-split into chunks)
// Supabase enforces a per-object global limit (~50 MB). Files bigger than this
// are uploaded as multiple parts and reassembled in the browser on download.
export const CHUNK_SIZE = 45 * 1024 * 1024; // 45 MB per part (safely under the 50 MB cap)

export interface TypeInfo {
  ext: string;
  label: string;
}

export const ALLOWED_TYPES: Record<string, TypeInfo> = {
  pdf: { ext: 'pdf', label: 'PDF' },
  doc: { ext: 'doc', label: 'DOC' },
  docx: { ext: 'docx', label: 'DOCX' },
  ppt: { ext: 'ppt', label: 'PPT' },
  pptx: { ext: 'pptx', label: 'PPTX' },
  xls: { ext: 'xls', label: 'XLS' },
  xlsx: { ext: 'xlsx', label: 'XLSX' },
  csv: { ext: 'csv', label: 'CSV' },
  txt: { ext: 'txt', label: 'TXT' },
  zip: { ext: 'zip', label: 'ZIP' },
  rar: { ext: 'rar', label: 'RAR' },
  png: { ext: 'png', label: 'PNG' },
  jpg: { ext: 'jpg', label: 'JPG' },
  jpeg: { ext: 'jpeg', label: 'JPEG' },
  gif: { ext: 'gif', label: 'GIF' },
  webp: { ext: 'webp', label: 'WEBP' },
  svg: { ext: 'svg', label: 'SVG' },
};

export const ACCEPT_ATTR = Object.keys(ALLOWED_TYPES).map((e) => `.${e}`).join(',');

export function extOf(name: string): string {
  const parts = name.split('.');
  return parts.length > 1 ? parts.pop()!.toLowerCase() : '';
}

export function isAllowed(name: string): boolean {
  return extOf(name) in ALLOWED_TYPES;
}

export function labelForFile(nameOrType: string | null | undefined): string {
  if (!nameOrType) return 'FILE';
  const ext = extOf(nameOrType);
  if (ext && ALLOWED_TYPES[ext]) return ALLOWED_TYPES[ext].label;
  if (nameOrType.includes('/')) {
    const sub = nameOrType.split('/').pop() || '';
    return sub.toUpperCase().slice(0, 5);
  }
  return (ext || 'file').toUpperCase();
}

export function isImageType(nameOrType: string | null | undefined): boolean {
  if (!nameOrType) return false;
  if (nameOrType.startsWith('image/')) return true;
  const ext = extOf(nameOrType);
  return ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext);
}

export function isPdfType(nameOrType: string | null | undefined): boolean {
  if (!nameOrType) return false;
  return nameOrType === 'application/pdf' || extOf(nameOrType) === 'pdf';
}

export function safeName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(-80);
}

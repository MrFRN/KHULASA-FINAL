import * as pdfjsLib from 'pdfjs-dist';

// Load the PDF worker from a CDN pinned to the installed library version so we
// never depend on a worker file being present in node_modules (the available
// build ships a UMD worker, not the ESM one referenced at build time).
const PDFJS_VERSION = (pdfjsLib as unknown as { version?: string }).version || '3.11.174';
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.worker.min.js`;

// Render page 1 of a PDF to a JPEG blob for use as a cover thumbnail.
export async function generatePdfThumbnail(file: File | Blob, maxWidth = 640): Promise<Blob | null> {
  try {
    const buf = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
    const page = await pdf.getPage(1);
    const base = page.getViewport({ scale: 1 });
    const scale = Math.min(2, maxWidth / base.width);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport, canvas } as unknown as Parameters<typeof page.render>[0]).promise;
    return await new Promise<Blob | null>((resolve) =>
      canvas.toBlob((b) => resolve(b), 'image/jpeg', 0.82)
    );
  } catch (e) {
    console.warn('PDF thumbnail generation failed:', e);
    return null;
  }
}

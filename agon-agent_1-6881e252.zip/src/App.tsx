import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { SettingsProvider } from './contexts/SettingsContext';
import { AuthProvider } from './contexts/AuthContext';
import { ToastProvider } from './components/Toast';
import ProtectedRoute from './components/ProtectedRoute';
import Spinner from './components/Spinner';
import Home from './pages/Home';

/**
 * Route-level code splitting. The homepage ships in the main bundle for the
 * fastest first paint; every other page (and the whole admin panel) is loaded
 * on demand. This keeps the initial download small so the site stays fast
 * under heavy traffic.
 */
const Study = lazy(() => import('./pages/Study'));
const Books = lazy(() => import('./pages/Books'));
const Interview = lazy(() => import('./pages/Interview'));
const ResourceDetail = lazy(() => import('./pages/ResourceDetail'));
const SearchResults = lazy(() => import('./pages/SearchResults'));
const Favorites = lazy(() => import('./pages/Favorites'));
const Login = lazy(() => import('./pages/Login'));
const Dashboard = lazy(() => import('./pages/admin/Dashboard'));
const ManageResources = lazy(() => import('./pages/admin/ManageResources'));
const Upload = lazy(() => import('./pages/admin/Upload'));
const Categories = lazy(() => import('./pages/admin/Categories'));
const Settings = lazy(() => import('./pages/admin/Settings'));
const AIAssistant = lazy(() => import('./pages/AIAssistant'));
import { CarePlanPage, CalculatorPage as CalculatorLegacyPage, CasePage } from './pages/AITools';
import NursingCalculator from './pages/NursingCalculator';
const AdminAI = lazy(() => import('./pages/admin/AdminAI'));
const CaseMCQ = lazy(() => import('./pages/CaseMCQ'));

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
      <SettingsProvider>
        <AuthProvider>
          <ToastProvider>
            <BrowserRouter>
              <Suspense fallback={<div className="flex min-h-screen items-center justify-center"><Spinner label="…" /></div>}>
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/study" element={<Study />} />
                  <Route path="/study/:category" element={<Study />} />
                  <Route path="/books" element={<Books />} />
                  <Route path="/books/:category" element={<Books />} />
                  <Route path="/interview" element={<Interview />} />
                  <Route path="/interview/:category" element={<Interview />} />
                  <Route path="/resource/:id" element={<ResourceDetail />} />
                  <Route path="/search" element={<SearchResults />} />
                  <Route path="/favorites" element={<Favorites />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/admin" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
                  <Route path="/admin/resources" element={<ProtectedRoute><ManageResources /></ProtectedRoute>} />
                  <Route path="/admin/upload" element={<ProtectedRoute><Upload /></ProtectedRoute>} />
                  <Route path="/admin/categories" element={<ProtectedRoute><Categories /></ProtectedRoute>} />
                  <Route path="/admin/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
                  <Route path="/admin/ai" element={<ProtectedRoute><AdminAI /></ProtectedRoute>} />
                  <Route path="/clinical-assistant" element={<Navigate to="/ai-assistant" replace />} />
                  <Route path="/ai-assistant" element={<AIAssistant />} />
                  <Route path="/ai-assistant/care-plan" element={<CarePlanPage />} />
                  <Route path="/ai-assistant/calculator" element={<NursingCalculator />} />
                  <Route path="/ai-assistant/case" element={<CasePage />} />
                  <Route path="/ai-assistant/mcq" element={<CaseMCQ />} />
                </Routes>
              </Suspense>
            </BrowserRouter>
          </ToastProvider>
        </AuthProvider>
      </SettingsProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}

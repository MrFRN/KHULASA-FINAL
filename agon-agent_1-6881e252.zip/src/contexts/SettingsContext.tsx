import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import type { ReactNode } from 'react';
import type { SiteSettings } from '../types';
import { DEFAULT_SETTINGS } from '../lib/constants';
import { fetchSettings } from '../lib/api';
import { useLang } from './LanguageContext';
import { STRINGS } from '../i18n/strings';

export interface RawSettings extends SiteSettings {
  siteNameEn?: string;
  taglineEn?: string;
  heroTitleEn?: string;
  heroSubtitleEn?: string;
  heroCtaEn?: string;
  aboutTextEn?: string;
  footerTextEn?: string;
}

interface SettingsValue {
  settings: SiteSettings;
  raw: RawSettings;
  loading: boolean;
  refresh: () => void;
}
const SettingsContext = createContext<SettingsValue>({
  settings: DEFAULT_SETTINGS,
  raw: DEFAULT_SETTINGS,
  loading: true,
  refresh: () => {},
});

export function SettingsProvider({ children }: { children: ReactNode }) {
  const { lang } = useLang();
  const [raw, setRaw] = useState<RawSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(() => {
    fetchSettings()
      .then((data) => {
        setRaw({ ...DEFAULT_SETTINGS, ...(data.data || {}) } as RawSettings);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const fallback = STRINGS[lang];
  const settings: SiteSettings = lang === 'en'
    ? {
        ...raw,
        siteName: raw.siteNameEn || fallback.brand,
        tagline: raw.taglineEn || fallback.tagline,
        heroTitle: raw.heroTitleEn || fallback.heroTitle,
        heroSubtitle: raw.heroSubtitleEn || fallback.heroSubtitle,
        heroCta: raw.heroCtaEn || fallback.heroCta,
        aboutText: raw.aboutTextEn || fallback.aboutText,
        footerText: raw.footerTextEn || fallback.footerText,
      }
    : {
        ...raw,
        siteName: raw.siteName || fallback.brand,
        tagline: raw.tagline || fallback.tagline,
        heroTitle: raw.heroTitle || fallback.heroTitle,
        heroSubtitle: raw.heroSubtitle || fallback.heroSubtitle,
        heroCta: raw.heroCta || fallback.heroCta,
        aboutText: raw.aboutText || fallback.aboutText,
        footerText: raw.footerText || fallback.footerText,
      };

  return (
    <SettingsContext.Provider value={{ settings, raw, loading, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export const useSettings = () => useContext(SettingsContext);

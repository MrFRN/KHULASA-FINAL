import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { STRINGS, type Lang, type StringKey } from '../i18n/strings';

interface LanguageValue {
  lang: Lang;
  isAr: boolean;
  setLang: (l: Lang) => void;
  t: (key: StringKey) => string;
  dir: 'rtl' | 'ltr';
}

const LanguageContext = createContext<LanguageValue>({
  lang: 'ar',
  isAr: true,
  setLang: () => {},
  t: (k) => STRINGS.ar[k],
  dir: 'rtl',
});

function readLang(): Lang {
  try {
    const stored = localStorage.getItem('khulasa-lang');
    if (stored === 'en' || stored === 'ar') return stored;
  } catch { /* ignore */ }
  return 'ar';
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(readLang);

  const setLang = (l: Lang) => {
    setLangState(l);
    try { localStorage.setItem('khulasa-lang', l); } catch { /* ignore */ }
  };

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.classList.toggle('font-ar', lang === 'ar');
    document.documentElement.classList.toggle('font-en', lang === 'en');
    document.title = lang === 'ar' ? 'الخلاصة في التمريض' : 'Al-Khulasa in Nursing';
  }, [lang]);

  const value = useMemo<LanguageValue>(() => ({
    lang,
    isAr: lang === 'ar',
    setLang,
    t: (key) => STRINGS[lang][key],
    dir: lang === 'ar' ? 'rtl' : 'ltr',
  }), [lang]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

// eslint-disable-next-line react-refresh/only-export-components
export const useLang = () => useContext(LanguageContext);

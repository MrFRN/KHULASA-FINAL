import { formatBytes } from '../lib/format';

export default function StorageMeter({ used, quota }: { used: number; quota: number }) {
  const pct = quota > 0 ? Math.min(100, (used / quota) * 100) : 0;
  const near = pct > 85;
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">التخزين المستخدم</span>
        <span className="text-sm text-slate-500 dark:text-slate-400">
          {formatBytes(used)} <span className="text-slate-400">/ {formatBytes(quota)}</span>
        </span>
      </div>
      <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
        <div className={`h-full rounded-full transition-all duration-500 ${near ? 'bg-red-500' : 'bg-gradient-to-l from-primary to-secondary'}`} style={{ width: `${pct}%` }} />
      </div>
      <p className="mt-1.5 text-xs text-slate-400">{formatBytes(Math.max(0, quota - used))} متاح · {pct.toFixed(1)}%</p>
    </div>
  );
}

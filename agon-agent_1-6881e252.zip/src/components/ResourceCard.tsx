import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Download, Heart, FileText, Star } from 'lucide-react';
import type { Resource } from '../types';
import { formatBytes } from '../lib/format';
import { isFavorite, toggleFavorite } from '../lib/favorites';
import FileTypeChip from './FileTypeChip';
import { useLang } from '../contexts/LanguageContext';
import { resourceTitle, sectionCopy } from '../lib/localize';

export default function ResourceCard({ resource, index = 0 }: { resource: Resource; index?: number }) {
  const [fav, setFav] = useState(false);
  const { lang, t } = useLang();
  useEffect(() => {
    setFav(isFavorite(resource.id));
    const h = () => setFav(isFavorite(resource.id));
    window.addEventListener('favorites-changed', h);
    return () => window.removeEventListener('favorites-changed', h);
  }, [resource.id]);

  const section = sectionCopy(resource.section, lang);
  const title = resourceTitle(resource, lang);
  const meta = resource.section === 'books'
    ? resource.author
    : (resource.subject || resource.year);

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.04, 0.3) }}
    >
      <Link
        to={`/resource/${resource.id}`}
        className="group flex h-full flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white transition hover:-translate-y-1 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/10 dark:border-white/10 dark:bg-white/5"
      >
        <div className={`relative aspect-[4/3] overflow-hidden bg-gradient-to-br ${section?.color || 'from-primary to-secondary'}`}>
          {resource.cover_image_url ? (
            <img src={resource.cover_image_url} alt={title} loading="lazy" className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-white/80"><FileText className="h-12 w-12" /></div>
          )}
          <div className="absolute inset-x-0 top-0 flex items-start justify-between p-3">
            <FileTypeChip name={resource.file_type || resource.file_name} />
            <button
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleFavorite(resource.id); }}
              aria-label={t('addFavorite')}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-slate-500 shadow-sm transition hover:text-accent dark:bg-navy-800/80"
            >
              <Heart className={`h-4 w-4 ${fav ? 'fill-accent text-accent' : ''}`} />
            </button>
          </div>
          {resource.featured && (
            <span className="absolute bottom-3 end-3 inline-flex items-center gap-1 rounded-full bg-white/90 px-2 py-0.5 text-[11px] font-bold text-accent shadow-sm dark:bg-navy-800/80">
              <Star className="h-3 w-3 fill-accent" /> {t('featuredBadge')}
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col p-4">
          {section && <span className="mb-1 text-xs font-bold text-primary">{section.label}</span>}
          <h3 className="line-clamp-2 font-bold leading-snug text-slate-900 dark:text-white">{title}</h3>
          {meta && <p className="mt-1 line-clamp-1 text-sm text-slate-500 dark:text-slate-400">{meta}</p>}
          <div className="mt-auto flex items-center justify-between pt-4 text-xs text-slate-400">
            <span>{formatBytes(resource.file_size)}</span>
            <span className="inline-flex items-center gap-1"><Download className="h-3.5 w-3.5" /> {resource.download_count}</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

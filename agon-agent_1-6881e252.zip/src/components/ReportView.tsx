import { Share2, Printer, Copy, Download, AlertTriangle, BookOpen, Pill, HeartPulse, FlaskConical, Stethoscope, ExternalLink, FileText } from 'lucide-react';
import type { AiReport } from '../lib/api';

function Section({ icon: Icon, title, accent, children }: { icon: any; title: string; accent: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
      <h3 className={`mb-3 flex items-center gap-2 text-base font-extrabold text-slate-900 dark:text-white`}>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${accent} text-white`}><Icon className="h-4 w-4" /></span>
        {title}
      </h3>
      <div className="space-y-2">{children}</div>
    </section>
  );
}

function List({ items, ordered }: { items: string[]; ordered?: boolean }) {
  if (!items || items.length === 0) return <p className="text-sm text-slate-400">—</p>;
  const cls = 'text-sm leading-relaxed text-slate-700 dark:text-slate-200';
  if (ordered) return <ol className={`list-decimal space-y-1 pr-5 ${cls}`}>{items.map((i, k) => <li key={k}>{i}</li>)}</ol>;
  return <ul className={`list-disc space-y-1 pr-5 ${cls}`}>{items.map((i, k) => <li key={k}>{i}</li>)}</ul>;
}

function toPlainText(r: AiReport, lang: string): string {
  const ar = lang === 'ar';
  const L: string[] = [];
  L.push(ar ? 'تقرير المساعد السريري الذكي (تعليمي فقط)' : 'AI Clinical Assistant Report (education only)');
  L.push(r.disclaimer);
  L.push('');
  const primary = r.primaryDiagnosis || r.differentials[0];
  if (primary) {
    L.push(ar ? 'التشخيص الطبي الأكثر دعماً:' : 'Most-supported working diagnosis:');
    L.push(`${primary.name} — ${ar ? 'ثقة تعليمية' : 'educational confidence'} ${primary.confidence}%`);
    (r.primaryDiagnosis?.support || []).forEach((s) => L.push(' - ' + s));
  }
  L.push('');
  (r.clinicalSummary || []).forEach((s) => L.push(s));
  L.push('');
  L.push(ar ? 'الفحوصات الموصى بها:' : 'Recommended Investigations:'); r.sections.investigations.forEach((i) => L.push(' - ' + i));
  L.push('');
  L.push(ar ? 'العلاج:' : 'Treatment:'); L.push((ar ? 'أولي: ' : 'Initial: ') + r.sections.treatment.initial.join(', '));
  L.push((ar ? 'خط أول: ' : 'First-line: ') + r.sections.treatment.firstLine.join(', '));
  L.push('');
  L.push(ar ? 'الأعلام الحمراء:' : 'Red Flags:'); r.sections.redFlags.forEach((f) => L.push(' - ' + f));
  L.push('');
  L.push(ar ? 'المراجع:' : 'References:'); r.sections.references.forEach((rf) => L.push(` - ${rf.abbr}: ${rf.note} ${rf.url}`));
  return L.join('\n');
}

export default function ReportView({ report, lang = 'en', onClose }: { report: AiReport; lang?: 'en' | 'ar'; onClose?: () => void }) {
  const ar = lang === 'ar';
  const copy = async () => {
    try { await navigator.clipboard.writeText(toPlainText(report, lang)); } catch {}
  };
  const share = async () => {
    const text = toPlainText(report, lang);
    if (navigator.share) { try { await navigator.share({ title: ar ? 'تقرير المساعد السريري الذكي' : 'AI Clinical Assistant Report', text }); return; } catch {} }
    copy();
  };
  const print = () => window.print();

  return (
    <div className="ai-report space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 dark:border-amber-500/30 dark:bg-amber-500/10">
        <div className="flex items-center gap-2 text-sm font-semibold text-amber-800 dark:text-amber-200">
          <AlertTriangle className="h-5 w-5" /> {report.disclaimer}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={copy} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Copy className="h-3.5 w-3.5" /> {ar ? 'نسخ' : 'Copy'}</button>
          <button onClick={share} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Share2 className="h-3.5 w-3.5" /> {ar ? 'مشاركة' : 'Share'}</button>
          <button onClick={print} className="inline-flex items-center gap-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold hover:bg-slate-100 dark:border-white/10 dark:hover:bg-white/5"><Printer className="h-3.5 w-3.5" /> {ar ? 'طباعة/PDF' : 'Print / PDF'}</button>
          {onClose && <button onClick={onClose} className="inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-white"><Download className="h-3.5 w-3.5" /> {ar ? 'إغلاق' : 'Close'}</button>}
        </div>
      </div>

      <Section icon={Stethoscope} title={ar ? 'التشخيص الطبي الأكثر دعماً' : 'Most-supported working diagnosis'} accent="from-primary to-primary-600">
        {(() => {
          const p = report.primaryDiagnosis || report.differentials[0];
          if (!p) return <p className="text-sm text-slate-400">{ar ? 'بيانات غير كافية لتشخيص عامل.' : 'Insufficient data for a working diagnosis.'}</p>;
          return (
            <div className="space-y-3">
              <p className="text-xs font-bold uppercase tracking-wide text-rose-500">
                {ar ? 'هذا ليس تشخيصاً مؤكداً ولا قائمة تفريقية.' : 'This is NOT a confirmed diagnosis and is not a differential list.'}
              </p>
              <div className="rounded-xl border border-slate-200 p-4 dark:border-white/10">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-lg font-extrabold text-slate-900 dark:text-white">{p.name}</span>
                  <span className="rounded-full bg-primary/10 px-2.5 py-1 text-xs font-bold text-primary">{ar ? 'ثقة تعليمية' : 'Educational confidence'} {p.confidence}%</span>
                </div>
                <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-l from-primary to-secondary" style={{ width: `${p.confidence}%` }} />
                </div>
                <ul className="mt-3 list-disc space-y-1 pr-5 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                  {(report.primaryDiagnosis?.support || [report.differentials[0]?.reasoning]).filter(Boolean).map((s, i) => <li key={i}>{s}</li>)}
                </ul>
                {report.primaryDiagnosis?.keyFindings?.length ? (
                  <p className="mt-2 text-xs text-slate-400">{ar ? 'موجودات داعمة: ' : 'Supporting findings: '}{report.primaryDiagnosis.keyFindings.join(ar ? '، ' : ', ')}</p>
                ) : null}
              </div>
              {report.primaryDiagnosis?.missingInformation?.length ? (
                <div className="rounded-xl border border-amber-200 bg-amber-50/80 p-3 text-sm text-amber-900 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-100">
                  <div className="mb-1 font-bold">{ar ? 'معلومات ناقصة حرجة' : 'Critical missing information'}</div>
                  <List items={report.primaryDiagnosis.missingInformation} />
                </div>
              ) : null}
            </div>
          );
        })()}
      </Section>

      {report.profileAnalysis && (
        <Section icon={HeartPulse} title={ar ? 'تحليل الملف حسب العمر والجنس والوزن' : 'Age-, sex- and weight-specific analysis'} accent="from-sky-500 to-indigo-600">
          <List items={[report.profileAnalysis.ageNote, report.profileAnalysis.sexNote, report.profileAnalysis.weightNote, report.profileAnalysis.pregnancyNote || ''].filter(Boolean)} />
          <div className="mt-3 grid gap-3 md:grid-cols-2">
            <div>
              <div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'تفسير العلامات الحيوية' : 'Vital-sign interpretation'}</div>
              <List items={report.profileAnalysis.vitalNotes} />
            </div>
            <div>
              <div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'تفسير التحاليل' : 'Laboratory interpretation'}</div>
              <List items={report.profileAnalysis.labNotes} />
            </div>
          </div>
        </Section>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        <Section icon={FlaskConical} title={ar ? 'الفحوصات الموصى بها' : 'Recommended Investigations'} accent="from-secondary to-secondary-600">
          <List items={report.sections.investigations} ordered />
        </Section>

        <Section icon={AlertTriangle} title={ar ? 'الأعلام الحمراء' : 'Red Flags'} accent="from-red-500 to-rose-600">
          <ul className="space-y-1">
            {report.sections.redFlags.length === 0 && <li className="text-sm text-slate-400">—</li>}
            {report.sections.redFlags.map((f, k) => (
              <li key={k} className="flex items-start gap-2 rounded-lg bg-red-50 p-2 text-sm font-semibold text-red-700 dark:bg-red-500/10 dark:text-red-300">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {f}
              </li>
            ))}
          </ul>
        </Section>
      </div>

      <Section icon={HeartPulse} title={ar ? 'الخطة العلاجية القائمة على الأدلة' : 'Evidence-Based Treatment'} accent="from-emerald-500 to-teal-600">
        <div className="grid gap-3 sm:grid-cols-2">
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'الإدارة الأولية' : 'Initial Management'}</div><List items={report.sections.treatment.initial} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'العلاج الخط الأول' : 'First-line Therapy'}</div><List items={report.sections.treatment.firstLine} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'علاج بديل' : 'Alternative Therapy'}</div><List items={report.sections.treatment.alternative} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'موانع استعمال' : 'Contraindications'}</div><List items={report.sections.treatment.contraindications} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'المتابعة والمراقبة' : 'Monitoring & Follow-up'}</div><List items={[...report.sections.treatment.monitoring, ...report.sections.treatment.followUp]} /></div>
          <div><div className="mb-1 text-xs font-bold text-slate-500">{ar ? 'معايير الدخول والعناية' : 'Admission & ICU Criteria'}</div><List items={[...report.sections.treatment.admission, ...report.sections.treatment.icu]} /></div>
        </div>
      </Section>

      <Section icon={HeartPulse} title={ar ? 'الرعاية التمريضية' : 'Nursing Management'} accent="from-pink-500 to-rose-500">
        <div className="space-y-4">
          {report.sections.nursing.priorities?.length ? (
            <div>
              <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? 'أولويات التمريض المرتبة' : 'Ranked nursing priorities'}</div>
              <ol className="space-y-2">
                {report.sections.nursing.priorities.map((p) => (
                  <li key={p.rank} className="rounded-xl border border-pink-200 bg-pink-50/50 p-3 text-sm dark:border-pink-500/20 dark:bg-pink-500/5">
                    <div className="font-bold">{p.diagnosis}</div>
                    <div className="mt-1 text-xs text-slate-500">{p.rationale}</div>
                  </li>
                ))}
              </ol>
            </div>
          ) : null}
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '1) تشخيصات التمريض (NANDA)' : '1) Nursing Diagnoses (NANDA)'}</div>
            <div className="space-y-2">
              {report.sections.nursing.nanda.map((d, i) => (
                <div key={i} className="rounded-xl border border-pink-200 bg-pink-50/60 p-3 text-sm leading-relaxed text-slate-800 dark:border-pink-500/20 dark:bg-pink-500/5 dark:text-slate-100">
                  {d}
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '2) أهداف التمريض' : '2) Nursing Goals'}</div>
            <List ordered items={report.sections.nursing.goals} />
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '3) التدخلات التمريضية (NIC)' : '3) Nursing Interventions (NIC)'}</div>
            <List items={report.sections.nursing.nic} />
            {report.sections.nursing.assessment?.length > 0 && (
              <div className="mt-2 text-sm text-slate-500"><span className="font-semibold">{ar ? 'التقييم: ' : 'Assessment: '}</span>{report.sections.nursing.assessment.join(' · ')}</div>
            )}
          </div>
          <div>
            <div className="mb-1 text-xs font-bold uppercase tracking-wide text-pink-600 dark:text-pink-300">{ar ? '4) التقييم' : '4) Evaluation'}</div>
            <List items={report.sections.nursing.evaluation} />
          </div>
          {report.sections.nursing.education?.length > 0 && (
            <div className="text-sm text-slate-500"><span className="font-semibold">{ar ? 'تثقيف المريض: ' : 'Patient Education: '}</span>{report.sections.nursing.education.join(' · ')}</div>
          )}
          {report.sections.nursing.discharge?.length > 0 && (
            <div className="text-sm text-slate-500"><span className="font-semibold">{ar ? 'تعليمات الخروج: ' : 'Discharge Instructions: '}</span>{report.sections.nursing.discharge.join(' · ')}</div>
          )}
        </div>
      </Section>

      <Section icon={Pill} title={ar ? 'معلومات الأدوية' : 'Drug Information'} accent="from-indigo-500 to-purple-600">
        <div className="space-y-3">
          {report.sections.drugs.length === 0 && <p className="text-sm text-slate-400">—</p>}
          {report.sections.drugs.map((d, k) => (
            <div key={k} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
              <div className="font-bold text-slate-900 dark:text-white">{d.generic} <span className="text-xs font-normal text-slate-400">({d.trade})</span></div>
              <div className="mt-1 grid gap-1 sm:grid-cols-2 text-slate-600 dark:text-slate-300">
                <div>{ar ? 'الجرعة البالغين: ' : 'Adult dose: '}{d.adultDose}</div><div>{ar ? 'جرعة الأطفال: ' : 'Pediatric dose: '}{d.pedDose}</div>
                <div>{ar ? 'الطريق: ' : 'Route: '}{d.route}</div><div>{ar ? 'التكرار: ' : 'Frequency: '}{d.frequency}</div>
                <div className="sm:col-span-2">{ar ? 'موانع: ' : 'Contraindications: '}{d.contraindications}</div>
                <div className="sm:col-span-2">{ar ? 'أعراض جانبية: ' : 'Side effects: '}{d.sideEffects}</div>
                <div className="sm:col-span-2">{ar ? 'تفاعلات: ' : 'Interactions: '}{d.interactions}</div>
                <div className="sm:col-span-2">{ar ? 'اعتبارات تمريضية: ' : 'Nursing considerations: '}{d.nursing}</div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {report.sections.redFlags?.length > 0 && (
        <div className="rounded-2xl border-2 border-rose-500 bg-rose-50 p-4 text-rose-800 dark:border-rose-500/50 dark:bg-rose-500/10 dark:text-rose-100">
          <div className="mb-2 flex items-center gap-2 text-sm font-extrabold uppercase tracking-wide">
            <AlertTriangle className="h-5 w-5" /> {ar ? 'تصعيد طارئ — اطلب مساعدة مهنية فورية' : 'Emergency escalation — seek professional care now'}
          </div>
          <p className="mb-2 text-sm">
            {ar
              ? 'هذه الأداة تعليمية وليست طبيباً أو ممرضاً مرخّصاً. إن وُجدت أعلام حمراء: اتصل بالإسعاف / اذهب للطوارئ فوراً.'
              : 'This assistant is not a licensed physician or nurse. If red flags are present, call emergency services / go to the ED immediately.'}
          </p>
          <ul className="list-disc space-y-1 pr-5 text-sm font-semibold">
            {report.sections.redFlags.map((f, i) => <li key={i}>{f}</li>)}
          </ul>
        </div>
      )}

      {report.webResearch && (
        <Section icon={BookOpen} title={ar ? 'بحث حيّ في المصادر (وقت التحليل)' : 'Live source retrieval (at analysis time)'} accent="from-emerald-600 to-teal-600">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            {report.webResearch.error
              ? (ar ? `تعذّر البحث الحي: ${report.webResearch.error}` : `Live retrieval issue: ${report.webResearch.error}`)
              : (ar
                ? `تم الاسترجاع من ${report.webResearch.provider || 'PubMed'} خلال ${report.webResearch.durationMs || '—'} مللي ثانية. المراجع أدناه مقالات حقيقية بروابط قابلة للفتح — ليست مختلقة.`
                : `Retrieved via ${report.webResearch.provider || 'PubMed'} in ${report.webResearch.durationMs || '—'} ms. Citations below are real indexed records with openable links — never fabricated.`)}
          </p>
          {report.webResearch.queries?.primary && (
            <p className="mt-2 text-xs text-slate-400">{ar ? 'استعلام:' : 'Query:'} {report.webResearch.queries.primary}</p>
          )}
          <ul className="mt-3 space-y-2">
            {(report.webResearch.articles || []).map((a) => (
              <li key={a.url} className="text-sm">
                <a href={a.url} target="_blank" rel="noopener noreferrer" className="font-semibold text-primary hover:underline">{a.title}</a>
                <span className="text-slate-500"> — {a.source}{a.year ? ` ${a.year}` : ''}{a.journal ? ` · ${a.journal}` : ''}</span>
              </li>
            ))}
          </ul>
        </Section>
      )}

      {report.evidencePipeline && (
        <Section icon={BookOpen} title={ar ? 'خط أنابيب الأدلة السريرية' : 'Clinical evidence pipeline'} accent="from-indigo-500 to-sky-600">
          <p className="text-sm leading-7 text-slate-600 dark:text-slate-300">{report.evidencePipeline.check.summary}</p>
          <p className="mt-2 text-xs text-slate-400">
            {ar ? 'موجودات مُجمّعة' : 'Findings collected'}: {report.evidencePipeline.findingsCollected} · {ar ? 'مصادر مُسترجَعة' : 'Sources retrieved'}: {report.evidencePipeline.sourcesRetrieved} · {ar ? 'درجة الفحص' : 'Check grade'}: {report.evidencePipeline.check.grade}
          </p>
          {report.evidencePipeline.check.groundedClaims?.length ? (
            <ul className="mt-3 list-disc space-y-1 pr-5 text-sm text-slate-600 dark:text-slate-300">
              {report.evidencePipeline.check.groundedClaims.slice(0, 6).map((c, i) => (
                <li key={i}><span className="font-semibold">{c.org}:</span> {c.claim}</li>
              ))}
            </ul>
          ) : null}
        </Section>
      )}

      {report.clinicalSummary?.length ? (
        <Section icon={FileText} title={ar ? 'الملخص السريري' : 'Clinical summary'} accent="from-slate-500 to-slate-700">
          <List items={report.clinicalSummary} />
        </Section>
      ) : null}

      {report.relatedPdfs.length > 0 && (
        <Section icon={FileText} title={ar ? 'ملفات ذات صلة من مكتبتك' : 'Related PDFs from Your Library'} accent="from-accent to-orange-500">
          <div className="grid gap-3 sm:grid-cols-2">
            {report.relatedPdfs.map((p) => (
              <a key={p.id} href={`/resource/${p.id}`} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 transition hover:border-primary dark:border-white/10">
                {p.cover ? <img src={p.cover} alt="" className="h-12 w-12 rounded-lg object-cover" /> : <BookOpen className="h-8 w-8 text-primary" />}
                <span className="text-sm font-semibold text-slate-800 dark:text-slate-100 line-clamp-2">{p.title}</span>
              </a>
            ))}
          </div>
        </Section>
      )}

      <Section icon={BookOpen} title={ar ? 'المراجع الموثوقة (RAG)' : 'Trusted References (RAG)'} accent="from-slate-600 to-slate-800">
        <ul className="space-y-1">
          {report.sections.references.map((rf, k) => (
            <li key={k}>
              <a href={rf.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline">
                {rf.abbr} <ExternalLink className="h-3 w-3" />
              </a>
              <span className="text-sm text-slate-600 dark:text-slate-300"> — {rf.note}</span>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}

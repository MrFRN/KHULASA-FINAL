import { Stethoscope, HeartPulse, Pill, Syringe, Activity, Cross, Thermometer } from 'lucide-react';

const ITEMS = [
  { Icon: Stethoscope, cls: 'top-10 right-[8%] text-primary/70', delay: '0s', size: 'h-9 w-9' },
  { Icon: HeartPulse, cls: 'top-24 left-[10%] text-secondary/70', delay: '1.2s', size: 'h-10 w-10' },
  { Icon: Pill, cls: 'bottom-24 right-[14%] text-accent/70', delay: '0.6s', size: 'h-8 w-8' },
  { Icon: Syringe, cls: 'bottom-16 left-[16%] text-primary/60', delay: '1.8s', size: 'h-9 w-9' },
  { Icon: Activity, cls: 'top-1/2 left-[6%] text-secondary/60', delay: '2.4s', size: 'h-8 w-8' },
  { Icon: Cross, cls: 'top-16 left-1/3 text-accent/50', delay: '0.9s', size: 'h-7 w-7' },
  { Icon: Thermometer, cls: 'bottom-1/3 right-[6%] text-primary/50', delay: '1.5s', size: 'h-8 w-8' },
];

export default function FloatingIcons() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {ITEMS.map((it, i) => {
        const I = it.Icon;
        return (
          <span key={i} className={`absolute animate-float-slow ${it.cls}`} style={{ animationDelay: it.delay }}>
            <I className={it.size} />
          </span>
        );
      })}
    </div>
  );
}

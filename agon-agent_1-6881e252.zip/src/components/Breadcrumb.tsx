import { Link } from 'react-router-dom';
import { ChevronLeft, Home } from 'lucide-react';

export interface Crumb { label: string; to?: string; }

export default function Breadcrumb({ items }: { items: Crumb[] }) {
  return (
    <nav className="flex flex-wrap items-center gap-1 text-sm text-slate-500 dark:text-slate-400">
      <Link to="/" className="flex items-center gap-1 hover:text-primary"><Home className="h-4 w-4" /> الرئيسية</Link>
      {items.map((c, i) => (
        <span key={i} className="flex items-center gap-1">
          <ChevronLeft className="h-4 w-4 text-slate-300" />
          {c.to && i < items.length - 1 ? (
            <Link to={c.to} className="hover:text-primary">{c.label}</Link>
          ) : (
            <span className="font-semibold text-slate-700 dark:text-slate-200">{c.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

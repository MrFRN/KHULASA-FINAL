import {
  GraduationCap, BookOpen, MessagesSquare, Stethoscope, HeartPulse, Pill, Baby,
  Syringe, Activity, Brain, Users, Microscope, Bone, Languages, Ambulance, Scissors,
  Droplet, ClipboardList, FileText, Building2, Cross, FlaskConical, ShieldPlus,
  BriefcaseMedical, HelpCircle, ListChecks, Lightbulb, MessageCircle,
  Download, TrendingUp, Layers, Sparkles, Eye, FolderTree, Star, HeartHandshake,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

const MAP: Record<string, LucideIcon> = {
  GraduationCap, BookOpen, MessagesSquare, Stethoscope, HeartPulse, Pill, Baby,
  Syringe, Activity, Brain, Users, Microscope, Bone, Languages, Ambulance, Scissors,
  Droplet, ClipboardList, FileText, Building2, Cross, FlaskConical, ShieldPlus,
  BriefcaseMedical, HelpCircle, ListChecks, Lightbulb, MessageCircle,
  Download, TrendingUp, Layers, Sparkles, Eye, FolderTree, Star, HeartHandshake,
};

export default function Icon({ name, className }: { name: string | null | undefined; className?: string }) {
  const Cmp = (name && MAP[name]) || FileText;
  return <Cmp className={className} />;
}

export const ICON_NAMES = Object.keys(MAP);

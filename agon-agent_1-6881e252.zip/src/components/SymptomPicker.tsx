import { useMemo, useState } from 'react';
import { Search, X, Check, Stethoscope } from 'lucide-react';
import { SYMPTOMS, Symptom } from '../lib/kb/symptoms';

const SYS_AR: Record<string, string> = {
  general: 'عام', cardio: 'قلب وأوعية', resp: 'تنفس', gi: 'هضم', neuro: 'أعصاب',
  renal: 'كلى وبول', endo: 'غدد', derm: 'جلد', msk: 'عظام ومفاصل', psych: 'نفسي',
  ob: 'نساء وحمل', peds: 'أطفال', ent: 'أنف وأذن',
};

export default function SymptomPicker({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);

  const selected = useMemo(() => SYMPTOMS.filter((s) => value.includes(s.id)), [value]);

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return SYMPTOMS;
    return SYMPTOMS.filter((s) => s.ar.includes(t) || s.en.toLowerCase().includes(t) || s.id.includes(t));
  }, [q]);

  const grouped = useMemo(() => {
    const m: Record<string, Symptom[]> = {};
    for (const s of filtered) (m[s.sys] = m[s.sys] || []).push(s);
    return m;
  }, [filtered]);

  const toggle = (id: string) => {
    onChange(value.includes(id) ? value.filter((x) => x !== id) : [...value, id]);
  };

  return (
    <div className="relative">
      <div className="flex flex-wrap gap-2 rounded-xl border border-slate-300 bg-white p-2 dark:border-white/10 dark:bg-white/5 min-h-[52px]">
        {selected.length === 0 && <span className="px-1 py-1 text-sm text-slate-400">Select symptoms from the list…</span>}
        {selected.map((s) => (
          <span key={s.id} className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary dark:text-primary-300">
            {s.ar}
            <button type="button" onClick={() => toggle(s.id)} className="rounded-full p-0.5 hover:bg-primary/20"><X className="h-3 w-3" /></button>
          </span>
        ))}
        <button type="button" onClick={() => setOpen((o) => !o)} className="ml-auto inline-flex items-center gap-1 rounded-lg bg-primary/10 px-3 py-1 text-xs font-bold text-primary hover:bg-primary/20">
          <Stethoscope className="h-3.5 w-3.5" /> Search symptoms ({selected.length})
        </button>
      </div>

      {open && (
        <div className="absolute z-30 mt-2 w-full rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-white/10 dark:bg-navy-800">
          <div className="flex items-center gap-2 border-b border-slate-100 p-3 dark:border-white/10">
            <Search className="h-4 w-4 text-slate-400" />
            <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search in English or Arabic…" className="w-full bg-transparent text-sm outline-none dark:text-white" />
          </div>
          <div className="max-h-72 overflow-y-auto p-2">
            {Object.entries(grouped).map(([sys, list]) => (
              <div key={sys} className="mb-2">
                <div className="px-2 py-1 text-[11px] font-bold uppercase tracking-wide text-slate-400">{SYS_AR[sys] || sys}</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                  {list.slice(0, 60).map((s) => {
                    const on = value.includes(s.id);
                    return (
                      <button key={s.id} type="button" onClick={() => toggle(s.id)} className={`flex items-center justify-between rounded-lg px-3 py-2 text-right text-sm transition ${on ? 'bg-primary/15 text-primary' : 'hover:bg-slate-100 dark:hover:bg-white/5'}`}>
                        <span>{s.en}{s.ar && s.ar !== s.en ? ` (${s.ar})` : ''}</span>
                        {on && <Check className="h-4 w-4 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
            {filtered.length === 0 && <div className="p-4 text-center text-sm text-slate-400">No results</div>}
          </div>
        </div>
      )}
    </div>
  );
}

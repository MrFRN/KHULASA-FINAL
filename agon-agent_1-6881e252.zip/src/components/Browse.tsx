import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import PublicLayout from './PublicLayout';
import Breadcrumb from './Breadcrumb';
import SectionHeader from './SectionHeader';
import FilterBar from './FilterBar';
import ResourceCard from './ResourceCard';
import Pagination from './Pagination';
import { SkeletonGrid } from './CardSkeleton';
import Icon from './Icon';
import { fetchResources, fetchCategories } from '../lib/api';
import { extOf, labelForFile } from '../lib/filetypes';
import type { Resource, NursingCategory, Section } from '../types';
import { FolderOpen } from 'lucide-react';
import { useLang } from '../contexts/LanguageContext';
import { categoryName, sectionCopy } from '../lib/localize';

const PER_PAGE = 12;

export default function Browse({ section }: { section: Section }) {
  const { category } = useParams();
  const { t, lang } = useLang();
  const meta = sectionCopy(section, lang);
  const [resources, setResources] = useState<Resource[]>([]);
  const [categories, setCategories] = useState<NursingCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [subject, setSubject] = useState('');
  const [year, setYear] = useState('');
  const [type, setType] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);

  useEffect(() => {
    setLoading(true);
    Promise.all([fetchResources({ section }), fetchCategories(section)])
      .then(([r, c]) => { setResources(r); setCategories(c); })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [section]);

  useEffect(() => { setPage(1); }, [search, subject, year, type, category, sort]);

  const activeCat = categories.find((c) => c.slug === category);

  const subjects = useMemo(() => [...new Set(resources.map((r) => r.subject).filter(Boolean))] as string[], [resources]);
  const years = useMemo(() => [...new Set(resources.map((r) => r.year).filter(Boolean))] as string[], [resources]);
  const types = useMemo(() => [...new Set(resources.map((r) => extOf(r.file_type || r.file_name || '')).filter(Boolean))] as string[], [resources]);

  const filtered = useMemo(() => {
    let r = resources;
    if (category) r = r.filter((x) => x.category === category);
    if (search) {
      const q = search.toLowerCase();
      r = r.filter((x) => [x.title, x.en?.title_en, x.description, x.en?.description_en, x.subject, x.author, (x.tags || []).join(' ')].filter(Boolean).join(' ').toLowerCase().includes(q));
    }
    if (subject) r = r.filter((x) => x.subject === subject);
    if (year) r = r.filter((x) => x.year === year);
    if (type) r = r.filter((x) => extOf(x.file_type || x.file_name || '') === type);
    r = [...r].sort((a, b) => {
      switch (sort) {
        case 'oldest': return +new Date(a.created_at) - +new Date(b.created_at);
        case 'popular': return b.download_count - a.download_count;
        case 'title': return a.title.localeCompare(b.title, lang === 'ar' ? 'ar' : 'en');
        default: return +new Date(b.created_at) - +new Date(a.created_at);
      }
    });
    return r;
  }, [resources, category, search, subject, year, type, sort, lang]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const pageItems = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const catLabel = activeCat ? categoryName(activeCat, lang) : '';

  const filters = [
    ...(subjects.length ? [{ key: 'subject', placeholder: t('subject'), value: subject, options: subjects.map((s) => ({ value: s, label: s })), onChange: setSubject }] : []),
    ...(section === 'study' && years.length ? [{ key: 'year', placeholder: t('academicYear'), value: year, options: years.map((y) => ({ value: y, label: y })), onChange: setYear }] : []),
    ...(types.length ? [{ key: 'type', placeholder: t('fileType'), value: type, options: types.map((tp) => ({ value: tp, label: labelForFile(tp) })), onChange: setType }] : []),
  ];

  if (category && !activeCat && !loading) {
    return (
      <PublicLayout>
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Breadcrumb items={[{ label: meta.label, to: meta.path }]} />
          <div className="mt-10 flex flex-col items-center gap-4 rounded-2xl border border-dashed border-slate-300 py-20 text-center dark:border-white/10">
            <FolderOpen className="h-12 w-12 text-slate-300" />
            <p className="font-semibold text-slate-700 dark:text-slate-200">{t('sectionMissing')}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">{t('sectionMissingHint')}</p>
            <Link to={meta.path} className="mt-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white transition hover:opacity-90">{t('backTo')} {meta.label}</Link>
          </div>
        </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Breadcrumb items={[{ label: meta.label, to: meta.path }, ...(activeCat ? [{ label: catLabel }] : [])]} />
        <div className="mt-6">
          <SectionHeader title={activeCat ? catLabel : meta.label} subtitle={activeCat ? undefined : meta.desc} icon={activeCat?.icon || meta.icon} gradient={meta.color} />
        </div>

        {categories.length > 0 && (
          <div className="mb-6 flex flex-wrap gap-2">
            <Link to={meta.path} className={`rounded-full px-4 py-2 text-sm font-semibold transition ${!category ? 'bg-primary text-white' : 'border border-slate-200 bg-white text-slate-600 hover:border-primary hover:text-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-300'}`}>{t('all')}</Link>
            {categories.map((c) => (
              <Link key={c.id} to={`${meta.path}/${c.slug}`} className={`inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-semibold transition ${category === c.slug ? 'bg-primary text-white' : 'border border-slate-200 bg-white text-slate-600 hover:border-primary hover:text-primary dark:border-white/10 dark:bg-white/5 dark:text-slate-300'}`}>
                {c.icon && <Icon name={c.icon} className="h-4 w-4" />} {categoryName(c, lang)}
              </Link>
            ))}
          </div>
        )}

        <FilterBar
          search={search}
          onSearch={setSearch}
          filters={filters}
          sort={sort}
          onSort={setSort}
          sortOptions={[
            { value: 'newest', label: t('sortNewest') },
            { value: 'oldest', label: t('sortOldest') },
            { value: 'popular', label: t('sortPopular') },
            { value: 'title', label: t('sortTitle') },
          ]}
        />

        <div className="mt-6">
          {loading ? <SkeletonGrid count={8} /> : error ? (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-500/20 dark:bg-red-500/10">{error}</div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-slate-300 py-20 text-center text-slate-500 dark:border-white/10">
              <FolderOpen className="h-12 w-12 text-slate-300" />
              <p className="font-semibold text-slate-700 dark:text-slate-200">{t('noMatch')}</p>
              <p className="text-sm">{t('tryFilters')}</p>
            </div>
          ) : (
            <>
              <p className="mb-4 text-sm text-slate-500 dark:text-slate-400">{filtered.length} {t('filesCount')}</p>
              <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
                {pageItems.map((r, i) => <ResourceCard key={r.id} resource={r} index={i} />)}
              </div>
              <Pagination page={page} totalPages={totalPages} onChange={(p) => { setPage(p); window.scrollTo({ top: 0, behavior: 'smooth' }); }} />
            </>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}

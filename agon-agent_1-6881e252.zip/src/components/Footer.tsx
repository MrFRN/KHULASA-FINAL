import { Link } from 'react-router-dom';
import { Cross, Send, Facebook, Mail } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { useLang } from '../contexts/LanguageContext';
import { sectionCopy } from '../lib/localize';
import { SECTION_LIST } from '../lib/constants';

export default function Footer() {
  const { settings } = useSettings();
  const { t, lang } = useLang();
  const year = new Date().getFullYear();
  return (
    <footer className="mt-20 border-t border-slate-200 bg-white/60 dark:border-white/10 dark:bg-navy-800/50">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="mb-4 flex items-center gap-2.5">
            {settings.logoUrl ? (
              <img src={settings.logoUrl} alt={settings.siteName} className="h-10 w-10 rounded-xl object-cover" />
            ) : (
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary text-white"><Cross className="h-5 w-5" /></span>
            )}
            <span className="text-lg font-extrabold text-slate-900 dark:text-white">{settings.siteName}</span>
          </div>
          <p className="text-sm leading-relaxed text-slate-500 dark:text-slate-400">{settings.aboutText}</p>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-slate-900 dark:text-white">{t('quickLinks')}</h4>
          <ul className="space-y-2.5 text-sm text-slate-500 dark:text-slate-400">
            <li><Link to="/" className="hover:text-primary">{t('navHome')}</Link></li>
            <li><Link to="/favorites" className="hover:text-primary">{t('navFavorites')}</Link></li>
            <li><Link to="/search" className="hover:text-primary">{t('navSearch')}</Link></li>
            <li><Link to="/login" className="hover:text-primary">{t('navLogin')}</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-slate-900 dark:text-white">{t('sections')}</h4>
          <ul className="space-y-2.5 text-sm text-slate-500 dark:text-slate-400">
            {SECTION_LIST.map((s) => {
              const copy = sectionCopy(s.key, lang);
              return <li key={s.key}><Link to={s.path} className="hover:text-primary">{copy.label}</Link></li>;
            })}
          </ul>
        </div>

        <div>
          <h4 className="mb-4 font-bold text-slate-900 dark:text-white">{t('contact')}</h4>
          <div className="flex gap-3">
            {settings.telegram && <a href={settings.telegram} target="_blank" rel="noreferrer" aria-label="Telegram" className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 transition hover:bg-primary hover:text-white dark:bg-white/5 dark:text-slate-300"><Send className="h-5 w-5" /></a>}
            {settings.facebook && <a href={settings.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 transition hover:bg-primary hover:text-white dark:bg-white/5 dark:text-slate-300"><Facebook className="h-5 w-5" /></a>}
            {settings.email && <a href={`mailto:${settings.email}`} aria-label="Email" className="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 transition hover:bg-primary hover:text-white dark:bg-white/5 dark:text-slate-300"><Mail className="h-5 w-5" /></a>}
          </div>
          {settings.email && <p className="mt-4 text-sm text-slate-500 dark:text-slate-400" dir="ltr">{settings.email}</p>}
        </div>
      </div>
      <div className="border-t border-slate-200 py-5 text-center text-sm text-slate-400 dark:border-white/10">
        © {year} · {settings.footerText}
      </div>
    </footer>
  );
}

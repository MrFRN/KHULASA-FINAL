import type { FileStatus } from '../types';

const MAP: Record<FileStatus, { label: string; cls: string }> = {
  published: { label: 'منشور', cls: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-500/10 dark:text-emerald-300' },
  draft: { label: 'مسودة', cls: 'bg-slate-100 text-slate-600 ring-slate-500/20 dark:bg-slate-500/10 dark:text-slate-300' },
  scheduled: { label: 'مجدول', cls: 'bg-blue-50 text-blue-700 ring-blue-600/20 dark:bg-blue-500/10 dark:text-blue-300' },
};

export default function StatusBadge({ status }: { status: FileStatus }) {
  const m = MAP[status] || MAP.draft;
  return (
    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${m.cls}`}>
      {m.label}
    </span>
  );
}

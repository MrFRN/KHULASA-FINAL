export { default } from './ResourceCard';

import { useLang } from '../contexts/LanguageContext';

export default function LanguageToggle({ compact = false }: { compact?: boolean }) {
  const { lang, setLang, t } = useLang();
  return (
    <div className={`flex items-center rounded-full border border-slate-200 bg-white/80 p-0.5 text-[11px] font-semibold dark:border-white/10 dark:bg-white/5 ${compact ? '' : ''}`}>
      <button
        type="button"
        onClick={() => setLang('ar')}
        aria-label={t('langAr')}
        className={`rounded-full px-2.5 py-1 transition ${lang === 'ar' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500 hover:text-slate-800'}`}
      >
        ع
      </button>
      <button
        type="button"
        onClick={() => setLang('en')}
        aria-label={t('langEn')}
        className={`rounded-full px-2.5 py-1 transition ${lang === 'en' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500 hover:text-slate-800'}`}
      >
        EN
      </button>
    </div>
  );
}

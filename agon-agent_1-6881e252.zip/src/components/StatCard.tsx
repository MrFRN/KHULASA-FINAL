import { motion } from 'framer-motion';
import Icon from './Icon';
import { formatNumber } from '../lib/format';

export default function StatCard({
  icon, value, label, gradient = 'from-primary to-secondary', index = 0, isNumber = true,
}: { icon: string; value: number | string; label: string; gradient?: string; index?: number; isNumber?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5"
    >
      <div className={`mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-white shadow-lg`}>
        <Icon name={icon} className="h-5 w-5" />
      </div>
      <p className="text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl">
        {isNumber && typeof value === 'number' ? formatNumber(value) : value}
      </p>
      <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">{label}</p>
    </motion.div>
  );
}

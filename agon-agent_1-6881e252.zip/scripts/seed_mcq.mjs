// Seed MCQ cases into Supabase via REST (uses dynamic import of mcq_cases.mjs).
import { readFileSync } from 'node:fs';
import https from 'node:https';

const env = readFileSync('.env', 'utf8');
const get = (k) => { const m = env.match(new RegExp('^' + k + '=(.*)$', 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : undefined; };
const SUPA_URL = get('NEXT_PUBLIC_SUPABASE_URL').replace(/\/$/, '');
const KEY = get('SUPABASE_SERVICE_ROLE_KEY');

function req(method, path, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const url = new URL(path, SUPA_URL);
    const r = https.request({
      method, hostname: url.hostname, path: url.pathname + url.search,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json', 'apikey': KEY, 'Authorization': 'Bearer ' + KEY,
        'Prefer': 'return=representation', ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    }, (res) => {
      let chunks = '';
      res.on('data', (c) => chunks += c);
      res.on('end', () => resolve({ status: res.statusCode, body: chunks }));
    });
    r.on('error', reject);
    r.on('timeout', () => r.destroy(new Error('timeout')));
    if (data) r.write(data);
    r.end();
  });
}

async function seedCase(c) {
  const { questions, ...rest } = c;
  rest.status = 'published';
  rest.featured = true;
  rest.published_at = new Date().toISOString();
  rest.verified_at = new Date().toISOString();
  rest.view_count = 0;
  rest.completion_count = 0;
  rest.avg_score = 0;
  rest.created_at = new Date().toISOString();
  const r = await req('POST', '/rest/v1/case_mcq_cases', rest);
  if (r.status >= 400) { console.error('FAIL', c.slug, r.body.slice(0, 200)); return false; }
  const inserted = JSON.parse(r.body);
  const id = inserted[0]?.id;
  if (!id) { console.error('No ID'); return false; }
  const rows = questions.map((q) => ({ ...q, case_id: id }));
  const qr = await req('POST', '/rest/v1/case_mcq_questions', rows);
  if (qr.status >= 400) { console.error('QS FAIL', c.slug, qr.body.slice(0, 200)); return false; }
  console.log('OK', c.slug, 'id=' + id, 'qs=' + rows.length);
  return true;
}

const mod = await import('./mcq_cases.mjs');
const ALL_CASES = mod.default;
let total = 0;
for (const c of ALL_CASES) {
  if (await seedCase(c)) total++;
}
console.log('Done: ' + total + ' cases');

-- ============================================================
-- الخلاصة في التمريض — RLS + Storage policies
-- Run this ONCE in Supabase → SQL Editor (project fsrintykugcpfeacpeay)
-- User type: authenticated (owner / admin logged in)
-- ============================================================

-- Public buckets used by the admin uploader
insert into storage.buckets (id, name, public)
values
  ('files', 'files', true),
  ('covers', 'covers', true),
  ('media', 'media', true)
on conflict (id) do update set public = true;

-- ---------- TABLE: public.resources ----------
alter table public.resources enable row level security;

drop policy if exists resources_select_all on public.resources;
drop policy if exists resources_insert_auth on public.resources;
drop policy if exists resources_update_auth on public.resources;
drop policy if exists resources_delete_auth on public.resources;

create policy resources_select_all
  on public.resources for select
  using (true);

create policy resources_insert_auth
  on public.resources for insert
  to authenticated
  with check (auth.uid() is not null);

create policy resources_update_auth
  on public.resources for update
  to authenticated
  using (auth.uid() is not null)
  with check (auth.uid() is not null);

create policy resources_delete_auth
  on public.resources for delete
  to authenticated
  using (auth.uid() is not null);

-- ---------- TABLE: public.resource_chunks ----------
alter table public.resource_chunks enable row level security;

drop policy if exists resource_chunks_select_all on public.resource_chunks;
drop policy if exists resource_chunks_insert_auth on public.resource_chunks;
drop policy if exists resource_chunks_update_auth on public.resource_chunks;
drop policy if exists resource_chunks_delete_auth on public.resource_chunks;

create policy resource_chunks_select_all
  on public.resource_chunks for select
  using (true);

create policy resource_chunks_insert_auth
  on public.resource_chunks for insert
  to authenticated
  with check (auth.uid() is not null);

create policy resource_chunks_update_auth
  on public.resource_chunks for update
  to authenticated
  using (auth.uid() is not null)
  with check (auth.uid() is not null);

create policy resource_chunks_delete_auth
  on public.resource_chunks for delete
  to authenticated
  using (auth.uid() is not null);

-- ---------- TABLE: public.nursing_categories ----------
alter table public.nursing_categories enable row level security;

drop policy if exists nursing_categories_select_all on public.nursing_categories;
drop policy if exists nursing_categories_write_auth on public.nursing_categories;

create policy nursing_categories_select_all
  on public.nursing_categories for select
  using (true);

create policy nursing_categories_write_auth
  on public.nursing_categories for all
  to authenticated
  using (auth.uid() is not null)
  with check (auth.uid() is not null);

-- ---------- STORAGE: storage.objects for files / covers / media ----------
drop policy if exists storage_khulasa_select on storage.objects;
drop policy if exists storage_khulasa_insert on storage.objects;
drop policy if exists storage_khulasa_update on storage.objects;
drop policy if exists storage_khulasa_delete on storage.objects;

create policy storage_khulasa_select
  on storage.objects for select
  using (bucket_id in ('files', 'covers', 'media'));

create policy storage_khulasa_insert
  on storage.objects for insert
  to authenticated
  with check (bucket_id in ('files', 'covers', 'media') and auth.uid() is not null);

create policy storage_khulasa_update
  on storage.objects for update
  to authenticated
  using (bucket_id in ('files', 'covers', 'media') and auth.uid() is not null)
  with check (bucket_id in ('files', 'covers', 'media') and auth.uid() is not null);

create policy storage_khulasa_delete
  on storage.objects for delete
  to authenticated
  using (bucket_id in ('files', 'covers', 'media') and auth.uid() is not null);

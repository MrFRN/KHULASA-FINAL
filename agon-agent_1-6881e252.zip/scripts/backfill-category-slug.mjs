import { readFileSync } from 'node:fs';
// Node 20 has no global WebSocket; stub it so @supabase/supabase-js can init.
if (typeof globalThis.WebSocket === 'undefined') {
  globalThis.WebSocket = class { constructor() { throw new Error('realtime disabled'); } close() {} };
}
import { createClient } from '@supabase/supabase-js';

const env = readFileSync('.env', 'utf8');
const get = (k) => {
  const m = env.match(new RegExp(`^${k}=(.*)$`, 'm'));
  if (!m) return undefined;
  return m[1].trim().replace(/^["']|["']$/g, '');
};
const url = get('NEXT_PUBLIC_SUPABASE_URL');
const key = get('SUPABASE_SERVICE_ROLE_KEY');
const supabase = createClient(url, key, {
  auth: { persistSession: false },
  realtime: { enabled: false },
});

const { data: cats } = await supabase.from('nursing_categories').select('name, slug');
const slugSet = new Set(cats.map((c) => c.slug));
const nameToSlug = Object.fromEntries(cats.map((c) => [c.name, c.slug]));

const { data: resources } = await supabase.from('resources').select('id, category, category_slug');
let updated = 0, missing = 0;
for (const r of resources || []) {
  let slug = null;
  if (r.category) {
    if (slugSet.has(r.category)) slug = r.category;            // category already a slug
    else if (nameToSlug[r.category]) slug = nameToSlug[r.category]; // category is a name
  }
  if (slug === r.category_slug) continue;
  if (!slug) { missing++; continue; }
  const { error } = await supabase.from('resources').update({ category_slug: slug }).eq('id', r.id);
  if (!error) updated++;
}
console.log(`backfilled category_slug: updated=${updated} missing=${missing} total=${resources?.length}`);

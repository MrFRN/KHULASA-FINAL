import { readFileSync } from 'node:fs';
if (typeof globalThis.WebSocket === 'undefined') globalThis.WebSocket = class { constructor(){throw new Error('x')} close(){} };
import { createClient } from '@supabase/supabase-js';
const env = readFileSync('.env','utf8');
const get=(k)=>{const m=env.match(new RegExp(`^${k}=(.*)$`,'m'));return m?m[1].trim().replace(/^["']|["']$/g,''):undefined;};
const supabase=createClient(get('NEXT_PUBLIC_SUPABASE_URL'),get('SUPABASE_SERVICE_ROLE_KEY'),{auth:{persistSession:false},realtime:{enabled:false}});

// id 38: "كتب طبية + NCLEX" slug medical-books -> nclex-books
// id 67: "غرفة العمليات" (books) slug غرفة-العمليات -> surgery-books
const changes = [
  { id: 38, slug: 'nclex-books' },
  { id: 67, slug: 'surgery-books' },
];
for (const c of changes) {
  const { error } = await supabase.from('nursing_categories').update({ slug: c.slug }).eq('id', c.id);
  console.log('cat', c.id, '->', c.slug, error ? error.message : 'ok');
}
// update resources whose category equals the OLD slug (within books section)
const oldToNew = { 'medical-books': 'nclex-books', 'غرفة-العمليات': 'surgery-books' };
const { data: res } = await supabase.from('resources').select('id, category, section');
let upd = 0;
for (const r of res || []) {
  const ns = oldToNew[r.category];
  if (ns) { const { error } = await supabase.from('resources').update({ category: ns }).eq('id', r.id); if(!error) upd++; }
}
console.log('resources updated:', upd);
// verify
const { data: v } = await supabase.from('resources').select('id,title,category').in('category', ['nclex-books','surgery-books']);
console.log('verify:', JSON.stringify(v));
